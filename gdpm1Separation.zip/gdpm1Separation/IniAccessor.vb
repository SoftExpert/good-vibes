﻿Option Explicit On
Imports System.Runtime.InteropServices
Imports System.Text

Namespace Kofax.Samples.SmpleOcx
    Module IniAccessor
        <DllImport("kernel32.dll", SetLastError:=True)>
        Public Function GetPrivateProfileString(ByVal lpAppName As String,
                            ByVal lpKeyName As String,
                            ByVal lpDefault As String,
                            ByVal lpReturnedString As StringBuilder,
                            ByVal nSize As Integer,
                            ByVal lpFileName As String) As Integer
        End Function


        Function GetIniString(ByVal Section$, ByVal Item$, ByVal File$) As String
            Const BUFSIZ As Integer = 255
            Dim Buf As StringBuilder = New StringBuilder(BUFSIZ)
            Dim RC&

            RC = GetPrivateProfileString(Section, Item, "", Buf, BUFSIZ, File)

            If RC > 0 Then
                GetIniString = Left$(Buf.ToString(), RC)
            Else
                GetIniString = ""
            End If

        End Function

        Function GetIniInteger(ByVal Section$, ByVal Item$, ByVal File$, ByRef intVal As Integer) As Boolean
            Const BUFSIZ As Integer = 255
            Dim Buf As StringBuilder = New StringBuilder(BUFSIZ)
            Dim RC&

            Dim s As String

            Try
                RC = GetPrivateProfileString(Section, Item, "", Buf, BUFSIZ, File)

                If RC > 0 Then
                    s = Left$(Buf.ToString(), RC)
                    intVal = Convert.ToInt32(s)
                    Return True
                End If
            Catch ex As Exception

            End Try
            Return False
        End Function

        <System.Runtime.CompilerServices.Extension()>
        Public Sub Invoke(ByVal control As Control, ByVal action As Action)
            If control.InvokeRequired Then
                control.Invoke(New MethodInvoker(Sub() action()), Nothing)
            Else
                action.Invoke()
            End If
        End Sub

    End Module

End Namespace