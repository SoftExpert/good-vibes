Option Strict Off
Option Explicit On

Imports Microsoft.Win32
Imports System.Runtime.InteropServices
Imports VB = Microsoft.VisualBasic
Imports System.Threading
Imports InteropServices = Kofax.Capture.CaptureModule.InteropServices
Imports Kofax.Capture.CaptureModule
Imports Kofax.SDK.CaptureInfo

Namespace Kofax.Samples.SmpleOcx

    '<ProgId("Kofax.SampleUserControl")> _
    '<Guid("03753CBC-E918-3156-94C7-2859013764E0")> _
    Public Class SampleUserControl
		Inherits System.Windows.Forms.UserControl
#Region "Windows Form Designer generated code "
		Public Sub New()
			MyBase.New()

			'Set UI Culture
			CaptureInfo.SetThreadUILanguage(Thread.CurrentThread)

			Try
				'This call is required by the Windows Form Designer.
				InitializeComponent()
				InitUserControl()
                LogShowUserControl()
                TabStop = True
            Catch ex As Exception
                ExceptionHandler.HandleException("New Error: ", ex)
            End Try
        End Sub
        'Form overrides dispose to clean up the component list.
        Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
            If Disposing Then
                LogHideUserControl()
                TerminateUserControl()
                If Not components Is Nothing Then
                    components.Dispose()
                End If
            End If
            MyBase.Dispose(Disposing)
        End Sub
        'Required by the Windows Form Designer
        Private components As System.ComponentModel.IContainer
        Public ToolTip1 As System.Windows.Forms.ToolTip
        Friend WithEvents cmdSetCSS As System.Windows.Forms.Button
        Friend WithEvents cmdGetCSS As System.Windows.Forms.Button
        Friend WithEvents txtValueCSS As System.Windows.Forms.TextBox
        Friend WithEvents txtNameCSS As System.Windows.Forms.TextBox
        Friend WithEvents Label7 As System.Windows.Forms.Label
        Friend WithEvents Label4 As System.Windows.Forms.Label
        Friend WithEvents frmCustomStorage As System.Windows.Forms.GroupBox
        Friend WithEvents cmdShowMenu As System.Windows.Forms.Button
        Friend WithEvents cmdAddMenu As System.Windows.Forms.Button
        Friend WithEvents txtDescription As System.Windows.Forms.TextBox
        Friend WithEvents cmdError As System.Windows.Forms.Button
        Friend WithEvents txtErr1 As System.Windows.Forms.TextBox
        Friend WithEvents txtErr2 As System.Windows.Forms.TextBox
        Friend WithEvents txtErr3 As System.Windows.Forms.TextBox
        Friend WithEvents txtLineNumber As System.Windows.Forms.TextBox
        Friend WithEvents txtModule As System.Windows.Forms.TextBox
        Friend WithEvents chkFullRefresh As System.Windows.Forms.CheckBox
        Friend WithEvents chkAutoRefresh As System.Windows.Forms.CheckBox
        Friend WithEvents cmdEdit As System.Windows.Forms.Button
        Friend WithEvents cmdRefresh As System.Windows.Forms.Button
        Friend WithEvents chkCancelEvent As System.Windows.Forms.CheckBox
        Friend WithEvents listEvent As System.Windows.Forms.ListBox
        Friend WithEvents cmdTranslate As System.Windows.Forms.Button
        Friend WithEvents txtAscentCaptureValues As System.Windows.Forms.TextBox
        Friend WithEvents cmdTestReferences As System.Windows.Forms.Button
        Friend WithEvents cmdHoldReferences As System.Windows.Forms.Button
        Friend WithEvents cmdSendKeys As System.Windows.Forms.Button
        Friend WithEvents txtSendKeys As System.Windows.Forms.TextBox
        Friend WithEvents cmdContext As System.Windows.Forms.Button
        Friend WithEvents txtContext As System.Windows.Forms.TextBox
        Friend WithEvents optField As System.Windows.Forms.RadioButton
        Friend WithEvents optPage As System.Windows.Forms.RadioButton
        Friend WithEvents optDocument As System.Windows.Forms.RadioButton
        Friend WithEvents frmLifetime As System.Windows.Forms.GroupBox
        Friend WithEvents Frame3 As System.Windows.Forms.GroupBox
        Friend WithEvents Label6 As System.Windows.Forms.Label
        Friend WithEvents Label5 As System.Windows.Forms.Label
        Friend WithEvents Label3 As System.Windows.Forms.Label
        Friend WithEvents Label2 As System.Windows.Forms.Label
        Friend WithEvents E As System.Windows.Forms.Label
        Friend WithEvents Label1 As System.Windows.Forms.Label
        Friend WithEvents Frame4 As System.Windows.Forms.GroupBox
        Friend WithEvents Frame1 As System.Windows.Forms.GroupBox
        Friend WithEvents frmAscentCaptureValues As System.Windows.Forms.GroupBox
        Friend WithEvents Frame2 As System.Windows.Forms.GroupBox
        Friend WithEvents Frame5 As System.Windows.Forms.GroupBox
        Friend WithEvents frmSendKeys As System.Windows.Forms.GroupBox
        'NOTE: The following procedure is required by the Windows Form Designer
        'It can be modified using the Windows Form Designer.
        'Do not modify it using the code editor.
        Friend WithEvents TreeView1 As System.Windows.Forms.TreeView
        Friend WithEvents optCSSType8 As System.Windows.Forms.RadioButton
        Friend WithEvents optCSSType7 As System.Windows.Forms.RadioButton
        Friend WithEvents optCSSType6 As System.Windows.Forms.RadioButton
        Friend WithEvents optCSSType5 As System.Windows.Forms.RadioButton
        Friend WithEvents optCSSType4 As System.Windows.Forms.RadioButton
        Friend WithEvents optCSSType0 As System.Windows.Forms.RadioButton
        Friend WithEvents optCSSType1 As System.Windows.Forms.RadioButton
        Friend WithEvents optCSSType2 As System.Windows.Forms.RadioButton
        Friend WithEvents optCSSType3 As System.Windows.Forms.RadioButton
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
            Me.components = New System.ComponentModel.Container()
            Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(SampleUserControl))
            Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
            Me.cmdSetCSS = New System.Windows.Forms.Button()
            Me.cmdGetCSS = New System.Windows.Forms.Button()
            Me.txtValueCSS = New System.Windows.Forms.TextBox()
            Me.txtNameCSS = New System.Windows.Forms.TextBox()
            Me.optCSSType8 = New System.Windows.Forms.RadioButton()
            Me.optCSSType7 = New System.Windows.Forms.RadioButton()
            Me.optCSSType6 = New System.Windows.Forms.RadioButton()
            Me.optCSSType5 = New System.Windows.Forms.RadioButton()
            Me.optCSSType4 = New System.Windows.Forms.RadioButton()
            Me.optCSSType0 = New System.Windows.Forms.RadioButton()
            Me.optCSSType1 = New System.Windows.Forms.RadioButton()
            Me.optCSSType2 = New System.Windows.Forms.RadioButton()
            Me.optCSSType3 = New System.Windows.Forms.RadioButton()
            Me.frmCustomStorage = New System.Windows.Forms.GroupBox()
            Me.Label7 = New System.Windows.Forms.Label()
            Me.Label4 = New System.Windows.Forms.Label()
            Me.cmdShowMenu = New System.Windows.Forms.Button()
            Me.cmdAddMenu = New System.Windows.Forms.Button()
            Me.txtDescription = New System.Windows.Forms.TextBox()
            Me.cmdError = New System.Windows.Forms.Button()
            Me.txtErr1 = New System.Windows.Forms.TextBox()
            Me.txtErr2 = New System.Windows.Forms.TextBox()
            Me.txtErr3 = New System.Windows.Forms.TextBox()
            Me.txtLineNumber = New System.Windows.Forms.TextBox()
            Me.txtModule = New System.Windows.Forms.TextBox()
            Me.chkFullRefresh = New System.Windows.Forms.CheckBox()
            Me.chkAutoRefresh = New System.Windows.Forms.CheckBox()
            Me.cmdEdit = New System.Windows.Forms.Button()
            Me.cmdRefresh = New System.Windows.Forms.Button()
            Me.chkCancelEvent = New System.Windows.Forms.CheckBox()
            Me.listEvent = New System.Windows.Forms.ListBox()
            Me.cmdTranslate = New System.Windows.Forms.Button()
            Me.txtAscentCaptureValues = New System.Windows.Forms.TextBox()
            Me.cmdTestReferences = New System.Windows.Forms.Button()
            Me.cmdHoldReferences = New System.Windows.Forms.Button()
            Me.cmdSendKeys = New System.Windows.Forms.Button()
            Me.txtSendKeys = New System.Windows.Forms.TextBox()
            Me.cmdContext = New System.Windows.Forms.Button()
            Me.txtContext = New System.Windows.Forms.TextBox()
            Me.optField = New System.Windows.Forms.RadioButton()
            Me.optPage = New System.Windows.Forms.RadioButton()
            Me.optDocument = New System.Windows.Forms.RadioButton()
            Me.frmLifetime = New System.Windows.Forms.GroupBox()
            Me.Frame3 = New System.Windows.Forms.GroupBox()
            Me.TreeView1 = New System.Windows.Forms.TreeView()
            Me.Frame4 = New System.Windows.Forms.GroupBox()
            Me.Label6 = New System.Windows.Forms.Label()
            Me.Label5 = New System.Windows.Forms.Label()
            Me.Label3 = New System.Windows.Forms.Label()
            Me.Label2 = New System.Windows.Forms.Label()
            Me.E = New System.Windows.Forms.Label()
            Me.Label1 = New System.Windows.Forms.Label()
            Me.Frame1 = New System.Windows.Forms.GroupBox()
            Me.frmAscentCaptureValues = New System.Windows.Forms.GroupBox()
            Me.Frame2 = New System.Windows.Forms.GroupBox()
            Me.Frame5 = New System.Windows.Forms.GroupBox()
            Me.frmSendKeys = New System.Windows.Forms.GroupBox()
            Me.frmCustomStorage.SuspendLayout()
            Me.frmLifetime.SuspendLayout()
            Me.Frame3.SuspendLayout()
            Me.Frame4.SuspendLayout()
            Me.Frame1.SuspendLayout()
            Me.frmAscentCaptureValues.SuspendLayout()
            Me.Frame2.SuspendLayout()
            Me.Frame5.SuspendLayout()
            Me.frmSendKeys.SuspendLayout()
            Me.SuspendLayout()
            '
            'cmdSetCSS
            '
            Me.cmdSetCSS.BackColor = System.Drawing.SystemColors.Control
            Me.cmdSetCSS.Cursor = System.Windows.Forms.Cursors.Default
            resources.ApplyResources(Me.cmdSetCSS, "cmdSetCSS")
            Me.cmdSetCSS.ForeColor = System.Drawing.SystemColors.ControlText
            Me.cmdSetCSS.Name = "cmdSetCSS"
            Me.cmdSetCSS.UseVisualStyleBackColor = False
            '
            'cmdGetCSS
            '
            Me.cmdGetCSS.BackColor = System.Drawing.SystemColors.Control
            Me.cmdGetCSS.Cursor = System.Windows.Forms.Cursors.Default
            resources.ApplyResources(Me.cmdGetCSS, "cmdGetCSS")
            Me.cmdGetCSS.ForeColor = System.Drawing.SystemColors.ControlText
            Me.cmdGetCSS.Name = "cmdGetCSS"
            Me.cmdGetCSS.UseVisualStyleBackColor = False
            '
            'txtValueCSS
            '
            Me.txtValueCSS.AcceptsReturn = True
            Me.txtValueCSS.BackColor = System.Drawing.SystemColors.Window
            Me.txtValueCSS.Cursor = System.Windows.Forms.Cursors.IBeam
            resources.ApplyResources(Me.txtValueCSS, "txtValueCSS")
            Me.txtValueCSS.ForeColor = System.Drawing.SystemColors.WindowText
            Me.txtValueCSS.Name = "txtValueCSS"
            '
            'txtNameCSS
            '
            Me.txtNameCSS.AcceptsReturn = True
            Me.txtNameCSS.BackColor = System.Drawing.SystemColors.Window
            Me.txtNameCSS.Cursor = System.Windows.Forms.Cursors.IBeam
            resources.ApplyResources(Me.txtNameCSS, "txtNameCSS")
            Me.txtNameCSS.ForeColor = System.Drawing.SystemColors.WindowText
            Me.txtNameCSS.Name = "txtNameCSS"
            '
            'optCSSType8
            '
            Me.optCSSType8.BackColor = System.Drawing.SystemColors.Control
            Me.optCSSType8.Cursor = System.Windows.Forms.Cursors.Default
            resources.ApplyResources(Me.optCSSType8, "optCSSType8")
            Me.optCSSType8.ForeColor = System.Drawing.SystemColors.ControlText
            Me.optCSSType8.Name = "optCSSType8"
            Me.optCSSType8.UseVisualStyleBackColor = False
            '
            'optCSSType7
            '
            Me.optCSSType7.BackColor = System.Drawing.SystemColors.Control
            Me.optCSSType7.Cursor = System.Windows.Forms.Cursors.Default
            resources.ApplyResources(Me.optCSSType7, "optCSSType7")
            Me.optCSSType7.ForeColor = System.Drawing.SystemColors.ControlText
            Me.optCSSType7.Name = "optCSSType7"
            Me.optCSSType7.UseVisualStyleBackColor = False
            '
            'optCSSType6
            '
            Me.optCSSType6.BackColor = System.Drawing.SystemColors.Control
            Me.optCSSType6.Cursor = System.Windows.Forms.Cursors.Default
            resources.ApplyResources(Me.optCSSType6, "optCSSType6")
            Me.optCSSType6.ForeColor = System.Drawing.SystemColors.ControlText
            Me.optCSSType6.Name = "optCSSType6"
            Me.optCSSType6.UseVisualStyleBackColor = False
            '
            'optCSSType5
            '
            Me.optCSSType5.BackColor = System.Drawing.SystemColors.Control
            Me.optCSSType5.Cursor = System.Windows.Forms.Cursors.Default
            resources.ApplyResources(Me.optCSSType5, "optCSSType5")
            Me.optCSSType5.ForeColor = System.Drawing.SystemColors.ControlText
            Me.optCSSType5.Name = "optCSSType5"
            Me.optCSSType5.UseVisualStyleBackColor = False
            '
            'optCSSType4
            '
            Me.optCSSType4.BackColor = System.Drawing.SystemColors.Control
            Me.optCSSType4.Cursor = System.Windows.Forms.Cursors.Default
            resources.ApplyResources(Me.optCSSType4, "optCSSType4")
            Me.optCSSType4.ForeColor = System.Drawing.SystemColors.ControlText
            Me.optCSSType4.Name = "optCSSType4"
            Me.optCSSType4.UseVisualStyleBackColor = False
            '
            'optCSSType0
            '
            Me.optCSSType0.BackColor = System.Drawing.SystemColors.Control
            Me.optCSSType0.Checked = True
            Me.optCSSType0.Cursor = System.Windows.Forms.Cursors.Default
            resources.ApplyResources(Me.optCSSType0, "optCSSType0")
            Me.optCSSType0.ForeColor = System.Drawing.SystemColors.ControlText
            Me.optCSSType0.Name = "optCSSType0"
            Me.optCSSType0.TabStop = True
            Me.optCSSType0.UseVisualStyleBackColor = False
            '
            'optCSSType1
            '
            Me.optCSSType1.BackColor = System.Drawing.SystemColors.Control
            Me.optCSSType1.Cursor = System.Windows.Forms.Cursors.Default
            resources.ApplyResources(Me.optCSSType1, "optCSSType1")
            Me.optCSSType1.ForeColor = System.Drawing.SystemColors.ControlText
            Me.optCSSType1.Name = "optCSSType1"
            Me.optCSSType1.UseVisualStyleBackColor = False
            '
            'optCSSType2
            '
            Me.optCSSType2.BackColor = System.Drawing.SystemColors.Control
            Me.optCSSType2.Cursor = System.Windows.Forms.Cursors.Default
            resources.ApplyResources(Me.optCSSType2, "optCSSType2")
            Me.optCSSType2.ForeColor = System.Drawing.SystemColors.ControlText
            Me.optCSSType2.Name = "optCSSType2"
            Me.optCSSType2.UseVisualStyleBackColor = False
            '
            'optCSSType3
            '
            Me.optCSSType3.BackColor = System.Drawing.SystemColors.Control
            Me.optCSSType3.Cursor = System.Windows.Forms.Cursors.Default
            resources.ApplyResources(Me.optCSSType3, "optCSSType3")
            Me.optCSSType3.ForeColor = System.Drawing.SystemColors.ControlText
            Me.optCSSType3.Name = "optCSSType3"
            Me.optCSSType3.UseVisualStyleBackColor = False
            '
            'frmCustomStorage
            '
            Me.frmCustomStorage.BackColor = System.Drawing.SystemColors.Control
            Me.frmCustomStorage.Controls.Add(Me.optCSSType3)
            Me.frmCustomStorage.Controls.Add(Me.optCSSType1)
            Me.frmCustomStorage.Controls.Add(Me.optCSSType0)
            Me.frmCustomStorage.Controls.Add(Me.optCSSType2)
            Me.frmCustomStorage.Controls.Add(Me.optCSSType8)
            Me.frmCustomStorage.Controls.Add(Me.cmdSetCSS)
            Me.frmCustomStorage.Controls.Add(Me.optCSSType7)
            Me.frmCustomStorage.Controls.Add(Me.Label7)
            Me.frmCustomStorage.Controls.Add(Me.optCSSType6)
            Me.frmCustomStorage.Controls.Add(Me.cmdGetCSS)
            Me.frmCustomStorage.Controls.Add(Me.optCSSType5)
            Me.frmCustomStorage.Controls.Add(Me.Label4)
            Me.frmCustomStorage.Controls.Add(Me.optCSSType4)
            Me.frmCustomStorage.Controls.Add(Me.txtValueCSS)
            Me.frmCustomStorage.Controls.Add(Me.txtNameCSS)
            Me.frmCustomStorage.FlatStyle = System.Windows.Forms.FlatStyle.System
            resources.ApplyResources(Me.frmCustomStorage, "frmCustomStorage")
            Me.frmCustomStorage.ForeColor = System.Drawing.SystemColors.ControlText
            Me.frmCustomStorage.Name = "frmCustomStorage"
            Me.frmCustomStorage.TabStop = False
            '
            'Label7
            '
            Me.Label7.BackColor = System.Drawing.SystemColors.Control
            Me.Label7.Cursor = System.Windows.Forms.Cursors.Default
            Me.Label7.FlatStyle = System.Windows.Forms.FlatStyle.System
            resources.ApplyResources(Me.Label7, "Label7")
            Me.Label7.ForeColor = System.Drawing.SystemColors.ControlText
            Me.Label7.Name = "Label7"
            '
            'Label4
            '
            Me.Label4.BackColor = System.Drawing.SystemColors.Control
            Me.Label4.Cursor = System.Windows.Forms.Cursors.Default
            Me.Label4.FlatStyle = System.Windows.Forms.FlatStyle.System
            resources.ApplyResources(Me.Label4, "Label4")
            Me.Label4.ForeColor = System.Drawing.SystemColors.ControlText
            Me.Label4.Name = "Label4"
            '
            'cmdShowMenu
            '
            Me.cmdShowMenu.BackColor = System.Drawing.SystemColors.Control
            Me.cmdShowMenu.Cursor = System.Windows.Forms.Cursors.Default
            resources.ApplyResources(Me.cmdShowMenu, "cmdShowMenu")
            Me.cmdShowMenu.ForeColor = System.Drawing.SystemColors.ControlText
            Me.cmdShowMenu.Name = "cmdShowMenu"
            Me.cmdShowMenu.UseVisualStyleBackColor = False
            '
            'cmdAddMenu
            '
            Me.cmdAddMenu.BackColor = System.Drawing.SystemColors.Control
            Me.cmdAddMenu.Cursor = System.Windows.Forms.Cursors.Default
            resources.ApplyResources(Me.cmdAddMenu, "cmdAddMenu")
            Me.cmdAddMenu.ForeColor = System.Drawing.SystemColors.ControlText
            Me.cmdAddMenu.Name = "cmdAddMenu"
            Me.cmdAddMenu.UseVisualStyleBackColor = False
            '
            'txtDescription
            '
            Me.txtDescription.AcceptsReturn = True
            Me.txtDescription.BackColor = System.Drawing.SystemColors.Window
            Me.txtDescription.Cursor = System.Windows.Forms.Cursors.IBeam
            resources.ApplyResources(Me.txtDescription, "txtDescription")
            Me.txtDescription.ForeColor = System.Drawing.SystemColors.WindowText
            Me.txtDescription.Name = "txtDescription"
            '
            'cmdError
            '
            Me.cmdError.BackColor = System.Drawing.SystemColors.Control
            Me.cmdError.Cursor = System.Windows.Forms.Cursors.Default
            resources.ApplyResources(Me.cmdError, "cmdError")
            Me.cmdError.ForeColor = System.Drawing.SystemColors.ControlText
            Me.cmdError.Name = "cmdError"
            Me.cmdError.UseVisualStyleBackColor = False
            '
            'txtErr1
            '
            Me.txtErr1.AcceptsReturn = True
            Me.txtErr1.BackColor = System.Drawing.SystemColors.Window
            Me.txtErr1.Cursor = System.Windows.Forms.Cursors.IBeam
            resources.ApplyResources(Me.txtErr1, "txtErr1")
            Me.txtErr1.ForeColor = System.Drawing.SystemColors.WindowText
            Me.txtErr1.Name = "txtErr1"
            '
            'txtErr2
            '
            Me.txtErr2.AcceptsReturn = True
            Me.txtErr2.BackColor = System.Drawing.SystemColors.Window
            Me.txtErr2.Cursor = System.Windows.Forms.Cursors.IBeam
            resources.ApplyResources(Me.txtErr2, "txtErr2")
            Me.txtErr2.ForeColor = System.Drawing.SystemColors.WindowText
            Me.txtErr2.Name = "txtErr2"
            '
            'txtErr3
            '
            Me.txtErr3.AcceptsReturn = True
            Me.txtErr3.BackColor = System.Drawing.SystemColors.Window
            Me.txtErr3.Cursor = System.Windows.Forms.Cursors.IBeam
            resources.ApplyResources(Me.txtErr3, "txtErr3")
            Me.txtErr3.ForeColor = System.Drawing.SystemColors.WindowText
            Me.txtErr3.Name = "txtErr3"
            '
            'txtLineNumber
            '
            Me.txtLineNumber.AcceptsReturn = True
            Me.txtLineNumber.BackColor = System.Drawing.SystemColors.Window
            Me.txtLineNumber.Cursor = System.Windows.Forms.Cursors.IBeam
            resources.ApplyResources(Me.txtLineNumber, "txtLineNumber")
            Me.txtLineNumber.ForeColor = System.Drawing.SystemColors.WindowText
            Me.txtLineNumber.Name = "txtLineNumber"
            '
            'txtModule
            '
            Me.txtModule.AcceptsReturn = True
            Me.txtModule.BackColor = System.Drawing.SystemColors.Window
            Me.txtModule.Cursor = System.Windows.Forms.Cursors.IBeam
            resources.ApplyResources(Me.txtModule, "txtModule")
            Me.txtModule.ForeColor = System.Drawing.SystemColors.WindowText
            Me.txtModule.Name = "txtModule"
            '
            'chkFullRefresh
            '
            Me.chkFullRefresh.BackColor = System.Drawing.SystemColors.Control
            Me.chkFullRefresh.Cursor = System.Windows.Forms.Cursors.Default
            resources.ApplyResources(Me.chkFullRefresh, "chkFullRefresh")
            Me.chkFullRefresh.ForeColor = System.Drawing.SystemColors.ControlText
            Me.chkFullRefresh.Name = "chkFullRefresh"
            Me.chkFullRefresh.UseVisualStyleBackColor = False
            '
            'chkAutoRefresh
            '
            Me.chkAutoRefresh.BackColor = System.Drawing.SystemColors.Control
            Me.chkAutoRefresh.Checked = True
            Me.chkAutoRefresh.CheckState = System.Windows.Forms.CheckState.Checked
            Me.chkAutoRefresh.Cursor = System.Windows.Forms.Cursors.Default
            resources.ApplyResources(Me.chkAutoRefresh, "chkAutoRefresh")
            Me.chkAutoRefresh.ForeColor = System.Drawing.SystemColors.ControlText
            Me.chkAutoRefresh.Name = "chkAutoRefresh"
            Me.chkAutoRefresh.UseVisualStyleBackColor = False
            '
            'cmdEdit
            '
            Me.cmdEdit.BackColor = System.Drawing.SystemColors.Control
            Me.cmdEdit.Cursor = System.Windows.Forms.Cursors.Default
            resources.ApplyResources(Me.cmdEdit, "cmdEdit")
            Me.cmdEdit.ForeColor = System.Drawing.SystemColors.ControlText
            Me.cmdEdit.Name = "cmdEdit"
            Me.cmdEdit.UseVisualStyleBackColor = False
            '
            'cmdRefresh
            '
            Me.cmdRefresh.BackColor = System.Drawing.SystemColors.Control
            Me.cmdRefresh.Cursor = System.Windows.Forms.Cursors.Default
            resources.ApplyResources(Me.cmdRefresh, "cmdRefresh")
            Me.cmdRefresh.ForeColor = System.Drawing.SystemColors.ControlText
            Me.cmdRefresh.Name = "cmdRefresh"
            Me.cmdRefresh.UseVisualStyleBackColor = False
            '
            'chkCancelEvent
            '
            Me.chkCancelEvent.BackColor = System.Drawing.SystemColors.Control
            Me.chkCancelEvent.Cursor = System.Windows.Forms.Cursors.Default
            resources.ApplyResources(Me.chkCancelEvent, "chkCancelEvent")
            Me.chkCancelEvent.ForeColor = System.Drawing.SystemColors.ControlText
            Me.chkCancelEvent.Name = "chkCancelEvent"
            Me.chkCancelEvent.UseVisualStyleBackColor = False
            '
            'listEvent
            '
            Me.listEvent.BackColor = System.Drawing.SystemColors.Window
            Me.listEvent.Cursor = System.Windows.Forms.Cursors.Default
            resources.ApplyResources(Me.listEvent, "listEvent")
            Me.listEvent.ForeColor = System.Drawing.SystemColors.WindowText
            Me.listEvent.Name = "listEvent"
            '
            'cmdTranslate
            '
            Me.cmdTranslate.BackColor = System.Drawing.SystemColors.Control
            Me.cmdTranslate.Cursor = System.Windows.Forms.Cursors.Default
            resources.ApplyResources(Me.cmdTranslate, "cmdTranslate")
            Me.cmdTranslate.ForeColor = System.Drawing.SystemColors.ControlText
            Me.cmdTranslate.Name = "cmdTranslate"
            Me.cmdTranslate.UseVisualStyleBackColor = False
            '
            'txtAscentCaptureValues
            '
            Me.txtAscentCaptureValues.AcceptsReturn = True
            Me.txtAscentCaptureValues.BackColor = System.Drawing.SystemColors.Window
            Me.txtAscentCaptureValues.Cursor = System.Windows.Forms.Cursors.IBeam
            resources.ApplyResources(Me.txtAscentCaptureValues, "txtAscentCaptureValues")
            Me.txtAscentCaptureValues.ForeColor = System.Drawing.SystemColors.WindowText
            Me.txtAscentCaptureValues.Name = "txtAscentCaptureValues"
            '
            'cmdTestReferences
            '
            Me.cmdTestReferences.BackColor = System.Drawing.SystemColors.Control
            Me.cmdTestReferences.Cursor = System.Windows.Forms.Cursors.Default
            resources.ApplyResources(Me.cmdTestReferences, "cmdTestReferences")
            Me.cmdTestReferences.ForeColor = System.Drawing.SystemColors.ControlText
            Me.cmdTestReferences.Name = "cmdTestReferences"
            Me.cmdTestReferences.UseVisualStyleBackColor = False
            '
            'cmdHoldReferences
            '
            Me.cmdHoldReferences.BackColor = System.Drawing.SystemColors.Control
            Me.cmdHoldReferences.Cursor = System.Windows.Forms.Cursors.Default
            resources.ApplyResources(Me.cmdHoldReferences, "cmdHoldReferences")
            Me.cmdHoldReferences.ForeColor = System.Drawing.SystemColors.ControlText
            Me.cmdHoldReferences.Name = "cmdHoldReferences"
            Me.cmdHoldReferences.UseVisualStyleBackColor = False
            '
            'cmdSendKeys
            '
            Me.cmdSendKeys.BackColor = System.Drawing.SystemColors.Control
            Me.cmdSendKeys.Cursor = System.Windows.Forms.Cursors.Default
            resources.ApplyResources(Me.cmdSendKeys, "cmdSendKeys")
            Me.cmdSendKeys.ForeColor = System.Drawing.SystemColors.ControlText
            Me.cmdSendKeys.Name = "cmdSendKeys"
            Me.cmdSendKeys.UseVisualStyleBackColor = False
            '
            'txtSendKeys
            '
            Me.txtSendKeys.AcceptsReturn = True
            Me.txtSendKeys.BackColor = System.Drawing.SystemColors.Window
            Me.txtSendKeys.Cursor = System.Windows.Forms.Cursors.IBeam
            resources.ApplyResources(Me.txtSendKeys, "txtSendKeys")
            Me.txtSendKeys.ForeColor = System.Drawing.SystemColors.WindowText
            Me.txtSendKeys.Name = "txtSendKeys"
            '
            'cmdContext
            '
            Me.cmdContext.BackColor = System.Drawing.SystemColors.Control
            Me.cmdContext.Cursor = System.Windows.Forms.Cursors.Default
            resources.ApplyResources(Me.cmdContext, "cmdContext")
            Me.cmdContext.ForeColor = System.Drawing.SystemColors.ControlText
            Me.cmdContext.Name = "cmdContext"
            Me.cmdContext.UseVisualStyleBackColor = False
            '
            'txtContext
            '
            Me.txtContext.AcceptsReturn = True
            Me.txtContext.BackColor = System.Drawing.SystemColors.Window
            Me.txtContext.Cursor = System.Windows.Forms.Cursors.IBeam
            resources.ApplyResources(Me.txtContext, "txtContext")
            Me.txtContext.ForeColor = System.Drawing.SystemColors.WindowText
            Me.txtContext.Name = "txtContext"
            '
            'optField
            '
            Me.optField.BackColor = System.Drawing.SystemColors.Control
            Me.optField.Cursor = System.Windows.Forms.Cursors.Default
            resources.ApplyResources(Me.optField, "optField")
            Me.optField.ForeColor = System.Drawing.SystemColors.ControlText
            Me.optField.Name = "optField"
            Me.optField.UseVisualStyleBackColor = False
            '
            'optPage
            '
            Me.optPage.BackColor = System.Drawing.SystemColors.Control
            Me.optPage.Cursor = System.Windows.Forms.Cursors.Default
            resources.ApplyResources(Me.optPage, "optPage")
            Me.optPage.ForeColor = System.Drawing.SystemColors.ControlText
            Me.optPage.Name = "optPage"
            Me.optPage.UseVisualStyleBackColor = False
            '
            'optDocument
            '
            Me.optDocument.BackColor = System.Drawing.SystemColors.Control
            Me.optDocument.Cursor = System.Windows.Forms.Cursors.Default
            resources.ApplyResources(Me.optDocument, "optDocument")
            Me.optDocument.ForeColor = System.Drawing.SystemColors.ControlText
            Me.optDocument.Name = "optDocument"
            Me.optDocument.UseVisualStyleBackColor = False
            '
            'frmLifetime
            '
            Me.frmLifetime.BackColor = System.Drawing.SystemColors.Control
            Me.frmLifetime.Controls.Add(Me.cmdHoldReferences)
            Me.frmLifetime.Controls.Add(Me.cmdTestReferences)
            Me.frmLifetime.FlatStyle = System.Windows.Forms.FlatStyle.System
            resources.ApplyResources(Me.frmLifetime, "frmLifetime")
            Me.frmLifetime.ForeColor = System.Drawing.SystemColors.ControlText
            Me.frmLifetime.Name = "frmLifetime"
            Me.frmLifetime.TabStop = False
            '
            'Frame3
            '
            Me.Frame3.BackColor = System.Drawing.SystemColors.Control
            Me.Frame3.Controls.Add(Me.TreeView1)
            Me.Frame3.Controls.Add(Me.cmdEdit)
            Me.Frame3.Controls.Add(Me.chkFullRefresh)
            Me.Frame3.Controls.Add(Me.chkAutoRefresh)
            Me.Frame3.Controls.Add(Me.cmdRefresh)
            Me.Frame3.FlatStyle = System.Windows.Forms.FlatStyle.System
            resources.ApplyResources(Me.Frame3, "Frame3")
            Me.Frame3.ForeColor = System.Drawing.SystemColors.ControlText
            Me.Frame3.Name = "Frame3"
            Me.Frame3.TabStop = False
            '
            'TreeView1
            '
            resources.ApplyResources(Me.TreeView1, "TreeView1")
            Me.TreeView1.Name = "TreeView1"
            '
            'Frame4
            '
            Me.Frame4.BackColor = System.Drawing.SystemColors.Control
            Me.Frame4.Controls.Add(Me.Label6)
            Me.Frame4.Controls.Add(Me.Label5)
            Me.Frame4.Controls.Add(Me.Label3)
            Me.Frame4.Controls.Add(Me.Label2)
            Me.Frame4.Controls.Add(Me.E)
            Me.Frame4.Controls.Add(Me.txtErr3)
            Me.Frame4.Controls.Add(Me.txtErr2)
            Me.Frame4.Controls.Add(Me.txtErr1)
            Me.Frame4.Controls.Add(Me.Label1)
            Me.Frame4.Controls.Add(Me.cmdError)
            Me.Frame4.Controls.Add(Me.txtModule)
            Me.Frame4.Controls.Add(Me.txtLineNumber)
            Me.Frame4.Controls.Add(Me.txtDescription)
            Me.Frame4.FlatStyle = System.Windows.Forms.FlatStyle.System
            resources.ApplyResources(Me.Frame4, "Frame4")
            Me.Frame4.ForeColor = System.Drawing.SystemColors.ControlText
            Me.Frame4.Name = "Frame4"
            Me.Frame4.TabStop = False
            '
            'Label6
            '
            Me.Label6.BackColor = System.Drawing.SystemColors.Control
            Me.Label6.Cursor = System.Windows.Forms.Cursors.Default
            Me.Label6.FlatStyle = System.Windows.Forms.FlatStyle.System
            resources.ApplyResources(Me.Label6, "Label6")
            Me.Label6.ForeColor = System.Drawing.SystemColors.ControlText
            Me.Label6.Name = "Label6"
            '
            'Label5
            '
            Me.Label5.BackColor = System.Drawing.SystemColors.Control
            Me.Label5.Cursor = System.Windows.Forms.Cursors.Default
            Me.Label5.FlatStyle = System.Windows.Forms.FlatStyle.System
            resources.ApplyResources(Me.Label5, "Label5")
            Me.Label5.ForeColor = System.Drawing.SystemColors.ControlText
            Me.Label5.Name = "Label5"
            '
            'Label3
            '
            Me.Label3.BackColor = System.Drawing.SystemColors.Control
            Me.Label3.Cursor = System.Windows.Forms.Cursors.Default
            Me.Label3.FlatStyle = System.Windows.Forms.FlatStyle.System
            resources.ApplyResources(Me.Label3, "Label3")
            Me.Label3.ForeColor = System.Drawing.SystemColors.ControlText
            Me.Label3.Name = "Label3"
            '
            'Label2
            '
            Me.Label2.BackColor = System.Drawing.SystemColors.Control
            Me.Label2.Cursor = System.Windows.Forms.Cursors.Default
            Me.Label2.FlatStyle = System.Windows.Forms.FlatStyle.System
            resources.ApplyResources(Me.Label2, "Label2")
            Me.Label2.ForeColor = System.Drawing.SystemColors.ControlText
            Me.Label2.Name = "Label2"
            '
            'E
            '
            Me.E.BackColor = System.Drawing.SystemColors.Control
            Me.E.Cursor = System.Windows.Forms.Cursors.Default
            Me.E.FlatStyle = System.Windows.Forms.FlatStyle.System
            resources.ApplyResources(Me.E, "E")
            Me.E.ForeColor = System.Drawing.SystemColors.ControlText
            Me.E.Name = "E"
            '
            'Label1
            '
            Me.Label1.BackColor = System.Drawing.SystemColors.Control
            Me.Label1.Cursor = System.Windows.Forms.Cursors.Default
            Me.Label1.FlatStyle = System.Windows.Forms.FlatStyle.System
            resources.ApplyResources(Me.Label1, "Label1")
            Me.Label1.ForeColor = System.Drawing.SystemColors.ControlText
            Me.Label1.Name = "Label1"
            '
            'Frame1
            '
            Me.Frame1.BackColor = System.Drawing.SystemColors.Control
            Me.Frame1.Controls.Add(Me.listEvent)
            Me.Frame1.Controls.Add(Me.chkCancelEvent)
            Me.Frame1.FlatStyle = System.Windows.Forms.FlatStyle.System
            resources.ApplyResources(Me.Frame1, "Frame1")
            Me.Frame1.ForeColor = System.Drawing.SystemColors.ControlText
            Me.Frame1.Name = "Frame1"
            Me.Frame1.TabStop = False
            '
            'frmAscentCaptureValues
            '
            Me.frmAscentCaptureValues.BackColor = System.Drawing.SystemColors.Control
            Me.frmAscentCaptureValues.Controls.Add(Me.cmdTranslate)
            Me.frmAscentCaptureValues.Controls.Add(Me.txtAscentCaptureValues)
            Me.frmAscentCaptureValues.FlatStyle = System.Windows.Forms.FlatStyle.System
            resources.ApplyResources(Me.frmAscentCaptureValues, "frmAscentCaptureValues")
            Me.frmAscentCaptureValues.ForeColor = System.Drawing.SystemColors.ControlText
            Me.frmAscentCaptureValues.Name = "frmAscentCaptureValues"
            Me.frmAscentCaptureValues.TabStop = False
            '
            'Frame2
            '
            Me.Frame2.BackColor = System.Drawing.SystemColors.Control
            Me.Frame2.Controls.Add(Me.txtContext)
            Me.Frame2.Controls.Add(Me.cmdContext)
            Me.Frame2.Controls.Add(Me.optDocument)
            Me.Frame2.Controls.Add(Me.optPage)
            Me.Frame2.Controls.Add(Me.optField)
            Me.Frame2.FlatStyle = System.Windows.Forms.FlatStyle.System
            resources.ApplyResources(Me.Frame2, "Frame2")
            Me.Frame2.ForeColor = System.Drawing.SystemColors.ControlText
            Me.Frame2.Name = "Frame2"
            Me.Frame2.TabStop = False
            '
            'Frame5
            '
            Me.Frame5.BackColor = System.Drawing.SystemColors.Control
            Me.Frame5.Controls.Add(Me.cmdAddMenu)
            Me.Frame5.Controls.Add(Me.cmdShowMenu)
            Me.Frame5.FlatStyle = System.Windows.Forms.FlatStyle.System
            resources.ApplyResources(Me.Frame5, "Frame5")
            Me.Frame5.ForeColor = System.Drawing.SystemColors.ControlText
            Me.Frame5.Name = "Frame5"
            Me.Frame5.TabStop = False
            '
            'frmSendKeys
            '
            Me.frmSendKeys.BackColor = System.Drawing.SystemColors.Control
            Me.frmSendKeys.Controls.Add(Me.txtSendKeys)
            Me.frmSendKeys.Controls.Add(Me.cmdSendKeys)
            Me.frmSendKeys.FlatStyle = System.Windows.Forms.FlatStyle.System
            resources.ApplyResources(Me.frmSendKeys, "frmSendKeys")
            Me.frmSendKeys.ForeColor = System.Drawing.SystemColors.ControlText
            Me.frmSendKeys.Name = "frmSendKeys"
            Me.frmSendKeys.TabStop = False
            '
            'SampleUserControl
            '
            Me.Controls.Add(Me.frmCustomStorage)
            Me.Controls.Add(Me.frmLifetime)
            Me.Controls.Add(Me.Frame3)
            Me.Controls.Add(Me.Frame4)
            Me.Controls.Add(Me.Frame1)
            Me.Controls.Add(Me.frmAscentCaptureValues)
            Me.Controls.Add(Me.Frame2)
            Me.Controls.Add(Me.Frame5)
            Me.Controls.Add(Me.frmSendKeys)
            resources.ApplyResources(Me, "$this")
            Me.Name = "SampleUserControl"
            Me.frmCustomStorage.ResumeLayout(False)
            Me.frmCustomStorage.PerformLayout()
            Me.frmLifetime.ResumeLayout(False)
            Me.Frame3.ResumeLayout(False)
            Me.Frame4.ResumeLayout(False)
            Me.Frame4.PerformLayout()
            Me.Frame1.ResumeLayout(False)
            Me.frmAscentCaptureValues.ResumeLayout(False)
            Me.frmAscentCaptureValues.PerformLayout()
            Me.Frame2.ResumeLayout(False)
            Me.Frame2.PerformLayout()
            Me.Frame5.ResumeLayout(False)
            Me.frmSendKeys.ResumeLayout(False)
            Me.frmSendKeys.PerformLayout()
            Me.ResumeLayout(False)

        End Sub
#End Region
        '********************************************************************************
        '***
        '*** Module:    SampleUserControl
        '*** Purpose:   OCX that tests all events, methods and properties
        '***            exposed by Ascent Capture
        '***
        '*** (c) Copyright 2006 Kofax Image Products.
        '*** All rights reserved.
        '***
        '********************************************************************************


        '*** The InteropServices.Application provides the base of the
        '*** Ascent Capture OLE Automation Hierarchy.
        Private m_oApp As InteropServices.Application

        '*** 
        '*** Current document, folder , page, and field numbers
        '*** 

        Private m_nDocumentNumber As Short
        Private m_nFolderNumber As Short
        Private m_nPageNumber As Short
        Private m_nFieldNumber As Short

        '*** Sequence number to keep tree keys different
        Private m_nNodeKeySeq As Short

        '*** Maximum elements in event list
        Private Const m_lMaxListSize As Integer = 200

        '*** Divider character for keys - Set when we init properties
        Private m_strKeyChar As String

        '*** Remember if we have ascent capture features
        Private m_bHasAscentCaptureFeatures As Boolean

        '*** 
        '*** Held object references to test object lifetime
        '*** 

        Private m_oHeldBatch As InteropServices.Batch
        Private m_oHeldDocuments As InteropServices.Documents
        Private m_oHeldDocument As InteropServices.Document
        Private m_oHeldPages As InteropServices.Pages
        Private m_oHeldPage As InteropServices.Page
        Private m_oHeldFields As InteropServices.IndexFields
        Private m_oHeldField As InteropServices.IndexField
        Private m_oHeldCustomProperties As InteropServices.CustomProperties
        Private m_oHeldCustomProperty As InteropServices.CustomProperty
        Private m_oHeldSuggestedValues As InteropServices.SuggestedValues
        Private m_oHeldSuggestedValue As InteropServices.SuggestedValue

        '*** We need to remember all of the menu items
        Dim m_oMenuCollection As MenuCollection

        '**************************************************
        '*** Function:  Application
        '*** Purpose:   Sets the application object - Base of hierarchy
        '*** Input:     none
        '*** Output:    none
        '**************************************************
        Public WriteOnly Property Application() As InteropServices.Application
            Set(ByVal Value As InteropServices.Application)
                Try
                    m_oApp = Value

                    '*** Add the menus to test with.
                    AddOcxTestMenu()
                    AddOcxBatchEditMenu()
                    AddOcxBatchControlMenu()

                    '*** See if we are actually running with Ascent Capture or some derivitive product
                    m_bHasAscentCaptureFeatures = m_oApp.HasAscentCaptureFeatures

                    '*** Modify UI if we aren't running AC
                    If Not m_bHasAscentCaptureFeatures Then
                        frmAscentCaptureValues.Enabled = False
                        optField.Enabled = False
                    End If
                Catch ex As Exception
                    ExceptionHandler.HandleException("ApplicationError Error: ", ex)
                End Try
            End Set
        End Property

        '**************************************************
        '*** Function:  ActionEvent
        '*** Purpose:   Receive each action event, respond by
        '***            adding the event to the listbox
        '*** Input:     nActionNumber - number assigned to
        '***                            event
        '*** Output:    vArgument - currently NOT used
        '***            pnCancel - Response to the event.
        '***                       Only DocumentClosing and
        '***                       FieldExiting process the response
        '*** Return:    ActionEvent returned is currently ignored.
        '**************************************************
        Public Function ActionEvent(ByVal nActionNumber As Short, ByRef vArgument As Object, ByRef pnCancel As Short) As Short

            Dim strActionEvent As String '*** Text to display for action event

            '*** Set the return values
            pnCancel = 0
            ActionEvent = 0

            '*** Get the document, folder , page and field indexes
            m_nDocumentNumber = 0
            m_nFolderNumber = 0
            m_nPageNumber = 0
            m_nFieldNumber = 0

            Using oActiveBatchWrap As New ApiObjectWrapper(Of InteropServices.Batch)(m_oApp.ActiveBatch)

                '*** 
                '*** The following code may fail, but the values will be left to 0 when caught
                '*** 
                If Not oActiveBatchWrap.IsNull Then

                    Try
                        Using oActiveFolderWrap As New ApiObjectWrapper(Of InteropServices.Folder)(oActiveBatchWrap.WrappedObject.ActiveFolder)
                            If Not oActiveFolderWrap.IsNull Then
                                m_nFolderNumber = oActiveFolderWrap.WrappedObject.OrderNumber
                            End If
                        End Using
                    Catch ex As Exception
                        m_nFolderNumber = 0
                    End Try

                    Using oActiveDocWrap As New ApiObjectWrapper(Of InteropServices.Document)(oActiveBatchWrap.WrappedObject.ActiveDocument)

                        If Not oActiveDocWrap.IsNull Then
                            m_nDocumentNumber = oActiveDocWrap.WrappedObject.OrderNumber

                            Using oActivePageWrap As New ApiObjectWrapper(Of InteropServices.Page)(oActiveDocWrap.WrappedObject.ActivePage)
                                If Not oActivePageWrap.IsNull Then
                                    m_nPageNumber = oActivePageWrap.WrappedObject.OrderNumber
                                End If
                            End Using

                            If m_bHasAscentCaptureFeatures Then
                                ' SPR 76462 - Error with document operations of SampleOCX.
                                Using oFormTypeWrap As New ApiObjectWrapper(Of InteropServices.FormType)(oActiveDocWrap.WrappedObject.FormType)
                                    If Not oFormTypeWrap.IsNull Then
                                        Using oActiveIndexFieldWrap As New ApiObjectWrapper(Of InteropServices.IndexField)(oActiveDocWrap.WrappedObject.ActiveIndexField)
                                            If Not oActiveIndexFieldWrap.IsNull Then
                                                m_nFieldNumber = oActiveIndexFieldWrap.WrappedObject.OrderNumber
                                            End If
                                        End Using
                                    End If
                                End Using
                            End If
                        End If
                    End Using
                End If
            End Using
            '*** 
            '*** Display some text for each action event
            '*** 

            Try
                Select Case nActionNumber

                    '*** 
                    '*** Batch Events
                    '*** 

                    Case InteropServices.KfxOcxEvent.KfxOcxEventBatchCreating
                        strActionEvent = "Batch Creating"
                        pnCancel = CancelEvent(strActionEvent)

                    Case InteropServices.KfxOcxEvent.KfxOcxEventBatchOpened
                        strActionEvent = "Batch Opened"

                    Case InteropServices.KfxOcxEvent.KfxOcxEventBatchClosing
                        strActionEvent = "Batch Closing"
                        pnCancel = CancelEvent(strActionEvent)

                    Case InteropServices.KfxOcxEvent.KfxOcxEventBatchRejecting
                        strActionEvent = "Batch Rejecting"
                        pnCancel = CancelEvent(strActionEvent)

                    Case InteropServices.KfxOcxEvent.KfxOcxEventBatchSuspending
                        strActionEvent = "Batch Suspending"
                        pnCancel = CancelEvent(strActionEvent)

                    Case InteropServices.KfxOcxEvent.KfxOcxEventBatchDeleting
                        strActionEvent = "Batch Deleting"
                        pnCancel = CancelEvent(strActionEvent)

                    Case InteropServices.KfxOcxEvent.KfxOcxEventBatchOpeningNext
                        strActionEvent = "Batch Opening Next"
                        pnCancel = CancelEvent(strActionEvent)

                    Case InteropServices.KfxOcxEvent.KfxOcxEventBatchOpeningSelect
                        strActionEvent = "Batch Opening Select"
                        pnCancel = CancelEvent(strActionEvent)

                    Case InteropServices.KfxOcxEvent.KfxOcxEventBatchOpeningID
                        strActionEvent = "Batch Opening ID"
                        pnCancel = CancelEvent(strActionEvent)

                    Case InteropServices.KfxOcxEvent.KfxOcxEventBatchOpeningCheck
                        '*** Check to see if any batches can be opened when opening
                        '*** in Scan - Otherwise, we will go directly to the new batch dialog
                        strActionEvent = "Batch Opening Check"
                        pnCancel = CancelEvent(strActionEvent)

                    Case InteropServices.KfxOcxEvent.KfxOcxEventBatchPropertiesDisplaying
                        strActionEvent = "Batch Properties"
                        pnCancel = CancelEvent(strActionEvent)

                        '*** 
                        '*** Documents
                        '*** 

                    Case InteropServices.KfxOcxEvent.KfxOcxEventDocumentOpened
                        strActionEvent = "Document " & m_nDocumentNumber & " Opened"

                    Case InteropServices.KfxOcxEvent.KfxOcxEventDocumentValidating
                        strActionEvent = "Document " & m_nDocumentNumber & " Validating"
                        pnCancel = CancelEvent(strActionEvent)

                    Case InteropServices.KfxOcxEvent.KfxOcxEventDocumentClosing
                        strActionEvent = "Document " & m_nDocumentNumber & " Closing"
                        pnCancel = CancelEvent(strActionEvent)

                        '*** 
                        '*** Folders
                        '*** 

                    Case InteropServices.KfxOcxEvent.KfxOcxEventFolderOpened
                        strActionEvent = "Folder " & m_nFolderNumber & " Opened"

                    Case InteropServices.KfxOcxEvent.KfxOcxEventFolderValidating
                        strActionEvent = "Folder " & m_nFolderNumber & " Validating"
                        pnCancel = CancelEvent(strActionEvent)

                    Case InteropServices.KfxOcxEvent.KfxOcxEventFolderClosing
                        strActionEvent = "Folder " & m_nFolderNumber & " Closing"
                        pnCancel = CancelEvent(strActionEvent)

                        '*** 
                        '*** Fields
                        '*** 

                    Case InteropServices.KfxOcxEvent.KfxOcxEventFieldEntered
                        strActionEvent = "Field " & m_nFieldNumber & " Entered"

                    Case InteropServices.KfxOcxEvent.KfxOcxEventFieldExiting
                        strActionEvent = "Field " & m_nFieldNumber & " Exiting"
                        pnCancel = CancelEvent(strActionEvent)

                        '*** 
                        '*** Content/Context change
                        '*** 

                    Case InteropServices.KfxOcxEvent.KfxOcxEventContextChanged
                        strActionEvent = "Context Changed ( Document " & m_nDocumentNumber & ", Folder " & m_nFolderNumber & ", Page " & m_nPageNumber & ", Field " & m_nFieldNumber & " )"
                        RefreshTree()

                    Case InteropServices.KfxOcxEvent.KfxOcxEventPropertyChanged
                        strActionEvent = "Property Changed"
                        RefreshTree()

                    Case InteropServices.KfxOcxEvent.KfxOcxEventContentChanged
                        strActionEvent = "Content Changed"
                        RefreshTree()

                        '*** 
                        '*** Batch Edit/Data Entry
                        '*** 

                    Case InteropServices.KfxOcxEvent.KfxOcxEventBatchEditModeEntered
                        strActionEvent = "Batch Edit Mode Entered"
                        RefreshTree()

                    Case InteropServices.KfxOcxEvent.KfxOcxEventDataEntryModeEntered
                        strActionEvent = "Data Entry Mode Entered"
                        RefreshTree()

                        '*** 
                        '*** Scan start/stop
                        '*** 

                    Case InteropServices.KfxOcxEvent.KfxOcxEventScanBatchStarted
                        strActionEvent = "Started Scanning Pages"

                    Case InteropServices.KfxOcxEvent.KfxOcxEventScanPageStarted
                        strActionEvent = "Started Scanning One Page"

                    Case InteropServices.KfxOcxEvent.KfxOcxEventScanStopped
                        strActionEvent = "Scanning Complete"
                        RefreshTree()

                        '*** 
                        '*** Error logging event
                        '*** 

                    Case InteropServices.KfxOcxEvent.KfxOcxEventErrorLogging
                        LogEvent("Error Logging")
                        LogEvent("Err1=" & Convert.ToString(vArgument(1)) & " Err2=" & Convert.ToString(vArgument(2)) & " Err3=" & Convert.ToString(vArgument(3)))
                        LogEvent("ErrorMessage=" & Convert.ToString(vArgument(4)))
                        LogEvent("CodeModule=" & Convert.ToString(vArgument(5)) & " LineNumber=" & Convert.ToInt32(vArgument(6)))

                        strActionEvent = "Error Logging"

                        pnCancel = CancelEvent(strActionEvent)

                        '*** 
                        '*** Dialogs
                        '*** 

                    Case InteropServices.KfxOcxEvent.KfxOcxEventAboutBoxDisplaying
                        strActionEvent = "About Box Displaying"
                        pnCancel = CancelEvent(strActionEvent)

                        '*** 
                        '*** Logging In
                        '*** 

                    Case InteropServices.KfxOcxEvent.KfxOcxEventLoggingIn
                        strActionEvent = "Logging In"
                        '*** For now, we don't actually invoke the login because
                        '*** it makes demonstration of this application annoying.
                        '*** Uncomment the following lines to see a login example.
                        'If Not LogIn() Then
                        'pnCancel = 1
                        'End If

                        '*** 
                        '*** Logging out
                        '*** 

                    Case InteropServices.KfxOcxEvent.KfxOcxEventLoggedOut
                        strActionEvent = "Logged Out"
                        '*** We don't do anything special with this event in the sample

                        '*** 
                        '*** Menu clicked event
                        '*** 

                    Case InteropServices.KfxOcxEvent.KfxOcxEventMenuClicked

                        '*** Special menus that must be added to registry.
                        '*** To test this add "ShowMe" as a EventText

                        If vArgument = "ShowMe" Then
                            m_oApp.ShowWindow(True)
                        End If

                        '*** To test this add "HideMe" as a EventText
                        If vArgument = "HideMe" Then
                            m_oApp.ShowWindow(False)
                        End If

                        '*** To test this add "ShowDialog" as a EventText
                        If vArgument = "ShowDialog" Then
                            MsgBox("Sample Dialog", MsgBoxStyle.OkOnly, "My Dialog")
                        End If

                        If InStr(vArgument, "BatchEdit.") Then
                            Call BatchEditEvent(vArgument)
                            RefreshTree()
                        End If

                        If InStr(vArgument, "BatchControl.") Then
                            Call BatchControlEvent(vArgument)
                            RefreshTree()
                        End If


                        strActionEvent = "Menu Clicked (EventText = " & vArgument & " )"
                    Case InteropServices.KfxOcxEvent.KfxOcxEventAppThemeChanged

                        Dim oColor As InteropServices.IRGB = m_oApp.Theme.BackgroundColor
                        Me.BackColor = Drawing.Color.FromArgb(oColor.Red, oColor.Green, oColor.Blue)

                        strActionEvent = "Theme changed"
                    Case Else '*** Other values.
                        strActionEvent = "Unknown ActionEvent " & nActionNumber
                End Select

                '*** Add the event to our log
                LogEvent(strActionEvent)
            Catch ex As Exception
                ExceptionHandler.HandleException("ActionEvent Error: ", ex)
            End Try
        End Function

        '**************************************************
        '*** Function:  LogIn
        '*** Purpose:   Display LogIn dialog
        '*** Input:     none
        '*** Output:    none
        '*** Return:    TRUE-login OK, FALSE-don't login
        '**************************************************
        Public Function LogIn() As Boolean

            Dim oLoginForm As LoginForm

            Try
                oLoginForm = New LoginForm
                LogIn = True ' initialize return

                '*** Show the form modally
                oLoginForm.ShowDialog(Me)

                '*** Exit if cancel
                If Not oLoginForm.OK Then
                    LogIn = False
                End If
            Catch ex As Exception
                Throw
            Finally
                If Not IsNothing(oLoginForm) Then
                    oLoginForm.Dispose()
                    oLoginForm = Nothing
                End If
            End Try

        End Function

        '**************************************************
        '*** Function:  AddOcxBatchEditMenu
        '*** Purpose:   Initialize the batch edit ocx menu
        '*** Input:     none
        '*** Output:    none
        '**************************************************
        Public Sub AddOcxBatchEditMenu()

            Try
                Dim strLocation As String
                Dim strMenuBarText As String
                Dim strEventName As String
                Dim strMenuText As String

                strLocation = "MenuBar"
                strMenuBarText = "O&cxBatchEditing"

                strMenuText = "&Import file..."
                strEventName = "BatchEdit.ImportFile"
                AddMenu(strEventName, strMenuText, strLocation, strMenuBarText)

                strMenuText = "&Delete page"
                strEventName = "BatchEdit.DeletePage"
                AddMenu(strEventName, strMenuText, strLocation, strMenuBarText)

                strMenuText = "Move page to &loose..."
                strEventName = "BatchEdit.MovePageToLoose"
                AddMenu(strEventName, strMenuText, strLocation, strMenuBarText)

                strMenuText = "Move page to &document..."
                strEventName = "BatchEdit.MovePageToDocument"
                AddMenu(strEventName, strMenuText, strLocation, strMenuBarText)

                strMenuText = "&Create document"
                strEventName = "BatchEdit.CreateDocument"
                AddMenu(strEventName, strMenuText, strLocation, strMenuBarText)

                strMenuText = "Insert document"
                strEventName = "BatchEdit.InsertDocument"
                AddMenu(strEventName, strMenuText, strLocation, strMenuBarText)

                strMenuText = "D&elete document"
                strEventName = "BatchEdit.DeleteDocument"
                AddMenu(strEventName, strMenuText, strLocation, strMenuBarText)

                strMenuText = "Move document to batch..."
                strEventName = "BatchEdit.MoveDocumentToBatch"
                AddMenu(strEventName, strMenuText, strLocation, strMenuBarText)

                strMenuText = "Move document to folder..."
                strEventName = "BatchEdit.MoveDocumentToFolder"
                AddMenu(strEventName, strMenuText, strLocation, strMenuBarText)

                strMenuText = "Create &folder"
                strEventName = "BatchEdit.CreateFolder"
                AddMenu(strEventName, strMenuText, strLocation, strMenuBarText)

                strMenuText = "Delete f&older"
                strEventName = "BatchEdit.DeleteFolder"
                AddMenu(strEventName, strMenuText, strLocation, strMenuBarText)

                strMenuText = "Move folder to batch..."
                strEventName = "BatchEdit.MoveFolderToBatch"
                AddMenu(strEventName, strMenuText, strLocation, strMenuBarText)

                strMenuText = "Move folder to folder..."
                strEventName = "BatchEdit.MoveFolderToFolder"
                AddMenu(strEventName, strMenuText, strLocation, strMenuBarText)
            Catch ex As Exception
                ExceptionHandler.HandleException("AddOcxBatchEditMenu Error: ", ex)
            End Try

        End Sub

        '**************************************************
        '*** Function:  AddOcxBatchControlMenu
        '*** Purpose:   Initialize the batch control ocx menu
        '*** Input:     none
        '*** Output:    none
        '**************************************************
        Public Sub AddOcxBatchControlMenu()

            Try
                Dim strLocation As String
                Dim strMenuBarText As String
                Dim strEventName As String
                Dim strMenuText As String

                strLocation = "MenuBar"
                strMenuBarText = "Oc&xBatchControl"

                strMenuText = "&Create batch..."
                strEventName = "BatchControl.CreateBatch"
                AddMenu(strEventName, strMenuText, strLocation, strMenuBarText)

                strMenuText = "&Delete batch"
                strEventName = "BatchControl.DeleteBatch"
                AddMenu(strEventName, strMenuText, strLocation, strMenuBarText)

                strMenuText = "&Suspend batch"
                strEventName = "BatchControl.SuspendBatch"
                AddMenu(strEventName, strMenuText, strLocation, strMenuBarText)

                strMenuText = "C&lose batch"
                strEventName = "BatchControl.CloseBatch"
                AddMenu(strEventName, strMenuText, strLocation, strMenuBarText)

                strMenuText = "&Reject batch..."
                strEventName = "BatchControl.RejectBatch"
                AddMenu(strEventName, strMenuText, strLocation, strMenuBarText)
            Catch ex As Exception
                ExceptionHandler.HandleException("AddOcxBatchControlMenu Error: ", ex)
            End Try

        End Sub

        '**************************************************
        '*** Function:  HandleBatchEditImportFile
        '*** Purpose:   Handle Import File command
        '*** Input:     none
        '*** Output:    none
        '**************************************************
        Private Sub HandleBatchEditImportFile()

            '*** 
            '*** Get the parameters
            '*** 

            Using frmEntry As New DataEntryForm
                frmEntry.EntryCaption = "Enter file name:"
                frmEntry.Value = "c:\test.tif"
                frmEntry.ShowDialog(Me)

                If Not frmEntry.OK Then Exit Sub

                '*** 
                '*** Do the import
                '*** 
                Using oActiveBatch As New ApiObjectWrapper(Of InteropServices.Batch)(m_oApp.ActiveBatch)
                    Using oInsertPages As New ApiObjectWrapper(Of InteropServices.Pages)(oActiveBatch.WrappedObject.ImportFile(frmEntry.Value))

                        '*** Check the results
                        Dim strMsg As String
                        strMsg = "Created " & Convert.ToString(oInsertPages.WrappedObject.Count) & " page(s). ( ID's ="

                        For Each oInsertPage As InteropServices.Page In oInsertPages.WrappedObject
                            Using oPage As New ApiObjectWrapper(Of InteropServices.Page)(oInsertPage)
                                strMsg = strMsg & " " & Convert.ToString(oPage.WrappedObject.ID)
                            End Using
                        Next

                        strMsg = strMsg & " )"
                        MsgBox(strMsg)
                    End Using
                End Using
            End Using
        End Sub

        '**************************************************
        '*** Function:  HandleBatchEditMovePageToLoose
        '*** Purpose:   Handle Move Page To Loose command
        '*** Input:     none
        '*** Output:    none
        '**************************************************
        Private Sub HandleBatchEditMovePageToLoose()

            Dim oInsertPage As InteropServices.Page = Nothing
            Try
                '*** 
                '*** Get the current page
                '*** 
                Dim oPage As InteropServices.Page = GetActivePage()
                If IsNothing(oPage) Then
                    MsgBox("No active page.")
                    Exit Sub
                End If

                Using oPageWrapper As New ApiObjectWrapper(Of InteropServices.Page)(oPage)
                    '*** 
                    '*** Get the parameters
                    '*** 
                    Dim oIndex As Integer = 0
                    Using frmEntry As DataEntryForm = New DataEntryForm
                        frmEntry.EntryCaption = "Enter order number of page before which to insert or 0 to append:"
                        frmEntry.Value = ""
                        frmEntry.ShowDialog(Me)
                        If Not frmEntry.OK Then Exit Sub
                        oIndex = Convert.ToInt32(frmEntry.Value)
                    End Using

                    Using oActiveBatch As InteropServices.Batch = m_oApp.ActiveBatch
                        Using oLoosePagesWrap As New ApiObjectWrapper(Of InteropServices.Pages)(oActiveBatch.LoosePages)
                            If Not oLoosePagesWrap.IsNull Then
                                oInsertPage = oLoosePagesWrap.WrappedObject.Item(oIndex)
                            End If
                        End Using
                        '*** Do it
                        oPageWrapper.WrappedObject.MoveToLoose(oInsertPage)
                    End Using
                End Using
            Catch ex As Exception
                Throw
            Finally

                If Not IsNothing(oInsertPage) Then
                    oInsertPage.Dispose()
                    oInsertPage = Nothing
                End If
            End Try

        End Sub

        '**************************************************
        '*** Function:  HandleBatchEditMovePageToDocument
        '*** Purpose:   Handle Move Page To Document command
        '*** Input:     none
        '*** Output:    none
        '**************************************************
        Private Sub HandleBatchEditMovePageToDocument()


            Dim oInsertPage As InteropServices.Page

            Try
                '*** 
                '*** Get the current page
                '*** 
                Using oPageWrap As New ApiObjectWrapper(Of InteropServices.Page)(GetActivePage())
                    If oPageWrap.IsNull Then
                        MsgBox("No active page.")
                        Exit Sub
                    Else

                        '*** 
                        '*** Get the parameters
                        '*** 
                        Dim oInsertDoc As InteropServices.Document

                        Dim oIndex As Integer = 0
                        Using frmEntry As New DataEntryForm
                            frmEntry.EntryCaption = "Enter document order number:"
                            frmEntry.Value = ""
                            frmEntry.ShowDialog(Me)
                            If Not frmEntry.OK Then Exit Sub
                            oIndex = Convert.ToInt32(frmEntry.Value)
                        End Using

                        Using oActiveBatch As New ApiObjectWrapper(Of InteropServices.Batch)(m_oApp.ActiveBatch)
                            Try
                                '*** 
                                '*** Get the document
                                '*** 
                                Using oDocCollWrap As New ApiObjectWrapper(Of InteropServices.Documents)(oActiveBatch.WrappedObject.Documents)
                                    If Not oDocCollWrap.IsNull Then
                                        oInsertDoc = oDocCollWrap.WrappedObject.Item(oIndex)
                                    End If
                                End Using
                            Catch ex As Exception
                                oInsertDoc = Nothing
                            End Try
                        End Using

                        If IsNothing(oInsertDoc) Then
                            MsgBox("Document not found.")
                            Exit Sub
                        End If

                        Using frmEntry As New DataEntryForm
                            frmEntry.EntryCaption = "Enter order number of page before which to insert or 0 to append:"
                            frmEntry.Value = ""
                            frmEntry.ShowDialog(Me)
                            If Not frmEntry.OK Then Exit Sub
                            oIndex = Convert.ToInt32(frmEntry.Value)
                        End Using

                        Try
                            '*** 
                            '*** Get the page
                            '*** 
                            Using oPageCollWrap As New ApiObjectWrapper(Of InteropServices.Pages)(oInsertDoc.Pages)
                                If Not oPageCollWrap.IsNull Then
                                    oInsertPage = oPageCollWrap.WrappedObject.Item(oIndex)
                                End If
                            End Using
                        Catch ex As Exception
                            oInsertPage = Nothing
                        End Try

                        oPageWrap.WrappedObject.MoveToDocument(oInsertDoc, oInsertPage)
                    End If
                End Using
            Catch ex As Exception
                Throw
            Finally
                If Not IsNothing(oInsertPage) Then
                    oInsertPage.Dispose()
                    oInsertPage = Nothing
                End If
            End Try

        End Sub

        '**************************************************
        '*** Function:  HandleBatchEditDeletePage
        '*** Purpose:   Handle Delete Page command
        '*** Input:     none
        '*** Output:    none
        '**************************************************
        Private Sub HandleBatchEditDeletePage()

            Using oPageWrap As New ApiObjectWrapper(Of InteropServices.Page)(GetActivePage())
                If oPageWrap.IsNull Then
                    MsgBox("No active page.")
                    Exit Sub
                Else
                    Using oActiveBatch As New ApiObjectWrapper(Of InteropServices.Batch)(m_oApp.ActiveBatch)
                        oActiveBatch.WrappedObject.DeletePage(oPageWrap.WrappedObject)
                    End Using
                End If
            End Using
        End Sub

        '**************************************************
        '*** Function:  HandleBatchEditCreateDocument
        '*** Purpose:   Handle Create Document command
        '*** Input:     none
        '*** Output:    none
        '**************************************************
        Private Sub HandleBatchEditCreateDocument()

            Using oActiveBatch As New ApiObjectWrapper(Of InteropServices.Batch)(m_oApp.ActiveBatch)
                Using oInsertDocWrap As New ApiObjectWrapper(Of InteropServices.Document)(oActiveBatch.WrappedObject.CreateDocument())
                    If Not oInsertDocWrap.IsNull Then
                        MsgBox("Created document ID " & Convert.ToString(oInsertDocWrap.WrappedObject.ID))
                    End If
                End Using
            End Using
        End Sub

        '**************************************************
        '*** Function:  HandleBatchEditInsertDocument
        '*** Purpose:   Handle Insert Document command
        '*** Input:     none
        '*** Output:    none
        '**************************************************
        Private Sub HandleBatchEditInsertDocument()
            Using oActiveBatch As InteropServices.Batch = m_oApp.ActiveBatch
                Using oDocWrap As New ApiObjectWrapper(Of InteropServices.Document)(oActiveBatch.ActiveDocument)
                    If oDocWrap.IsNull Then
                        MsgBox("No active document.")
                        Exit Sub
                    Else
                        Using oInsertDocWrap As New ApiObjectWrapper(Of InteropServices.Document)(oActiveBatch.CreateDocument(oDocWrap.WrappedObject))
                            MsgBox("Created document ID " & Convert.ToString(oInsertDocWrap.WrappedObject.ID))
                        End Using
                    End If
                End Using
            End Using
        End Sub

        '**************************************************
        '*** Function:  HandleBatchEditDeleteDocument
        '*** Purpose:   Handle Delete Document command
        '*** Input:     none
        '*** Output:    none
        '**************************************************
        Private Sub HandleBatchEditDeleteDocument()
            Using oActiveBatch As New ApiObjectWrapper(Of InteropServices.Batch)(m_oApp.ActiveBatch)
                Using oDocWrap As New ApiObjectWrapper(Of InteropServices.Document)(oActiveBatch.WrappedObject.ActiveDocument)
                    If oDocWrap.IsNull Then
                        MsgBox("No active document.")
                        Exit Sub
                    Else
                        oActiveBatch.WrappedObject.DeleteDocument(oDocWrap.WrappedObject)
                    End If
                End Using
            End Using
        End Sub

        '**************************************************
        '*** Function:  HandleBatchEditMoveDocumentToBatch
        '*** Purpose:   Handle Move Document To Batch command
        '*** Input:     none
        '*** Output:    none
        '**************************************************
        Private Sub HandleBatchEditMoveDocumentToBatch()

            Dim oInsertDoc As InteropServices.Document
            Try
                Using oActiveBatch As New ApiObjectWrapper(Of InteropServices.Batch)(m_oApp.ActiveBatch)
                    '*** 
                    '*** Get the current document
                    '*** 
                    Using oDocWrap As New ApiObjectWrapper(Of InteropServices.Document)(oActiveBatch.WrappedObject.ActiveDocument)
                        If oDocWrap.IsNull Then
                            MsgBox("No active document.")
                            Exit Sub
                        Else
                            '*** 
                            '*** Get the parameters
                            '*** 
                            Using frmEntry As New DataEntryForm
                                frmEntry.EntryCaption = "Enter order number of document before which to insert or 0 to append:"
                                frmEntry.Value = ""
                                frmEntry.ShowDialog(Me)
                                If Not frmEntry.OK Then Exit Sub
                                Dim oIndex As Integer = Convert.ToInt32(frmEntry.Value)
                                If oIndex <> 0 And Len(frmEntry.Value) <> 0 Then
                                    Using oDocumentCollWrap As New ApiObjectWrapper(Of InteropServices.Documents)(oActiveBatch.WrappedObject.Documents)
                                        If Not oDocumentCollWrap.IsNull Then
                                            oInsertDoc = oDocumentCollWrap.WrappedObject.Item(oIndex)
                                        End If
                                    End Using
                                End If
                            End Using

                            '*** Do it
                            oDocWrap.WrappedObject.MoveToBatch(oInsertDoc)
                        End If
                    End Using
                End Using
            Catch
                Throw
            Finally
                If Not IsNothing(oInsertDoc) Then
                    oInsertDoc.Dispose()
                    oInsertDoc = Nothing
                End If
            End Try
        End Sub

        '**************************************************
        '*** Function:  HandleBatchEditMoveDocumentToFolder
        '*** Purpose:   Handle Move Document To Folder command
        '*** Input:     none
        '*** Output:    none
        '**************************************************
        Private Sub HandleBatchEditMoveDocumentToFolder()

            Dim oFolder As InteropServices.Folder = Nothing
            Dim oInsertDoc As InteropServices.Document

            Try
                Using oActiveBatch As New ApiObjectWrapper(Of InteropServices.Batch)(m_oApp.ActiveBatch)
                    '*** 
                    '*** Get the current document
                    '*** 

                    Using oDocWrap As New ApiObjectWrapper(Of InteropServices.Document)(oActiveBatch.WrappedObject.ActiveDocument)
                        If oDocWrap.IsNull Then
                            MsgBox("No active document.")
                            Exit Sub
                        Else

                            '*** 
                            '*** Get the parameters
                            '***
                            Dim oIndex As Integer = 0
                            Using frmEntry As New DataEntryForm
                                frmEntry.EntryCaption = "Enter folder ID where the document will be moved to:"
                                frmEntry.Value = ""
                                frmEntry.ShowDialog(Me)
                                If Not frmEntry.OK Then Exit Sub
                                oIndex = Convert.ToInt32(frmEntry.Value)
                                Using oFoldersWrap As New ApiObjectWrapper(Of InteropServices.Folders)(oActiveBatch.WrappedObject.Folders)
                                    If Not oFoldersWrap.IsNull Then
                                        oFolder = FindFolderByID(oFoldersWrap.WrappedObject, oIndex)
                                    End If
                                End Using
                            End Using

                            If IsNothing(oFolder) Then
                                MsgBox(String.Format("Folder ID: {0} not found.", oIndex))
                                Exit Sub
                            End If

                            Using frmEntry As New DataEntryForm
                                frmEntry.EntryCaption = "Enter order number of document before which to insert or 0 to append:"
                                frmEntry.Value = ""
                                frmEntry.ShowDialog(Me)
                                If Not frmEntry.OK Then Exit Sub
                                oIndex = Convert.ToInt32(frmEntry.Value)
                                If oIndex <> 0 And Len(frmEntry.Value) <> 0 Then
                                    Using oDocumentsWrap As New ApiObjectWrapper(Of InteropServices.Documents)(oFolder.Documents)
                                        If Not oDocumentsWrap.IsNull Then
                                            oInsertDoc = oDocumentsWrap.WrappedObject.Item(oIndex)
                                        End If
                                    End Using
                                End If
                            End Using

                            '*** Do it
                            oDocWrap.WrappedObject.MoveToFolder(oFolder, oInsertDoc)
                        End If
                    End Using
                End Using
            Catch ex As Exception
                Throw
            Finally
                If Not IsNothing(oFolder) Then
                    oFolder.Dispose()
                    oFolder = Nothing
                End If
                If Not IsNothing(oInsertDoc) Then
                    oInsertDoc.Dispose()
                    oInsertDoc = Nothing
                End If
            End Try
        End Sub

        '**************************************************
        '*** Function:  HandleBatchEditCreateFolder
        '*** Purpose:   Handle Create Folder command
        '*** Input:     none
        '*** Output:    none
        '**************************************************
        Private Sub HandleBatchEditCreateFolder()

            Using oActiveBatch As New ApiObjectWrapper(Of InteropServices.Batch)(m_oApp.ActiveBatch)
                Using oInsertFolder As InteropServices.Folder = oActiveBatch.WrappedObject.CreateFolder
                    MsgBox("Created folder ID " & Convert.ToString(oInsertFolder.ID))
                End Using
            End Using
        End Sub

        '**************************************************
        '*** Function:  HandleBatchEditDeleteFolder
        '*** Purpose:   Handle Delete Folder command
        '*** Input:     none
        '*** Output:    none
        '**************************************************
        Private Sub HandleBatchEditDeleteFolder()

            Using oActiveBatch As New ApiObjectWrapper(Of InteropServices.Batch)(m_oApp.ActiveBatch)
                Using oFolderWrap As New ApiObjectWrapper(Of InteropServices.Folder)(oActiveBatch.WrappedObject.ActiveFolder)
                    If oFolderWrap.IsNull Then
                        MsgBox("No active folder.")
                        Exit Sub
                    Else
                        m_oApp.ActiveBatch.DeleteFolder(oFolderWrap.WrappedObject)
                    End If
                End Using
            End Using
        End Sub

        '**************************************************
        '*** Function:  HandleBatchEditMoveFolderToBatch
        '*** Purpose:   Handle Move Folder To Batch command
        '*** Input:     none
        '*** Output:    none
        '**************************************************
        Private Sub HandleBatchEditMoveFolderToBatch()

            Dim oFolder As InteropServices.Folder = Nothing
            Dim oInsertFolder As InteropServices.Folder = Nothing

            Try
                Using oActiveBatch As New ApiObjectWrapper(Of InteropServices.Batch)(m_oApp.ActiveBatch)
                    '*** 
                    '*** Get the current folder
                    '*** 

                    Using oFolderWrap As New ApiObjectWrapper(Of InteropServices.Folder)(oActiveBatch.WrappedObject.ActiveFolder)
                        If oFolderWrap.IsNull Then
                            MsgBox("No active folder.")
                            Exit Sub
                        Else

                            '*** 
                            '*** Get the parameters
                            '*** 
                            Dim bValidEntry As Boolean
                            bValidEntry = False
                            Dim oIndex As Integer = 0
                            Using frmEntry As New DataEntryForm
                                frmEntry.EntryCaption = "Enter order number of folder before which to insert or 0 to append:"
                                frmEntry.Value = ""
                                frmEntry.ShowDialog(Me)
                                If Not frmEntry.OK Then Exit Sub
                                oIndex = Convert.ToInt32(frmEntry.Value)
                                If oIndex <> 0 And Len(frmEntry.Value) <> 0 Then
                                    bValidEntry = True
                                    Using oFoldersWrap As New ApiObjectWrapper(Of InteropServices.Folders)(oActiveBatch.WrappedObject.Folders)
                                        If Not oFoldersWrap.IsNull Then
                                            oInsertFolder = FindFolderByOrderID(oFoldersWrap.WrappedObject, oIndex)
                                        End If
                                    End Using
                                End If
                            End Using

                            If bValidEntry And IsNothing(oInsertFolder) Then
                                MsgBox(String.Format("Folder Order Number: {0} not found.", oIndex))
                                Exit Sub
                            End If

                            '*** Do it
                            oFolder.MoveToBatch(oInsertFolder)
                        End If
                    End Using
                End Using
            Catch ex As Exception
                Throw
            Finally
                If Not IsNothing(oFolder) Then
                    oFolder.Dispose()
                    oFolder = Nothing
                End If
                If Not IsNothing(oInsertFolder) Then
                    oInsertFolder.Dispose()
                    oInsertFolder = Nothing
                End If
            End Try

        End Sub

        '**************************************************
        '*** Function:  HandleBatchEditMoveFolderToFolder
        '*** Purpose:   Handle Move Folder To Folder command
        '*** Input:     none
        '*** Output:    none
        '**************************************************
        Private Sub HandleBatchEditMoveFolderToFolder()


            Dim oTargetFolder As InteropServices.Folder = Nothing
            Dim oInsertFolder As InteropServices.Folder = Nothing

            Try
                Using oActiveBatch As New ApiObjectWrapper(Of InteropServices.Batch)(m_oApp.ActiveBatch)
                    '*** 
                    '*** Get the current folder
                    '*** 
                    Using oFolderWrap As New ApiObjectWrapper(Of InteropServices.Folder)(oActiveBatch.WrappedObject.ActiveFolder)
                        If oFolderWrap.IsNull Then
                            MsgBox("No active folder.")
                            Exit Sub
                        Else

                            '*** 
                            '*** Get the parameters
                            '*** 
                            Dim oIndex As Integer = 0
                            Using frmEntry As New DataEntryForm
                                frmEntry.EntryCaption = "Enter folder ID where the folder will be moved to:"
                                frmEntry.Value = ""
                                frmEntry.ShowDialog(Me)
                                If Not frmEntry.OK Then Exit Sub
                                oIndex = Convert.ToInt32(frmEntry.Value)
                                Dim oFolders As New ApiObjectWrapper(Of InteropServices.Folders)(oActiveBatch.WrappedObject.Folders)
                                Using oFolders
                                    If Not oFolders.IsNull Then
                                        oTargetFolder = FindFolderByID(oFolders.WrappedObject, oIndex)
                                    End If
                                End Using
                            End Using

                            If IsNothing(oTargetFolder) Then
                                MsgBox(String.Format("Folder ID: {0} not found.", oIndex))
                                Exit Sub
                            End If

                            Dim bValidEntry As Boolean
                            bValidEntry = False

                            Using frmEntry As New DataEntryForm
                                frmEntry.EntryCaption = "Enter order number of folder before which to insert or 0 to append:"
                                frmEntry.Value = ""
                                frmEntry.ShowDialog(Me)
                                If Not frmEntry.OK Then Exit Sub
                                oIndex = Convert.ToInt32(frmEntry.Value)
                                If oIndex <> 0 And Len(frmEntry.Value) <> 0 Then
                                    bValidEntry = True
                                    Using oFoldersWrap As New ApiObjectWrapper(Of InteropServices.Folders)(oTargetFolder.Folders)
                                        If Not oFoldersWrap.IsNull Then
                                            oInsertFolder = FindFolderByOrderID(oFoldersWrap.WrappedObject, oIndex)
                                        End If
                                    End Using
                                End If
                            End Using

                            If bValidEntry And IsNothing(oInsertFolder) Then
                                MsgBox(String.Format("Folder Order Number: {0} not found.", oIndex))
                                Exit Sub
                            End If
                            '*** Do it
                            oFolderWrap.WrappedObject.MoveToFolder(oTargetFolder, oInsertFolder)
                        End If
                    End Using
                End Using
            Catch ex As Exception
                Throw
            Finally
                If Not IsNothing(oTargetFolder) Then
                    oTargetFolder.Dispose()
                    oTargetFolder = Nothing
                End If
                If Not IsNothing(oInsertFolder) Then
                    oInsertFolder.Dispose()
                    oInsertFolder = Nothing
                End If
            End Try

        End Sub

        '**************************************************
        '*** Function:  BatchEditEvent
        '*** Purpose:   Handle batch edit commands
        '*** Input:     none
        '*** Output:    none
        '**************************************************
        Public Sub BatchEditEvent(ByVal strEvent As String)

            Try
                Using oActiveBatchWrap As New ApiObjectWrapper(Of InteropServices.Batch)(m_oApp.ActiveBatch)
                    If oActiveBatchWrap.IsNull Then
                        MsgBox("No Active Batch")
                        Exit Sub
                    End If
                End Using

                Select Case strEvent
                    Case "BatchEdit.ImportFile"
                        HandleBatchEditImportFile()

                    Case "BatchEdit.MovePageToLoose"
                        HandleBatchEditMovePageToLoose()

                    Case "BatchEdit.MovePageToDocument"
                        HandleBatchEditMovePageToDocument()

                    Case "BatchEdit.DeletePage"
                        HandleBatchEditDeletePage()

                    Case "BatchEdit.CreateDocument"
                        HandleBatchEditCreateDocument()

                    Case "BatchEdit.InsertDocument"
                        HandleBatchEditInsertDocument()

                    Case "BatchEdit.DeleteDocument"
                        HandleBatchEditDeleteDocument()

                    Case "BatchEdit.MoveDocumentToBatch"
                        HandleBatchEditMoveDocumentToBatch()

                    Case "BatchEdit.MoveDocumentToFolder"
                        HandleBatchEditMoveDocumentToFolder()

                    Case "BatchEdit.CreateFolder"
                        HandleBatchEditCreateFolder()

                    Case "BatchEdit.DeleteFolder"
                        HandleBatchEditDeleteFolder()

                    Case "BatchEdit.MoveFolderToBatch"
                        HandleBatchEditMoveFolderToBatch()

                    Case "BatchEdit.MoveFolderToFolder"
                        HandleBatchEditMoveFolderToFolder()
                End Select
            Catch ex As Exception
                ExceptionHandler.HandleException("BatchEditEvent Error: " & strEvent, ex)
            End Try

        End Sub

        '**************************************************
        '*** Function:  BatchControlCreateBatch
        '*** Purpose:   Handle batch Create command
        '*** Input:     none
        '*** Output:    none
        '**************************************************
        Private Sub BatchControlCreateBatch()

            Dim oBatchClass As InteropServices.BatchClass = Nothing
            Dim oBatch As InteropServices.Batch = Nothing

            Try
                '*** 
                '*** Get the batch class
                '*** 
                Using oBatchClassesWrap As New ApiObjectWrapper(Of InteropServices.BatchClasses)(m_oApp.BatchClasses)
                    If Not oBatchClassesWrap.IsNull Then
                        Using frmEntry As New DataEntryForm
                            frmEntry.EntryCaption = "Enter batch class name:"
                            frmEntry.Value = ""
                            frmEntry.ShowDialog(Me)
                            If Not frmEntry.OK Then Exit Sub
                            oBatchClass = oBatchClassesWrap.WrappedObject.Item(frmEntry.Value)
                        End Using

                        If IsNothing(oBatchClass) Then
                            MsgBox("Batch class not found.")
                            Exit Sub
                        End If

                        '*** 
                        '*** Get the name
                        '***

                        Dim strBatchName As String

                        Using frmEntry As New DataEntryForm
                            frmEntry.EntryCaption = "Enter batch name (or blank to generate a name):"
                            frmEntry.Value = ""
                            frmEntry.ShowDialog(Me)
                            If Not frmEntry.OK Then Exit Sub
                            strBatchName = frmEntry.Value
                        End Using
                        oBatch = m_oApp.CreateBatch(oBatchClass, strBatchName)
                        MsgBox("Created batch name " & oBatch.Name)
                    End If
                End Using
            Catch ex As Exception
                Throw
            Finally

                If Not IsNothing(oBatchClass) Then
                    Using (oBatchClass)
                    End Using
                    oBatchClass = Nothing
                End If
                If Not IsNothing(oBatch) Then
                    Using (oBatch)
                    End Using
                    oBatch = Nothing
                End If
            End Try

        End Sub

        '**************************************************
        '*** Function:  BatchControlDeleteBatch
        '*** Purpose:   Handle batch Delete command
        '*** Input:     none
        '*** Output:    none
        '**************************************************
        Private Sub BatchControlDeleteBatch()

            Try
                m_oApp.DeleteBatch()
            Catch ex As Exception
                Throw
            End Try

        End Sub

        '**************************************************
        '*** Function:  BatchControlSuspendBatch
        '*** Purpose:   Handle batch Suspend command
        '*** Input:     none
        '*** Output:    none
        '**************************************************
        Private Sub BatchControlSuspendBatch()

            Try
                m_oApp.SuspendBatch()
            Catch ex As Exception
                Throw
            End Try

        End Sub

        '**************************************************
        '*** Function:  BatchControlCloseBatch
        '*** Purpose:   Handle batch Close command
        '*** Input:     none
        '*** Output:    none
        '**************************************************
        Private Sub BatchControlCloseBatch()

            Try
                m_oApp.CloseBatch()
            Catch ex As Exception
                Throw
            End Try

        End Sub

        '**************************************************
        '*** Function:  BatchControlRejectBatch
        '*** Purpose:   Handle batch Reject command
        '*** Input:     none
        '*** Output:    none
        '**************************************************
        Private Sub BatchControlRejectBatch()

            Using frmEntry As New DataEntryForm
                '*** Get rejection message
                frmEntry.EntryCaption = "Enter rejection message:"
                frmEntry.Value = ""
                frmEntry.ShowDialog(Me)
                If Not frmEntry.OK Then Exit Sub
                m_oApp.RejectBatch(frmEntry.Value)
            End Using

        End Sub

        '**************************************************
        '*** Function:  BatchControlEvent
        '*** Purpose:   Handle batch control commands
        '*** Input:     none
        '*** Output:    none
        '**************************************************
        Public Sub BatchControlEvent(ByVal strEvent As String)

            Try
                Select Case strEvent
                    Case "BatchControl.CreateBatch"
                        BatchControlCreateBatch()

                    Case "BatchControl.DeleteBatch"
                        BatchControlDeleteBatch()

                    Case "BatchControl.SuspendBatch"
                        BatchControlSuspendBatch()

                    Case "BatchControl.CloseBatch"
                        BatchControlCloseBatch()

                    Case "BatchControl.RejectBatch"
                        BatchControlRejectBatch()
                End Select
            Catch ex As Exception
                ExceptionHandler.HandleException("BatchControlEvent Error: " & strEvent, ex)
            End Try

        End Sub

        '**************************************************
        '*** Function:  GetActivePage
        '*** Purpose:   Return the currently active loose or document page
        '*** Input:     none
        '*** Output:    none
        '**************************************************
        Private Function GetActivePage() As InteropServices.Page

            Dim oPage As InteropServices.Page = Nothing

            Using oActiveBatch As New ApiObjectWrapper(Of InteropServices.Batch)(m_oApp.ActiveBatch)
                oPage = oActiveBatch.WrappedObject.ActiveLoosePage

                If IsNothing(oPage) Then
                    Using oDocWrap As New ApiObjectWrapper(Of InteropServices.Document)(oActiveBatch.WrappedObject.ActiveDocument)
                        If Not oDocWrap.IsNull Then
                            oPage = oDocWrap.WrappedObject.ActivePage
                        End If
                    End Using
                End If
            End Using
            Return oPage

        End Function

        '**************************************************
        '*** Function:  AddOcxTestMenu
        '*** Purpose:   Initialize the default text ocx menu
        '***            Put up:
        '***               Show Me
        '***               Hide Me
        '***               Show Dialog
        '*** Input:     none
        '*** Output:    none
        '**************************************************
        Public Sub AddOcxTestMenu()

            Try
                Dim strLocation As String
                Dim strMenuBarText As String
                Dim strEventName As String
                Dim strMenuText As String

                strLocation = "MenuBar"
                strMenuBarText = "&OcxTest"

                '*** Add Show Me menu item
                strMenuText = "&Show Me"
                strEventName = "ShowMe"

                AddMenu(strEventName, strMenuText, strLocation, strMenuBarText)

                '*** Add Hide Me menu item
                strMenuText = "&Hide Me"
                strEventName = "HideMe"

                AddMenu(strEventName, strMenuText, strLocation, strMenuBarText)

                '*** Add Show Dialog menu item
                strMenuText = "Show &Dialog"
                strEventName = "ShowDialog"

                AddMenu(strEventName, strMenuText, strLocation, strMenuBarText)
            Catch ex As Exception
                ExceptionHandler.HandleException("AddOcxTestMenu Error: ", ex)
            End Try

        End Sub

        '**************************************************
        '*** Function:  Add menu
        '*** Purpose:   Add menus for testing. Add it to current OCX
        '***            and to menu collection
        '*** Input:     strEventName  - text returned to control when
        '***                            the menu item is clicked
        '***            strMenuText  - text that is displayed
        '***            strLocation  - location for text display
        '***            strMenuBarText  - MenuBar text, if on menubar.
        '*** Output:    none
        '**************************************************
        Public Sub AddMenu(ByRef strEventName As String, ByRef strMenuText As String, ByRef strLocation As String, ByRef strMenuBarText As String)

            Try
                Dim oMenuItem As MenuItem
                m_oApp.AddMenu(strEventName, strMenuText, strLocation, strMenuBarText)

                oMenuItem = New MenuItem
                oMenuItem.strName = strEventName
                oMenuItem.strMenu = strMenuText
                oMenuItem.strLocation = strLocation
                oMenuItem.strMenuBarText = strMenuBarText

                '*** Added menus are always shown by default
                oMenuItem.lState = InteropServices.KfxShowMenu.KfxMenuShow
                m_oMenuCollection.Add(oMenuItem)
            Catch ex As Exception
                ExceptionHandler.HandleException("AddMenu Error: ", ex)
            End Try

        End Sub


        '**************************************************
        '*** Function:  LogEvent
        '*** Purpose:   Logs an event to our UI log
        '*** Input:     none
        '*** Output:    none
        '**************************************************
        Private Sub LogEvent(ByRef strEvent As String)

            '*** Clean out the list if it is too long
            If listEvent.Items.Count > m_lMaxListSize Then
                '*** Delete the first item to scroll up if we over-flowed
                listEvent.Items.RemoveAt(0)
            End If

            '*** Add to the list log
            listEvent.Items.Add(strEvent)

            '*** Scroll to bottom
            listEvent.SelectedIndex = listEvent.Items.Count - 1
            listEvent.SelectedIndex = -1

        End Sub

        '**************************************************
        '*** Function:  CancelEvent
        '*** Purpose:   Returns 1 if we should cancel the event
        '*** Input:     none
        '*** Output:    Returns 1 if we should cancel the event
        '**************************************************
        Private Function CancelEvent(ByVal strEvent As String) As Short

            CancelEvent = 0
            Dim vbResult As MsgBoxResult

            If (chkCancelEvent.CheckState = System.Windows.Forms.CheckState.Checked) Then
                vbResult = MsgBox("Do you want to Cancel the event: (" & strEvent & ")?", MsgBoxStyle.YesNo)
                If (vbResult = MsgBoxResult.Yes) Then
                    CancelEvent = 1
                End If
            End If

        End Function

        '**************************************************
        '*** Function:  RefreshTree
        '*** Purpose:   Refresh the tree if auto-refresh is on - Otherwise, clear it
        '*** Input:     none
        '*** Output:    none
        '**************************************************
        Private Sub RefreshTree()

            If chkAutoRefresh.CheckState = System.Windows.Forms.CheckState.Checked Then
                FillTree()
            Else
                TreeView1.Nodes.Clear()
            End If

        End Sub

        '**************************************************
        '*** Function:  FillTree
        '*** Purpose:   Using the InteropServices.Application
        '***            display all of the data in a tree control
        '*** Input:     none
        '*** Output:    none
        '**************************************************
        Private Sub FillTree()

            Try
                '*** Clear the tree
                TreeView1.Nodes.Clear()

                '*** Reset the tree sequence number
                ResetKeySequence()

                '*** Add application node at root
                Dim root As TreeNode
                root = TreeView1.Nodes.Add("Application")

                '*** Display the application hierarchy
                ShowAppProperties(root, m_oApp)
            Catch ex As Exception
                ExceptionHandler.HandleException("RefreshTree Error: ", ex)
            End Try

        End Sub

        '**************************************************
        '*** Function:  ShowAppProperties
        '*** Purpose:   Add to the tree control all properties
        '***            under the Document node
        '*** Input:     nIndex - parent treeview node index
        '***            oApp - an application pointer
        '*** Output:    none
        '**************************************************
        Private Sub ShowAppProperties(ByVal parent As TreeNode, ByRef oApp As InteropServices.Application)

            Dim nodeTemp As TreeNode

            If FullRefresh() Then
                Try
                    Using oBatchCollWrap As New ApiObjectWrapper(Of InteropServices.BatchClasses)(oApp.BatchClasses)
                        If Not oBatchCollWrap.IsNull Then
                            nodeTemp = parent.Nodes.Add("BatchClasses")
                            ShowBatchClassesProperties(nodeTemp, oBatchCollWrap.WrappedObject)
                        End If
                    End Using
                Catch ex As Exception
                    Throw
                End Try
            End If

            If FullRefresh() Then
                '*** The following might blow up if not in Scan/QC, so ignore errors
                Dim strPageCount As String
                Try
                    strPageCount = Convert.ToString(oApp.RemainingPageCount)
                Catch ex As Exception
                    strPageCount = ""
                Finally
                    parent.Nodes.Add("RemainingPageCount = " & strPageCount)
                End Try
            End If

            '*** DataEntryMode
            Dim nodeDataEntry As TreeNode
            nodeDataEntry = parent.Nodes.Add("DataEntryMode = " & Convert.ToString(oApp.DataEntryMode))

            '*** ActiveBatch
            Try
                Using oBatch As New ApiObjectWrapper(Of InteropServices.Batch)(oApp.ActiveBatch)
                    If Not oBatch.IsNull Then
                        nodeTemp = parent.Nodes.Add("ActiveBatch")
                        ShowBatchProperties(nodeTemp, oBatch.WrappedObject)
                    End If
                End Using
            Catch ex As Exception
                Throw
            End Try

            '*** Other application properties
            parent.Nodes.Add("DataEntryMode = " & Convert.ToString(oApp.DataEntryMode))
            parent.Nodes.Add("HasAscentCaptureFeatures = " & Convert.ToString(oApp.HasAscentCaptureFeatures))
            parent.Nodes.Add("MultipleItemsSelected = " & Convert.ToString(oApp.MultipleItemsSelected))
            parent.Nodes.Add("PanelName = " & Convert.ToString(oApp.PanelName))

            '*** Expand tree to show at least the application level
            nodeDataEntry.EnsureVisible()

        End Sub

        '**************************************************
        '*** Function:  ShowBatchProperties
        '*** Purpose:   Show all batch class properties
        '*** Input:     nIndex - index of parent node
        '***            oBatch - the batch object
        '*** Output:    none
        '**************************************************
        Private Sub ShowBatchClassProperties(ByVal parent As TreeNode, ByRef oBatchClass As InteropServices.BatchClass)

            '*** Batch class name
            parent.Nodes.Add("Name = " & Convert.ToString(oBatchClass.Name))

            '*** Batch class description
            If m_bHasAscentCaptureFeatures Then
                parent.Nodes.Add("Description = " & Convert.ToString(oBatchClass.Description))
                parent.Nodes.Add("PublishTime = " & Convert.ToString(oBatchClass.PublishTime))
                parent.Nodes.Add("XmlFile = " & Convert.ToString(oBatchClass.XmlFile))
            End If

        End Sub

        '**************************************************
        '*** Function:  ShowBatchClassesProperties
        '*** Purpose:   Add all batch class collection properties
        '*** Input:     nIndex is the parent's index
        '***            oCollection - the batch class objects
        '*** Output:    none
        '**************************************************
        Private Sub ShowBatchClassesProperties(ByVal parent As TreeNode, ByRef oCollection As InteropServices.BatchClasses)

            Dim nodeTemp As TreeNode

            '*** Count
            parent.Nodes.Add("Count = " & Convert.ToString(oCollection.Count))

            '*** 
            '*** Iterate over each object
            '*** 

            Dim intNodeNum As Short
            intNodeNum = 1

            Try
                For Each oChildObject As InteropServices.BatchClass In oCollection
                    '*** Add the parent node as the item number
                    nodeTemp = parent.Nodes.Add(Convert.ToString(intNodeNum))
                    Using (oChildObject)
                        '*** Add the sub-nodes
                        ShowBatchClassProperties(nodeTemp, oChildObject)
                    End Using
                    '*** Increment the item number
                    intNodeNum = intNodeNum + 1
                Next
            Catch ex As Exception
                Throw
            End Try

        End Sub

        '**************************************************
        '*** Function:  ShowBatchDocumentClasses
        '*** Purpose:   Add the document class collection
        '***            properties to the tree
        '*** Input:     parent - parent node
        '***            oBatch - the batch object
        '*** Output:    none
        '**************************************************
        Private Sub ShowBatchDocumentClasses(ByVal parent As TreeNode, ByRef oBatch As InteropServices.Batch)

            Dim nodeTemp As TreeNode
            Try
                If FullRefresh() Then
                    Using oDocumentClassesWrap As New ApiObjectWrapper(Of InteropServices.DocumentClasses)(oBatch.DocumentClasses)
                        If Not oDocumentClassesWrap.IsNull Then
                            nodeTemp = parent.Nodes.Add("DocumentClasses")
                            ShowDocumentClassesProperties(nodeTemp, oDocumentClassesWrap.WrappedObject)
                        End If
                    End Using
                End If
            Catch ex As Exception
                Throw
            End Try

        End Sub

        '**************************************************
        '*** Function:  ShowBatchFolderClasses
        '*** Purpose:   Add the folder class collection
        '***            properties to the tree
        '*** Input:     parent - parent node
        '***            oBatch - the batch object
        '*** Output:    none
        '**************************************************
        Private Sub ShowBatchFolderClasses(ByVal parent As TreeNode, ByRef oBatch As InteropServices.Batch)

            Dim nodeTemp As TreeNode
            Try
                If FullRefresh() Then
                    Using oFolderClassesWrap As New ApiObjectWrapper(Of InteropServices.FolderClasses)(oBatch.FolderClasses)
                        If Not oFolderClassesWrap.IsNull Then
                            nodeTemp = parent.Nodes.Add("FolderClasses")
                            ShowFolderClassesProperties(nodeTemp, oFolderClassesWrap.WrappedObject)
                        End If
                    End Using
                End If
            Catch ex As Exception
                Throw
            Finally
                If Not IsNothing(nodeTemp) Then
                    nodeTemp = Nothing
                End If
            End Try
        End Sub

        '**************************************************
        '*** Function:  ShowBatchFormTypes
        '*** Purpose:   Add the batch form type
        '***            properties to the tree
        '*** Input:     parent - parent node
        '***            oBatch - the batch object
        '*** Output:    none
        '**************************************************
        Private Sub ShowBatchFormTypes(ByVal parent As TreeNode, ByRef oBatch As InteropServices.Batch)

            Dim nodeTemp As TreeNode

            Try
                If FullRefresh() Then
                    Using oFormTypes As New ApiObjectWrapper(Of InteropServices.FormTypes)(oBatch.FormTypes)
                        If Not oFormTypes.IsNull Then
                            nodeTemp = parent.Nodes.Add("FormTypes")
                            ShowFormTypesProperties(nodeTemp, oFormTypes.WrappedObject)
                        End If
                    End Using
                End If
            Catch ex As Exception
                Throw
            Finally
                If Not IsNothing(nodeTemp) Then
                    nodeTemp = Nothing
                End If
            End Try

        End Sub

        '**************************************************
        '*** Function:  ShowBatchFields
        '*** Purpose:   Add the batch field
        '***            properties to the tree
        '*** Input:     parent - parent node
        '***            oBatch - the batch object
        '*** Output:    none
        '**************************************************
        Private Sub ShowBatchFields(ByVal parent As TreeNode, ByRef oBatch As InteropServices.Batch)

            Dim nodeTemp As TreeNode

            Try
                If FullRefresh() Then
                    Using oBatchFields As New ApiObjectWrapper(Of InteropServices.BatchFields)(oBatch.BatchFields)
                        If Not oBatchFields.IsNull Then
                            nodeTemp = parent.Nodes.Add("BatchFields")
                            ShowBatchFieldsProperties(nodeTemp, oBatchFields.WrappedObject)
                        End If
                    End Using
                End If
            Catch ex As Exception
                Throw
            Finally
                If Not IsNothing(nodeTemp) Then
                    nodeTemp = Nothing
                End If
            End Try

        End Sub

        '**************************************************
        '*** Function:  ShowBatchTotals
        '*** Purpose:   Add the batch total
        '***            properties to the tree
        '*** Input:     parent - parent node
        '***            oBatch - the batch object
        '*** Output:    none
        '**************************************************
        Private Sub ShowBatchTotals(ByVal parent As TreeNode, ByRef oBatch As InteropServices.Batch)

            Dim nodeTemp As TreeNode

            Try
                If FullRefresh() Then
                    Using oExpectedBatchTotals As New ApiObjectWrapper(Of InteropServices.ExpectedBatchTotals)(oBatch.ExpectedBatchTotals)
                        If Not oExpectedBatchTotals.IsNull Then
                            nodeTemp = parent.Nodes.Add("ExpectedBatchTotals")
                            ShowExpectedBatchTotalsProperties(nodeTemp, oExpectedBatchTotals.WrappedObject)
                        End If
                    End Using
                End If
            Catch ex As Exception
                Throw
            Finally
                If Not IsNothing(nodeTemp) Then
                    nodeTemp = Nothing
                End If
            End Try

        End Sub

        '**************************************************
        '*** Function:  ShowBatchDocuments
        '*** Purpose:   Add the active document 
        '***            properties to the tree
        '*** Input:     parent - parent node
        '***            oBatch - the batch object
        '*** Output:    none
        '**************************************************
        Private Sub ShowBatchActiveDocument(ByVal parent As TreeNode, ByRef oBatch As InteropServices.Batch)

            Dim nodeTemp As TreeNode

            Try
                Using oDocument As New ApiObjectWrapper(Of InteropServices.Document)(oBatch.ActiveDocument)
                    If Not oDocument.IsNull Then
                        nodeTemp = parent.Nodes.Add("ActiveDocument")
                        ShowDocumentProperties(nodeTemp, oDocument.WrappedObject)
                    End If
                End Using
            Catch ex As Exception
                Throw
            Finally
                If Not IsNothing(nodeTemp) Then
                    nodeTemp = Nothing
                End If
            End Try

        End Sub

        '**************************************************
        '*** Function:  ShowBatchDocuments
        '*** Purpose:   Add the document collection
        '***            properties to the tree
        '*** Input:     parent - parent node
        '***            oBatch - the batch object
        '*** Output:    none
        '**************************************************
        Private Sub ShowBatchDocuments(ByVal parent As TreeNode, ByRef oBatch As InteropServices.Batch)

            Dim nodeTemp As TreeNode

            Try
                If FullRefresh() Then
                    nodeTemp = parent.Nodes.Add("Documents")
                    Using oDocuments As New ApiObjectWrapper(Of InteropServices.Documents)(oBatch.Documents)
                        If Not oDocuments.IsNull Then
                            ShowDocumentsProperties(nodeTemp, oDocuments.WrappedObject)
                        End If
                    End Using
                End If
            Catch ex As Exception
                Throw
            Finally
                If Not IsNothing(nodeTemp) Then
                    nodeTemp = Nothing
                End If
            End Try

        End Sub

        '**************************************************
        '*** Function:  ShowBatchActiveFolder
        '*** Purpose:   Add the active folder
        '***            properties to the tree
        '*** Input:     parent - parent node
        '***            oBatch - the batch object
        '*** Output:    none
        '**************************************************
        Private Sub ShowBatchActiveFolder(ByVal parent As TreeNode, ByRef oBatch As InteropServices.Batch)

            Dim nodeTemp As TreeNode

            Try
                Using oFolder As New ApiObjectWrapper(Of InteropServices.Folder)(oBatch.ActiveFolder)
                    If Not oFolder.IsNull Then
                        nodeTemp = parent.Nodes.Add("ActiveFolder")
                        ShowFolderProperties(nodeTemp, oFolder.WrappedObject)
                    End If
                End Using
            Catch ex As Exception
                Throw
            Finally
                If Not IsNothing(nodeTemp) Then
                    nodeTemp = Nothing
                End If
            End Try

        End Sub

        '**************************************************
        '*** Function:  ShowBatchFolders
        '*** Purpose:   Add the folder collection
        '***            properties to the tree
        '*** Input:     parent - parent node
        '***            oBatch - the batch object
        '*** Output:    none
        '**************************************************
        Private Sub ShowBatchFolders(ByVal parent As TreeNode, ByRef oBatch As InteropServices.Batch)

            Dim nodeTemp As TreeNode

            Try
                If FullRefresh() Then
                    nodeTemp = parent.Nodes.Add("Folders")
                    Using oFolders As New ApiObjectWrapper(Of InteropServices.Folders)(oBatch.Folders)
                        If Not oFolders.IsNull Then
                            ShowFoldersProperties(nodeTemp, oFolders.WrappedObject)
                        End If
                    End Using
                End If
            Catch ex As Exception
                Throw
            Finally
                If Not IsNothing(nodeTemp) Then
                    nodeTemp = Nothing
                End If
            End Try

        End Sub

        '**************************************************
        '*** Function:  ShowBatchActivePage
        '*** Purpose:   Add the active page
        '***            properties to the tree
        '*** Input:     parent - parent node
        '***            oBatch - the batch object
        '*** Output:    none
        '**************************************************
        Private Sub ShowBatchActivePage(ByVal parent As TreeNode, ByRef oBatch As InteropServices.Batch)

            Dim nodeTemp As TreeNode

            Try
                Dim lDocID As Integer
                Using oPage As New ApiObjectWrapper(Of InteropServices.Page)(oBatch.ActivePage)

                    If Not oPage.IsNull Then
                        nodeTemp = parent.Nodes.Add("ActivePage")
                        Using oDoc As New ApiObjectWrapper(Of InteropServices.Document)(oPage.WrappedObject.Document)
                            If Not oDoc.IsNull Then
                                lDocID = oDoc.WrappedObject.ID
                            Else
                                lDocID = 0
                            End If
                            ShowPageProperties(nodeTemp, oPage.WrappedObject, lDocID)
                        End Using
                    End If
                End Using
            Catch ex As Exception
                Throw
            Finally
                If Not IsNothing(nodeTemp) Then
                    nodeTemp = Nothing
                End If
            End Try

        End Sub

        '**************************************************
        '*** Function:  ShowBatchLoosePageCount
        '*** Purpose:   Add the loose page count
        '***            property to the tree
        '*** Input:     parent - parent node
        '***            oBatch - the batch object
        '*** Output:    none
        '**************************************************
        Private Sub ShowBatchLoosePageCount(ByVal parent As TreeNode, ByRef oBatch As InteropServices.Batch)

            Try
                If FullRefresh() Then
                    parent.Nodes.Add("LoosePageCount = " & Convert.ToString(oBatch.LoosePageCount))
                End If
            Catch ex As Exception
                Throw
            End Try

        End Sub

        '**************************************************
        '*** Function:  ShowBatchLoosePages
        '*** Purpose:   Add the loose page collection
        '***            properties to the tree
        '*** Input:     parent - parent node
        '***            oBatch - the batch object
        '*** Output:    none
        '**************************************************
        Private Sub ShowBatchLoosePages(ByVal parent As TreeNode, ByRef oBatch As InteropServices.Batch)

            Dim nodeTemp As TreeNode

            Try
                If FullRefresh() Then
                    nodeTemp = parent.Nodes.Add("LoosePages")
                    Using oLoosePages As New ApiObjectWrapper(Of InteropServices.Pages)(oBatch.LoosePages)
                        If Not oLoosePages.IsNull Then
                            ShowPagesProperties(nodeTemp, oLoosePages.WrappedObject, 0)
                        End If
                    End Using
                End If
            Catch ex As Exception
                Throw
            Finally
                If Not IsNothing(nodeTemp) Then
                    nodeTemp = Nothing
                End If
            End Try

        End Sub

        '**************************************************
        '*** Function:  ShowBatchActiveLoosePage
        '*** Purpose:   Add the active loose page 
        '***            properties to the tree
        '*** Input:     parent - parent node
        '***            oBatch - the batch object
        '*** Output:    none
        '**************************************************
        Private Sub ShowBatchActiveLoosePage(ByVal parent As TreeNode, ByRef oBatch As InteropServices.Batch)

            Dim nodeTemp As TreeNode
            Try
                Using oPage As New ApiObjectWrapper(Of InteropServices.Page)(oBatch.ActiveLoosePage)
                    If Not oPage.IsNull Then
                        nodeTemp = parent.Nodes.Add("ActiveLoosePage")
                        ShowPageProperties(nodeTemp, oPage.WrappedObject, 0)
                    End If
                End Using
            Catch ex As Exception
                Throw
            Finally
                If Not IsNothing(nodeTemp) Then
                    nodeTemp = Nothing
                End If
            End Try

        End Sub

        '**************************************************
        '*** Function:  ShowBatchProperties
        '*** Purpose:   Add to the tree control all properties
        '***            under the Batch node
        '*** Input:     parent - parent node
        '***            oBatch - the batch object
        '*** Output:    none
        '**************************************************
        Private Sub ShowBatchProperties(ByVal parent As TreeNode, ByRef oBatch As InteropServices.Batch)

            Dim nodeTemp As TreeNode

            Try
                '*** Batch name
                parent.Nodes.Add("Name = " & oBatch.Name)

                '*** Batch description
                If m_bHasAscentCaptureFeatures Then
                    nodeTemp = parent.Nodes.Add("Description = " & oBatch.Description)
                    SetKey(nodeTemp, "Batch", "Description", 0, 0)

                    If FullRefresh() Then
                        nodeTemp = parent.Nodes.Add("Priority = " & Convert.ToString(oBatch.Priority))
                        SetKey(nodeTemp, "Batch", "Priority", 0, 0)

                        parent.Nodes.Add("PublishTime = " & Convert.ToString(oBatch.PublishTime))

                        parent.Nodes.Add("CreateTime = " & Convert.ToString(oBatch.CreateTime))

                        '*** The following might blow up if not in Scan/QC, so ignore errors
                        Try
                            parent.Nodes.Add("SupportsAutomaticSeparationAndFormID = " & Convert.ToString(oBatch.SupportsAutomaticSeparationAndFormID))

                            nodeTemp = parent.Nodes.Add("AutomaticSeparationAndFormID = " & Convert.ToString(oBatch.AutomaticSeparationAndFormID))
                            SetKey(nodeTemp, "Batch", "AutomaticSeparationAndFormID", 0, 0)
                        Catch ex As Exception
                            ' Ignore
                        End Try
                    End If

                End If

                '*** Batch's external id
                parent.Nodes.Add("ExternalID = " & Convert.ToString(oBatch.ExternalID))

                '*** Batch Class name
                parent.Nodes.Add("ClassName = " & oBatch.ClassName)

                '*** Batch class id
                parent.Nodes.Add("ClassID = " & Convert.ToString(oBatch.ClassID))

                '*** Document count
                parent.Nodes.Add("DocumentCount = " & Convert.ToString(oBatch.DocumentCount))

                '*** Folder count
                parent.Nodes.Add("FolderCount = " & Convert.ToString(oBatch.FolderCount))

                '*** Document Classes - Sub-object
                ShowBatchDocumentClasses(parent, oBatch)

                '*** Folder Classes - Sub-object
                ShowBatchFolderClasses(parent, oBatch)

                '*** Form Types - Sub-object
                ShowBatchFormTypes(parent, oBatch)

                '*** Batch Fields - Sub-object
                ShowBatchFields(parent, oBatch)

                '*** Expected Batch Totals - Sub-object
                ShowBatchTotals(parent, oBatch)

                '*** Active document - Sub-object
                ShowBatchActiveDocument(parent, oBatch)

                '*** Document Collection - Only on full refresh
                ShowBatchDocuments(parent, oBatch)

                '*** Active folder - Sub-object
                ShowBatchActiveFolder(parent, oBatch)

                '*** Folder Collection - Only on full refresh
                ShowBatchFolders(parent, oBatch)

                '*** Active page - Sub-object
                ShowBatchActivePage(parent, oBatch)

                '*** Loose Page Count - Only on full refresh
                ShowBatchLoosePageCount(parent, oBatch)

                '*** Loose Page collection - Only on full refresh
                ShowBatchLoosePages(parent, oBatch)

                '*** Active loose page - Sub-object
                ShowBatchActiveLoosePage(parent, oBatch)
            Catch ex As Exception
                Throw
            Finally
                If Not IsNothing(nodeTemp) Then
                    nodeTemp = Nothing
                End If
            End Try

        End Sub

        '**************************************************
        '*** Function:  ShowDocumentClassProperties
        '*** Purpose:   Show all document class properties
        '*** Input:     nIndex - index of parent node
        '***            oDocumentClass - the document class object
        '*** Output:    none
        '**************************************************
        Private Sub ShowDocumentClassProperties(ByVal parent As TreeNode, ByRef oDocumentClass As InteropServices.DocumentClass)

            Dim nodeTemp As TreeNode

            parent.Nodes.Add("Name = " & Convert.ToString(oDocumentClass.Name))
            parent.Nodes.Add("Description = " & Convert.ToString(oDocumentClass.Description))

            '*** Form types
            '*** Active loose page - Sub-object
            Using oFormTypes As New ApiObjectWrapper(Of InteropServices.FormTypes)(oDocumentClass.FormTypes)
                If Not oFormTypes.IsNull Then
                    nodeTemp = parent.Nodes.Add("FormTypes")
                    ShowFormTypesProperties(nodeTemp, oFormTypes.WrappedObject)
                End If
            End Using
        End Sub

        '**************************************************
        '*** Function:  ShowDocumentClassesProperties
        '*** Purpose:   Add properties of document classes
        '*** Input:     nIndex is the parent's index
        '***            oCollection - the batchfields object
        '*** Output:    none
        '**************************************************
        Private Sub ShowDocumentClassesProperties(ByVal parent As TreeNode, ByRef oCollection As InteropServices.DocumentClasses)

            Dim nodeTemp As TreeNode

            '*** Count
            parent.Nodes.Add("Count = " & Convert.ToString(oCollection.Count))

            '*** 
            '*** Iterate over each object
            '*** 

            Dim intNodeNum As Short
            intNodeNum = 1

            Try
                For Each oChildObject As InteropServices.DocumentClass In oCollection
                    Using (oChildObject)
                        '*** Add the parent node as the item number
                        nodeTemp = parent.Nodes.Add(Convert.ToString(intNodeNum))

                        '*** Add the sub-nodes
                        ShowDocumentClassProperties(nodeTemp, oChildObject)

                        '*** Increment the item number
                        intNodeNum = intNodeNum + 1

                    End Using
                    oChildObject = Nothing
                Next oChildObject
            Catch ex As Exception
                Throw
            End Try

        End Sub

        '**************************************************
        '*** Function:  ShowFolderClassProperties
        '*** Purpose:   Show all folder class properties
        '*** Input:     nIndex - index of parent node
        '***            oFolderClass - the folder class object
        '*** Output:    none
        '**************************************************
        Private Sub ShowFolderClassProperties(ByVal parent As TreeNode, ByRef oFolderClass As InteropServices.FolderClass)

            parent.Nodes.Add("Name = " & Convert.ToString(oFolderClass.Name))
            parent.Nodes.Add("Description = " & Convert.ToString(oFolderClass.Description))

        End Sub

        '**************************************************
        '*** Function:  ShowFolderClassesProperties
        '*** Purpose:   Add properties of folder classes
        '*** Input:     nIndex is the parent's index
        '***            oCollection - the FolderClasses object
        '*** Output:    none
        '**************************************************
        Private Sub ShowFolderClassesProperties(ByVal parent As TreeNode, ByRef oCollection As InteropServices.FolderClasses)

            Dim nodeTemp As TreeNode

            '*** Count
            parent.Nodes.Add("Count = " & Convert.ToString(oCollection.Count))

            '*** 
            '*** Iterate over each object
            '*** 

            Dim intNodeNum As Short
            intNodeNum = 1

            Try
                For Each oChildObject As InteropServices.FolderClass In oCollection
                    Using (oChildObject)
                        '*** Add the parent node as the item number
                        nodeTemp = parent.Nodes.Add(Convert.ToString(intNodeNum))

                        '*** Add the sub-nodes
                        ShowFolderClassProperties(nodeTemp, oChildObject)

                        '*** Increment the item number
                        intNodeNum = intNodeNum + 1
                    End Using
                Next oChildObject
            Catch ex As Exception
                Throw
            End Try

        End Sub


        '**************************************************
        '*** Function:  ShowFormTypeProperties
        '*** Purpose:   Show all form type properties
        '*** Input:     nIndex - index of parent node
        '***            oFormType - the form type object
        '*** Output:    none
        '**************************************************
        Private Sub ShowFormTypeProperties(ByVal parent As TreeNode, ByRef oFormType As InteropServices.FormType)

            parent.Nodes.Add("Name = " & Convert.ToString(oFormType.Name))

            If m_bHasAscentCaptureFeatures Then
                parent.Nodes.Add("Description = " & Convert.ToString(oFormType.Description))

                '*** We don't expand the document class because that would go into
                '*** a recursive loop.  Just make sure we can get to it
                Using oDocClass As InteropServices.DocumentClass = oFormType.DocumentClass
                    parent.Nodes.Add("DocumentClass (Name) = " & Convert.ToString(oDocClass.Name))
                End Using
            End If

        End Sub

        '**************************************************
        '*** Function:  ShowFormTypesProperties
        '*** Purpose:   Add properties of all form types
        '*** Input:     nIndex is the parent's index
        '***            oCollection - the batchfields object
        '*** Output:    none
        '**************************************************
        Private Sub ShowFormTypesProperties(ByVal parent As TreeNode, ByRef oCollection As InteropServices.FormTypes)

            Dim nodeTemp As TreeNode

            '*** Count
            parent.Nodes.Add("Count = " & Convert.ToString(oCollection.Count))

            '*** 
            '*** Iterate over each object
            '*** 

            Dim intNodeNum As Short
            intNodeNum = 1

            Try
                For Each oChildObject As InteropServices.FormType In oCollection
                    Using (oChildObject)
                        '*** Add the parent node as the item number
                        nodeTemp = parent.Nodes.Add(Convert.ToString(intNodeNum))

                        '*** Add the sub-nodes
                        ShowFormTypeProperties(nodeTemp, oChildObject)

                        '*** Increment the item number
                        intNodeNum = intNodeNum + 1
                    End Using
                Next oChildObject
            Catch ex As Exception
                Throw
            End Try

        End Sub

        '**************************************************
        '*** Function:  ShowBatchFieldProperties
        '*** Purpose:   Show all Batch field properties
        '*** Input:     nIndex is the index of the parent
        '***            oField - the batch field object
        '*** Output:    none
        '**************************************************
        Private Sub ShowBatchFieldProperties(ByVal parent As TreeNode, ByRef oField As InteropServices.BatchField)

            Dim nodeTemp As TreeNode

            parent.Nodes.Add("Name = " & Convert.ToString(oField.Name))
            parent.Nodes.Add("DisplayLabel = " & Convert.ToString(oField.DisplayLabel))
            parent.Nodes.Add("OrderNumber = " & Convert.ToString(oField.OrderNumber))
            parent.Nodes.Add("TypeName =  " & Convert.ToString(oField.TypeName))
            parent.Nodes.Add("Description =  " & Convert.ToString(oField.Description))
            parent.Nodes.Add("Numeric =  " & Convert.ToString(oField.Numeric))

            '*** 
            '*** Numeric fields throw if you try to get length, and non-numeric fields throw
            '*** if you try to get numeric precision and numeric scale
            '*** 

            If oField.Numeric Then

                parent.Nodes.Add("NumericPrecision =  " & Convert.ToString(oField.NumericPrecision))
                parent.Nodes.Add("NumericScale =  " & Convert.ToString(oField.NumericScale))

            Else '*** Character type

                parent.Nodes.Add("Length =  " & Convert.ToString(oField.Length))

            End If
            parent.Nodes.Add("SqlType =  " & Convert.ToString(oField.SqlType))
            parent.Nodes.Add("Hidden =  " & Convert.ToString(oField.Hidden))
            parent.Nodes.Add("Required =  " & Convert.ToString(oField.Required))

            nodeTemp = parent.Nodes.Add("Value =  " & Convert.ToString(oField.Value))
            SetKey(nodeTemp, "BatchField", "Value", oField.OrderNumber, 0)

            parent.Nodes.Add("DefaultValue =  " & Convert.ToString(oField.DefaultValue))

            '*** 
            '*** Suggested Value Stuff
            '*** 

            parent.Nodes.Add("SuggestedValueCount =  " & Convert.ToString(oField.SuggestedValueCount))
            If FullRefresh() Then
                Using oSuggestedValues As New ApiObjectWrapper(Of InteropServices.SuggestedValues)(oField.SuggestedValues)
                    If Not oSuggestedValues.IsNull Then
                        nodeTemp = parent.Nodes.Add("SuggestedValues")
                        ShowSuggestedValuesProperties(nodeTemp, oSuggestedValues.WrappedObject)
                    End If
                End Using
                parent.Nodes.Add("SuggestedValuesForceMatch =  " & Convert.ToString(oField.SuggestedValuesForceMatch))
                parent.Nodes.Add("SuggestedValuesForceMatchCaseSensitive =  " & Convert.ToString(oField.SuggestedValuesForceMatchCaseSensitive))
            End If

        End Sub

        '**************************************************
        '*** Function:  ShowBatchFieldsProperties
        '*** Purpose:   Add all batch field collection properties
        '*** Input:     nIndex is the parent's index
        '***            oCollection - the batchfields object
        '*** Output:    none
        '**************************************************
        Private Sub ShowBatchFieldsProperties(ByVal parent As TreeNode, ByRef oCollection As InteropServices.BatchFields)

            Dim nodeTemp As TreeNode

            '*** Count
            parent.Nodes.Add("Count = " & Convert.ToString(oCollection.Count))

            '*** 
            '*** Iterate over each object
            '*** 

            Dim intNodeNum As Short
            intNodeNum = 1

            Try
                For Each oChildObject As InteropServices.BatchField In oCollection
                    Using (oChildObject)
                        '*** Add the parent node as the item number
                        nodeTemp = parent.Nodes.Add(Convert.ToString(intNodeNum))

                        '*** Add the sub-nodes
                        ShowBatchFieldProperties(nodeTemp, oChildObject)

                        '*** Increment the item number
                        intNodeNum = intNodeNum + 1
                    End Using
                Next oChildObject
            Catch ex As Exception
                Throw
            End Try

        End Sub

        '**************************************************
        '*** Function:  ShowExpectedBatchTotalProperties
        '*** Purpose:   Show all Batch total properties
        '*** Input:     nIndex is the index of the parent
        '***            oField - the batch field object
        '*** Output:    none
        '**************************************************
        Private Sub ShowExpectedBatchTotalProperties(ByVal parent As TreeNode, ByRef oField As InteropServices.ExpectedBatchTotal)

            Dim nodeTemp As TreeNode

            parent.Nodes.Add("Name = " & Convert.ToString(oField.Name))
            parent.Nodes.Add("OrderNumber = " & Convert.ToString(oField.OrderNumber))
            parent.Nodes.Add("TypeName =  " & Convert.ToString(oField.TypeName))
            parent.Nodes.Add("Description =  " & Convert.ToString(oField.Description))
            parent.Nodes.Add("Numeric =  " & Convert.ToString(oField.Numeric))

            '*** Numeric fields throw if you try to get length, and non-numeric fields throw
            '*** if you try to get numeric precision and numeric scale

            If oField.Numeric Then

                parent.Nodes.Add("NumericPrecision =  " & Convert.ToString(oField.NumericPrecision))
                parent.Nodes.Add("NumericScale =  " & Convert.ToString(oField.NumericScale))

            Else '*** Character type

                parent.Nodes.Add("Length =  " & Convert.ToString(oField.Length))

            End If
            parent.Nodes.Add("SqlType =  " & Convert.ToString(oField.SqlType))

            nodeTemp = parent.Nodes.Add("Value =  " & Convert.ToString(oField.Value))
            SetKey(nodeTemp, "ExpectedBatchTotal", "Value", oField.OrderNumber, 0)

        End Sub

        '**************************************************
        '*** Function:  ShowExpectedBatchTotals
        '*** Purpose:   Add all expected batch total properties
        '*** Input:     nIndex is the parent's index
        '***            oCollection - the batchfields object
        '*** Output:    none
        '**************************************************
        Private Sub ShowExpectedBatchTotalsProperties(ByVal parent As TreeNode, ByRef oCollection As InteropServices.ExpectedBatchTotals)

            Dim nodeTemp As TreeNode

            '*** Count
            parent.Nodes.Add("Count = " & Convert.ToString(oCollection.Count))

            '*** 
            '*** Iterate over each object
            '*** 

            Dim intNodeNum As Short
            intNodeNum = 1

            Try
                For Each oChildObject As InteropServices.ExpectedBatchTotal In oCollection
                    Using (oChildObject)
                        '*** Add the parent node as the item number
                        nodeTemp = parent.Nodes.Add(Convert.ToString(intNodeNum))

                        '*** Add the sub-nodes
                        ShowExpectedBatchTotalProperties(nodeTemp, oChildObject)

                        '*** Increment the item number
                        intNodeNum = intNodeNum + 1

                    End Using
                Next
            Catch ex As Exception
                Throw
            End Try

        End Sub

        '**************************************************
        '*** Function:  ShowDocumentProperties
        '*** Purpose:   Add to the tree control all properties
        '***            under the Document node
        '*** Input:     nIndex is the index of the parent
        '***            oDocument - the current document
        '*** Output:    none
        '**************************************************
        Private Sub ShowDocumentProperties(ByVal parent As TreeNode, ByRef oDocument As InteropServices.Document)

            Dim nodeTemp As TreeNode

            '*** Get our ID (order number) so we can write to fields
            Dim lDocID As Integer
            lDocID = oDocument.OrderNumber

            '*** See if we have a form type
            Dim strFormType As String
            strFormType = ""

            Try
                strFormType = oDocument.FormName ' Throws if no form
            Catch ex As Exception
                strFormType = ""
            End Try

            If strFormType.Length <> 0 Then
                parent.Nodes.Add("ClassName = " & oDocument.ClassName)
                If m_bHasAscentCaptureFeatures Then
                    parent.Nodes.Add("ClassID = " & Convert.ToString(oDocument.ClassID))
                End If
                parent.Nodes.Add("FormName = " & oDocument.FormName)
            End If

            If m_bHasAscentCaptureFeatures Then
                parent.Nodes.Add("UniqueID = " & Convert.ToString(oDocument.UniqueID))
            End If
            parent.Nodes.Add("OrderNumber = " & Convert.ToString(oDocument.OrderNumber))
            parent.Nodes.Add("PageCount = " & Convert.ToString(oDocument.PageCount))

            '*** Parent folder
            Using oParentFolder As New ApiObjectWrapper(Of InteropServices.Folder)(oDocument.Folder)
                If Not oParentFolder.IsNull Then
                    nodeTemp = parent.Nodes.Add("Folder")
                    ShowFolderProperties(nodeTemp, oParentFolder.WrappedObject, False)
                End If
            End Using

            '*** Document Page Collection
            Using oDocPages As New ApiObjectWrapper(Of InteropServices.Pages)(oDocument.Pages)
                If Not oDocPages.IsNull Then
                    nodeTemp = parent.Nodes.Add("Pages")
                    ShowPagesProperties(nodeTemp, oDocPages.WrappedObject, lDocID)
                End If
            End Using

            '*** Document ActivePage
            Using oActivePage As New ApiObjectWrapper(Of InteropServices.Page)(oDocument.ActivePage)
                If Not oActivePage.IsNull Then
                    nodeTemp = parent.Nodes.Add("ActivePage")
                    ShowPageProperties(nodeTemp, oActivePage.WrappedObject, lDocID)
                End If
            End Using
            '*** 
            '*** The following three properties throw exceptions if not in data-entry mode
            '*** AND we are on the current document
            '*** 
            Dim lCurrentOrder As Integer
            lCurrentOrder = 0

            Try
                Using oActiveBatch As New ApiObjectWrapper(Of InteropServices.Batch)(m_oApp.ActiveBatch)
                    Using oCurrentDocument As New ApiObjectWrapper(Of InteropServices.Document)(oActiveBatch.WrappedObject.ActiveDocument)  '*** Batch always set from here
                        If Not oCurrentDocument.IsNull Then
                            lCurrentOrder = oCurrentDocument.WrappedObject.OrderNumber
                        End If
                    End Using
                End Using
            Catch ex As Exception
                Throw
            End Try

            If strFormType.Length <> 0 And m_bHasAscentCaptureFeatures Then
                '*** Document Index Field Count
                parent.Nodes.Add("IndexFieldCount =  " & Convert.ToString(oDocument.IndexFieldCount))

                '*** Document Index Field collection
                Using oIndexFields As New ApiObjectWrapper(Of InteropServices.IndexFields)(oDocument.IndexFields)
                    If Not oIndexFields.IsNull Then
                        nodeTemp = parent.Nodes.Add("IndexFieldCollection")
                        ShowDocIndexFieldsProperties(nodeTemp, oIndexFields.WrappedObject, lDocID)
                    End If
                End Using

                '*** Active Index Field - They may not have an active field
                Using oIndexField As New ApiObjectWrapper(Of InteropServices.IndexField)(oDocument.ActiveIndexField)
                    If Not oIndexField.IsNull Then
                        nodeTemp = parent.Nodes.Add("ActiveIndexField")
                        ShowDocIndexFieldProperties(nodeTemp, oIndexField.WrappedObject, lDocID)
                    End If
                End Using
            End If

            '*** 
            '*** The custom property properties throw exceptions if there is no export connector
            '*** 

            Dim lCustomPropertyCount As Integer
            lCustomPropertyCount = -1

            Try
                If m_bHasAscentCaptureFeatures Then
                    lCustomPropertyCount = oDocument.CustomPropertyCount ' Throws if no export connector
                End If
            Catch ex As Exception
                lCustomPropertyCount = -1
            End Try

            If lCustomPropertyCount >= 0 Then
                '*** Custom Property Count
                parent.Nodes.Add("CustomPropertyCount =  " & Convert.ToString(oDocument.CustomPropertyCount))

                '*** Custom Property Collection
                Using oCustomPropertyColl As New ApiObjectWrapper(Of InteropServices.CustomProperties)(oDocument.CustomProperties)
                    If Not oCustomPropertyColl.IsNull Then
                        nodeTemp = parent.Nodes.Add("CustomPropertyCollection")
                        ShowCustomProperties(nodeTemp, oCustomPropertyColl.WrappedObject, lDocID)
                    End If
                End Using
            End If

            '*** Reject status
            nodeTemp = parent.Nodes.Add("Rejected =  " & Convert.ToString(oDocument.Rejected))
            SetKey(nodeTemp, "Document", "Rejected", lDocID, 0)

            '*** Note
            nodeTemp = parent.Nodes.Add("Note =  " & oDocument.Note)
            SetKey(nodeTemp, "Document", "Note", lDocID, 0)

            Dim strTemp As String
            If FullRefresh() And m_bHasAscentCaptureFeatures Then
                parent.Nodes.Add("FormIDConfidence =  " & Convert.ToString(oDocument.FormIDConfidence))
                parent.Nodes.Add("FormIDDifference =  " & Convert.ToString(oDocument.FormIDDifference))

                '*** 
                '*** We don't expand the document class because that would go into
                '*** a recursive loop.  Just make sure we can get to it
                '*** 

                strTemp = "FormType (Name) = "
                Using oFormType As New ApiObjectWrapper(Of InteropServices.FormType)(oDocument.FormType)
                    If oFormType.IsNull Then
                        strTemp = strTemp & "(none)"
                    Else
                        strTemp = strTemp & Convert.ToString(oFormType.WrappedObject.Name)
                    End If

                    nodeTemp = parent.Nodes.Add(strTemp)
                    SetKey(nodeTemp, "Document", "FormType", lDocID, 0)
                End Using
            End If

            parent.Nodes.Add("ID = " & Convert.ToString(oDocument.ID))

            If FullRefresh() And m_bHasAscentCaptureFeatures Then
                '*** Assigned Export Connectors
                Using oAsnReleasesScripts As New ApiObjectWrapper(Of InteropServices.AsnReleaseScripts)(oDocument.AsnReleaseScripts)
                    If Not oAsnReleasesScripts.IsNull Then
                        nodeTemp = parent.Nodes.Add("AsnReleaseScripts")
                        ShowAssignedReleaseScripts(nodeTemp, oAsnReleasesScripts.WrappedObject, lDocID)
                    End If
                End Using
            End If

        End Sub

        '**************************************************
        '*** Function:  ShowDocumentsProperties
        '*** Purpose:   Add all document collection properties
        '*** Input:     nIndex is the parent's index
        '***            oDocuments - the pages object
        '*** Output:    none
        '**************************************************
        Private Sub ShowDocumentsProperties(ByVal parent As TreeNode, ByRef oDocuments As InteropServices.Documents)

            Dim nodeTemp As TreeNode

            '*** Count
            parent.Nodes.Add("Count = " & Convert.ToString(oDocuments.Count))

            '*** Iterate over each page
            Dim intNodeNum As Short
            intNodeNum = 1

            Try
                For Each oDocument As InteropServices.Document In oDocuments
                    Using oDocumentWrapper As New ApiObjectWrapper(Of InteropServices.Document)(oDocument)
                        '*** Add the parent node as the item number
                        nodeTemp = parent.Nodes.Add(Convert.ToString(intNodeNum))

                        '*** Add the sub-nodes
                        ShowDocumentProperties(nodeTemp, oDocumentWrapper.WrappedObject)

                        '*** Increment the item number
                        intNodeNum = intNodeNum + 1

                    End Using
                Next
            Catch ex As Exception
                Throw
            End Try

        End Sub

        '**************************************************
        '*** Function:  ShowFolderProperties
        '*** Purpose:   Add to the tree control all properties
        '***            under the Folder node
        '*** Input:     nIndex is the index of the parent
        '***            oFolder - the current folder
        '*** Output:    none
        '**************************************************
        Private Sub ShowFolderProperties(ByVal parent As TreeNode, ByRef oFolder As InteropServices.Folder, Optional ByRef bRecursive As Boolean = True)

            Dim nodeTemp As TreeNode

            '*** 
            '*** Get our ID (order number) so we can write to fields
            '*** 

            Dim lFolderID As Integer
            lFolderID = oFolder.OrderNumber

            '*** See if we have a folder class
            Dim strFolderClass As String
            strFolderClass = ""

            Try
                strFolderClass = oFolder.ClassName ' Throws if no folder class
            Catch ex As Exception
                strFolderClass = ""
            End Try

            If strFolderClass.Length <> 0 Then
                parent.Nodes.Add("ClassName = " & oFolder.ClassName)
                If m_bHasAscentCaptureFeatures Then
                    parent.Nodes.Add("ClassID = " & Convert.ToString(oFolder.ClassID))
                End If
            End If

            parent.Nodes.Add("ID = " & Convert.ToString(oFolder.ID))

            parent.Nodes.Add("OrderNumber = " & Convert.ToString(oFolder.OrderNumber))

            '*** Parent folder
            Using oSubFolder As New ApiObjectWrapper(Of InteropServices.Folder)(oFolder.Folder)
                If Not oSubFolder.IsNull Then
                    nodeTemp = parent.Nodes.Add("Folder")
                    ShowFolderProperties(nodeTemp, oSubFolder.WrappedObject, False)
                End If
            End Using

            nodeTemp = parent.Nodes.Add("Validated = " & Convert.ToString(oFolder.Validated))
            SetKey(nodeTemp, "Folder", "Validated", oFolder.ID, 0)

            nodeTemp = parent.Nodes.Add("Verified = " & Convert.ToString(oFolder.Verified))
            SetKey(nodeTemp, "Folder", "Verified", oFolder.ID, 0)

            If strFolderClass.Length <> 0 And m_bHasAscentCaptureFeatures Then
                '*** Folder Index Field Count
                parent.Nodes.Add("IndexFieldCount =  " & Convert.ToString(oFolder.IndexFieldCount))

                '*** Folder Index Field collection
                nodeTemp = parent.Nodes.Add("IndexFieldCollection")
                Using oIndexFields As New ApiObjectWrapper(Of InteropServices.IndexFields)(oFolder.IndexFields)
                    If Not oIndexFields.IsNull Then
                        ShowFolderIndexFieldsProperties(nodeTemp, oIndexFields.WrappedObject, lFolderID)
                    End If
                End Using
            End If

            If bRecursive Then
                Using oDocs As New ApiObjectWrapper(Of InteropServices.Documents)(oFolder.Documents)
                    If Not oDocs.IsNull Then
                        nodeTemp = parent.Nodes.Add("Documents")
                        ShowDocumentsProperties(nodeTemp, oDocs.WrappedObject)
                    End If
                End Using

                Using oFolders As New ApiObjectWrapper(Of InteropServices.Folders)(oFolder.Folders)
                    If Not oFolders.IsNull Then
                        nodeTemp = parent.Nodes.Add("Folders")
                        ShowFoldersProperties(nodeTemp, oFolders.WrappedObject)
                    End If
                End Using
            End If
        End Sub

        '**************************************************
        '*** Function:  ShowFoldersProperties
        '*** Purpose:   Add all folder collection properties
        '*** Input:     nIndex is the parent's index
        '***            oFolders - the Folders object
        '*** Output:    none
        '**************************************************
        Private Sub ShowFoldersProperties(ByVal parent As TreeNode, ByRef oFolders As InteropServices.Folders)

            Dim nodeTemp As TreeNode

            '*** Count
            parent.Nodes.Add("Count = " & Convert.ToString(oFolders.Count))

            '*** Iterate over each folder
            Dim intNodeNum As Short
            intNodeNum = 1

            Try
                For Each oFolder As InteropServices.Folder In oFolders
                    Using oFolderWrapper As New ApiObjectWrapper(Of InteropServices.Folder)(oFolder)
                        '*** Add the parent node as the item number
                        nodeTemp = parent.Nodes.Add(Convert.ToString(intNodeNum))

                        '*** Add the sub-nodes
                        ShowFolderProperties(nodeTemp, oFolderWrapper.WrappedObject)

                        '*** Increment the item number
                        intNodeNum = intNodeNum + 1
                    End Using
                Next
            Catch ex As Exception
                Throw
            End Try

        End Sub

        '**************************************************
        '*** Function:  ShowPageProperties
        '*** Purpose:   Add to the tree control all properties
        '***            under the Document node
        '*** Input:     nIndex is the index of the parent node
        '***            oPage is the page to display
        '***            lDocID is the document ID
        '*** Output:    none
        '**************************************************
        Private Sub ShowPageProperties(ByVal parent As TreeNode, ByRef oPage As InteropServices.Page, ByRef lDocID As Integer)

            Dim nodeTemp As TreeNode

            parent.Nodes.Add("FileName = " & oPage.FileName)
            parent.Nodes.Add("OrderNumber = " & Convert.ToString(oPage.OrderNumber))

            nodeTemp = parent.Nodes.Add("OriginalFileName =  " & Convert.ToString(oPage.OriginalFileName))
            SetKey(nodeTemp, "Page", "OriginalFileName", oPage.OrderNumber, lDocID)

            nodeTemp = parent.Nodes.Add("Rejected =  " & Convert.ToString(oPage.Rejected))
            SetKey(nodeTemp, "Page", "Rejected", oPage.OrderNumber, lDocID)

            nodeTemp = parent.Nodes.Add("Note =  " & oPage.Note)
            SetKey(nodeTemp, "Page", "Note", oPage.OrderNumber, lDocID)

            '*** Show endorsing stuff if full refresh
            If FullRefresh() Then
                If m_bHasAscentCaptureFeatures Then
                    parent.Nodes.Add("EndorsingString =  " & oPage.EndorsingString)
                End If
                parent.Nodes.Add("ImageAddress =  " & oPage.ImageAddress)
                parent.Nodes.Add("RollNumber =  " & Convert.ToString(oPage.RollNumber))
            End If

            '*** Show page registration confidence if full refresh
            If FullRefresh() And m_bHasAscentCaptureFeatures Then
                parent.Nodes.Add("RegistrationConfidence =  " & Convert.ToString(oPage.RegistrationConfidence))
            End If

            parent.Nodes.Add("ID = " & Convert.ToString(oPage.ID))

            If FullRefresh() Then
                '*** Only show that the document reference is valid to prevent recursion
                Using oDoc As New ApiObjectWrapper(Of InteropServices.Document)(oPage.Document)
                    If Not oDoc.IsNull Then
                        parent.Nodes.Add("Document ID = " & Convert.ToString(oDoc.WrappedObject.ID))
                    End If
                End Using
            End If

        End Sub

        '**************************************************
        '*** Function:  ShowPagesProperties
        '*** Purpose:   Add all pages collection properties
        '*** Input:     nIndex is the parent's index
        '***            oPages - the pages object
        '***            lDocID is the document ID
        '*** Output:    none
        '**************************************************
        Private Sub ShowPagesProperties(ByVal parent As TreeNode, ByRef oPages As InteropServices.Pages, ByRef lDocID As Integer)

            Dim nodeTemp As TreeNode

            '*** Count
            parent.Nodes.Add("Count = " & Convert.ToString(oPages.Count))

            '*** 
            '*** Iterate over each page
            '*** 

            Dim intNodeNum As Short
            intNodeNum = 1

            Try
                For Each oPage As InteropServices.Page In oPages
                    Using oPageWrapper As New ApiObjectWrapper(Of InteropServices.Page)(oPage)
                        '*** Add the parent node as the item number
                        nodeTemp = parent.Nodes.Add(Convert.ToString(intNodeNum))

                        '*** Add the sub-nodes
                        ShowPageProperties(nodeTemp, oPageWrapper.WrappedObject, lDocID)

                        '*** Increment the item number
                        intNodeNum = intNodeNum + 1

                    End Using
                Next
            Catch ex As Exception
                Throw
            End Try

        End Sub

        '**************************************************
        '*** Function:  ShowCustomProperty
        '*** Purpose:   Shows custom property info
        '*** Input:     nIndex is the index of the parent node
        '***            oCustomProperty - the custom property object
        '***            lDocID is the document ID
        '*** Output:    none
        '**************************************************
        Private Sub ShowCustomProperty(ByVal parent As TreeNode, ByRef oCustomProperty As InteropServices.CustomProperty, ByRef lDocID As Integer)

            Dim nodeTemp As TreeNode

            '*** Name
            parent.Nodes.Add("Name = " & Convert.ToString(oCustomProperty.Name))

            '*** OrderNumber
            parent.Nodes.Add("OrderNumber = " & Convert.ToString(oCustomProperty.OrderNumber))

            '*** Value
            nodeTemp = parent.Nodes.Add("Value = " & Convert.ToString(oCustomProperty.Value))
            If lDocID >= 0 Then
                SetKey(nodeTemp, "CustomProperty", "Value", oCustomProperty.OrderNumber, lDocID)
            End If

        End Sub

        '**************************************************
        '*** Function:  ShowCustomProperties
        '*** Purpose:   Show a custom properties collection in the tree
        '*** Input:     nIndex is the index of the parent
        '***            oPages - the pages object
        '***            lDocID is the document ID
        '*** Output:    none
        '**************************************************
        Private Sub ShowCustomProperties(ByVal parent As TreeNode, ByRef oCustomProperties As InteropServices.CustomProperties, ByRef lDocID As Integer)

            Dim nodeTemp As TreeNode

            '*** Count
            parent.Nodes.Add("Count = " & Convert.ToString(oCustomProperties.Count))

            '*** Iterate over each page
            Dim intNodeNum As Short
            intNodeNum = 1

            Try
                For Each oCustomProperty As InteropServices.CustomProperty In oCustomProperties
                    Using oCustomPropertyWrapper As New ApiObjectWrapper(Of InteropServices.CustomProperty)(oCustomProperty)
                        '*** Add the parent node as the item number
                        nodeTemp = parent.Nodes.Add(Convert.ToString(intNodeNum))

                        '*** Add the sub-nodes
                        ShowCustomProperty(nodeTemp, oCustomPropertyWrapper.WrappedObject, lDocID)

                        '*** Increment the item number
                        intNodeNum = intNodeNum + 1
                    End Using
                Next
            Catch ex As Exception
                Throw
            End Try

        End Sub

        '**************************************************
        '*** Function:  ShowAssignedReleaseScript
        '*** Purpose:   Shows assigned export connector info
        '*** Input:     nIndex is the index of the parent node
        '***            oAsnReleaseScript - the export connector
        '***            lDocID is the document ID
        '*** Output:    none
        '**************************************************
        Private Sub ShowAssignedReleaseScript(ByVal parent As TreeNode, ByRef oAsnReleaseScript As InteropServices.AsnReleaseScript, ByRef lDocID As Integer)

            Dim nodeTemp As TreeNode

            parent.Nodes.Add("Name = " & Convert.ToString(oAsnReleaseScript.Name))
            parent.Nodes.Add("ReleaseScriptName = " & Convert.ToString(oAsnReleaseScript.ReleaseScriptName))
            parent.Nodes.Add("OrderNumber = " & Convert.ToString(oAsnReleaseScript.OrderNumber))

            '*** Custom Property Count
            parent.Nodes.Add("CustomPropertyCount =  " & Convert.ToString(oAsnReleaseScript.CustomPropertyCount))

            '*** Custom Property Collection
            nodeTemp = parent.Nodes.Add("CustomPropertyCollection")

            '*** For now, its too complex to try to update through this collection
            Using oCustomProperties As New ApiObjectWrapper(Of InteropServices.CustomProperties)(oAsnReleaseScript.CustomProperties)
                If Not oCustomProperties.IsNull Then
                    ShowCustomProperties(nodeTemp, oCustomProperties.WrappedObject, -1)
                End If
            End Using
        End Sub

        '**************************************************
        '*** Function:  ShowAssignedReleaseScripts
        '*** Purpose:   Show an assigned export connectors collection in the tree
        '*** Input:     nIndex is the index of the parent
        '***            oAsnReleaseScripts - the assignment collection
        '***            lDocID is the document ID
        '*** Output:    none
        '**************************************************
        Private Sub ShowAssignedReleaseScripts(ByVal parent As TreeNode, ByRef oAsnReleaseScripts As InteropServices.AsnReleaseScripts, ByRef lDocID As Integer)

            Dim nodeTemp As TreeNode

            '*** Count
            parent.Nodes.Add("Count = " & Convert.ToString(oAsnReleaseScripts.Count))

            '*** 
            '*** Iterate over each page
            '*** 

            Dim intNodeNum As Short
            intNodeNum = 1

            Try
                For Each oAsnReleaseScript As InteropServices.AsnReleaseScript In oAsnReleaseScripts
                    Using oAsnReleaseScriptWrapper As New ApiObjectWrapper(Of InteropServices.AsnReleaseScript)(oAsnReleaseScript)
                        '*** Add the parent node as the item number
                        nodeTemp = parent.Nodes.Add(Convert.ToString(intNodeNum))

                        '*** Add the sub-nodes
                        ShowAssignedReleaseScript(nodeTemp, oAsnReleaseScriptWrapper.WrappedObject, lDocID)

                        '*** Increment the item number
                        intNodeNum = intNodeNum + 1

                    End Using
                Next
            Catch ex As Exception
                Throw
            End Try

        End Sub

        '**************************************************
        '*** Function:  ShowDocIndexFieldProperties
        '*** Purpose:   Show all document index field properties
        '*** Input:     nIndex is the index of the parent
        '***            oPage - the page object
        '***            lDocID is the document ID
        '*** Output:    none
        '**************************************************
        Private Sub ShowDocIndexFieldProperties(ByVal parent As TreeNode, ByRef oIndexField As InteropServices.IndexField, ByRef lDocID As Integer)

            Dim nodeTemp As TreeNode

            parent.Nodes.Add("Name = " & Convert.ToString(oIndexField.Name))
            parent.Nodes.Add("DisplayLabel = " & Convert.ToString(oIndexField.DisplayLabel))
            parent.Nodes.Add("OrderNumber = " & Convert.ToString(oIndexField.OrderNumber))
            parent.Nodes.Add("TypeName =  " & Convert.ToString(oIndexField.TypeName))
            parent.Nodes.Add("Description =  " & Convert.ToString(oIndexField.Description))
            parent.Nodes.Add("Numeric =  " & Convert.ToString(oIndexField.Numeric))

            '*** 
            '*** Numeric fields throw if you try to get length, and non-numeric fields throw
            '*** if you try to get numeric precision and numeric scale
            '*** 

            If oIndexField.Numeric Then
                parent.Nodes.Add("NumericPrecision =  " & Convert.ToString(oIndexField.NumericPrecision))
                parent.Nodes.Add("NumericScale =  " & Convert.ToString(oIndexField.NumericScale))
            Else '*** Character type
                parent.Nodes.Add("Length =  " & Convert.ToString(oIndexField.Length))
            End If

            parent.Nodes.Add("SqlType =  " & Convert.ToString(oIndexField.SqlType))
            parent.Nodes.Add("Hidden =  " & Convert.ToString(oIndexField.Hidden))
            parent.Nodes.Add("Sticky =  " & Convert.ToString(oIndexField.Sticky))
            parent.Nodes.Add("Required =  " & Convert.ToString(oIndexField.Required))
            parent.Nodes.Add("Total =  " & Convert.ToString(oIndexField.Total))

            nodeTemp = parent.Nodes.Add("Value =  " & Convert.ToString(oIndexField.Value))
            SetKey(nodeTemp, "IndexField", "Value", oIndexField.OrderNumber, lDocID)

            nodeTemp = parent.Nodes.Add("Confidence =  " & Convert.ToString(oIndexField.Confidence))
            SetKey(nodeTemp, "IndexField", "Confidence", oIndexField.OrderNumber, lDocID)

            parent.Nodes.Add("DefaultValue =  " & Convert.ToString(oIndexField.DefaultValue))

            '*** Zone stuff
            parent.Nodes.Add("ZoneLeft =  " & Convert.ToString(oIndexField.ZoneLeft))
            parent.Nodes.Add("ZoneTop =  " & Convert.ToString(oIndexField.ZoneTop))
            parent.Nodes.Add("ZoneWidth =  " & Convert.ToString(oIndexField.ZoneWidth))
            parent.Nodes.Add("ZoneHeight =  " & Convert.ToString(oIndexField.ZoneHeight))

            '*** Suggested Value Stuff
            parent.Nodes.Add("SuggestedValueCount =  " & Convert.ToString(oIndexField.SuggestedValueCount))

            If FullRefresh() Then
                nodeTemp = parent.Nodes.Add("SuggestedValues")
                Using oSuggestedValues As New ApiObjectWrapper(Of InteropServices.SuggestedValues)(oIndexField.SuggestedValues)
                    If Not oSuggestedValues.IsNull Then
                        ShowSuggestedValuesProperties(nodeTemp, oSuggestedValues.WrappedObject)
                    End If
                End Using
                parent.Nodes.Add("SuggestedValuesForceMatch =  " & Convert.ToString(oIndexField.SuggestedValuesForceMatch))
                parent.Nodes.Add("SuggestedValuesForceMatchCaseSensitive =  " & Convert.ToString(oIndexField.SuggestedValuesForceMatchCaseSensitive))
            End If

            '*** Page - only on full dump
            If FullRefresh() Then
                Using oPage As New ApiObjectWrapper(Of InteropServices.Page)(oIndexField.Page)
                    If Not oPage.IsNull Then
                        nodeTemp = parent.Nodes.Add("Page")
                        ShowPageProperties(nodeTemp, oPage.WrappedObject, lDocID)
                    End If
                End Using
            End If

        End Sub

        '**************************************************
        '*** Function:  ShowDocIndexFieldsProperties
        '*** Purpose:   Add all Document Index Field collection properties
        '*** Input:     nIndex - Index of parent
        '***            oPages - the IndexFields object
        '*** Output:    none
        '**************************************************
        Private Sub ShowDocIndexFieldsProperties(ByVal parent As TreeNode, ByRef oIndexFields As InteropServices.IndexFields, ByRef lDocID As Integer)

            Dim nodeTemp As TreeNode

            '*** Count
            parent.Nodes.Add("Count = " & Convert.ToString(oIndexFields.Count))

            '*** Iterate over each index field
            Dim intNodeNum As Short
            intNodeNum = 1

            Try
                For Each oIndexField As InteropServices.IndexField In oIndexFields
                    Using oIndexFieldWrapper As New ApiObjectWrapper(Of InteropServices.IndexField)(oIndexField)
                        '*** Add the parent node as the item number
                        nodeTemp = parent.Nodes.Add(Convert.ToString(intNodeNum))

                        '*** Add the sub-nodes
                        ShowDocIndexFieldProperties(nodeTemp, oIndexFieldWrapper.WrappedObject, lDocID)

                        '*** Increment the item number
                        intNodeNum = intNodeNum + 1
                    End Using
                Next
            Catch ex As Exception
                Throw
            End Try

        End Sub

        '**************************************************
        '*** Function:  ShowFolderIndexFieldProperties
        '*** Purpose:   Show all folder index field properties
        '*** Input:     nIndex is the index of the parent
        '***            oIndexField - the IndexField object
        '***            lFolderID is the folder ID
        '*** Output:    none
        '**************************************************
        Private Sub ShowFolderIndexFieldProperties(ByVal parent As TreeNode, ByRef oIndexField As InteropServices.IndexField, ByRef lFolderID As Integer)

            Dim nodeTemp As TreeNode

            parent.Nodes.Add("Name = " & Convert.ToString(oIndexField.Name))
            parent.Nodes.Add("DisplayLabel = " & Convert.ToString(oIndexField.DisplayLabel))
            parent.Nodes.Add("OrderNumber = " & Convert.ToString(oIndexField.OrderNumber))
            parent.Nodes.Add("TypeName =  " & Convert.ToString(oIndexField.TypeName))
            parent.Nodes.Add("Description =  " & Convert.ToString(oIndexField.Description))
            parent.Nodes.Add("Numeric =  " & Convert.ToString(oIndexField.Numeric))

            '*** 
            '*** Numeric fields throw if you try to get length, and non-numeric fields throw
            '*** if you try to get numeric precision and numeric scale
            '*** 

            If oIndexField.Numeric Then
                parent.Nodes.Add("NumericPrecision =  " & Convert.ToString(oIndexField.NumericPrecision))
                parent.Nodes.Add("NumericScale =  " & Convert.ToString(oIndexField.NumericScale))
            Else '*** Character type
                parent.Nodes.Add("Length =  " & Convert.ToString(oIndexField.Length))
            End If

            parent.Nodes.Add("SqlType =  " & Convert.ToString(oIndexField.SqlType))
            parent.Nodes.Add("Hidden =  " & Convert.ToString(oIndexField.Hidden))
            parent.Nodes.Add("Sticky =  " & Convert.ToString(oIndexField.Sticky))
            parent.Nodes.Add("Required =  " & Convert.ToString(oIndexField.Required))

            nodeTemp = parent.Nodes.Add("Value =  " & Convert.ToString(oIndexField.Value))
            SetKey(nodeTemp, "IndexField", "Value", oIndexField.OrderNumber, lFolderID)

            nodeTemp = parent.Nodes.Add("Confidence =  " & Convert.ToString(oIndexField.Confidence))
            SetKey(nodeTemp, "IndexField", "Confidence", oIndexField.OrderNumber, lFolderID)

            parent.Nodes.Add("DefaultValue =  " & Convert.ToString(oIndexField.DefaultValue))

            '*** 
            '*** Suggested Value Stuff
            '*** 

            parent.Nodes.Add("SuggestedValueCount =  " & Convert.ToString(oIndexField.SuggestedValueCount))

            If FullRefresh() Then
                Using oSuggestedValues As New ApiObjectWrapper(Of InteropServices.SuggestedValues)(oIndexField.SuggestedValues)
                    If Not oSuggestedValues.IsNull Then
                        nodeTemp = parent.Nodes.Add("SuggestedValues")
                        ShowSuggestedValuesProperties(nodeTemp, oSuggestedValues.WrappedObject)
                    End If
                End Using
                parent.Nodes.Add("SuggestedValuesForceMatch =  " & Convert.ToString(oIndexField.SuggestedValuesForceMatch))
                parent.Nodes.Add("SuggestedValuesForceMatchCaseSensitive =  " & Convert.ToString(oIndexField.SuggestedValuesForceMatchCaseSensitive))
            End If

        End Sub

        '**************************************************
        '*** Function:  ShowFolderIndexFieldsProperties
        '*** Purpose:   Add all Folder Index Field collection properties
        '*** Input:     nIndex - Index of parent
        '***            oIndexFields - the IndexFields object
        '***            lFolderID - the folder ID
        '*** Output:    none
        '**************************************************
        Private Sub ShowFolderIndexFieldsProperties(ByVal parent As TreeNode, ByRef oIndexFields As InteropServices.IndexFields, ByRef lFolderID As Integer)

            Dim nodeTemp As TreeNode

            '*** Count
            parent.Nodes.Add("Count = " & Convert.ToString(oIndexFields.Count))

            '*** Iterate over each index field
            Dim intNodeNum As Short
            intNodeNum = 1

            Try
                For Each oIndexField As InteropServices.IndexField In oIndexFields
                    Using oIndexFieldWrapper As New ApiObjectWrapper(Of InteropServices.IndexField)(oIndexField)
                        '*** Add the parent node as the item number
                        nodeTemp = parent.Nodes.Add(Convert.ToString(intNodeNum))

                        '*** Add the sub-nodes
                        ShowFolderIndexFieldProperties(nodeTemp, oIndexFieldWrapper.WrappedObject, lFolderID)

                        '*** Increment the item number
                        intNodeNum = intNodeNum + 1

                    End Using
                Next
            Catch ex As Exception
                Throw
            End Try

        End Sub

        '**************************************************
        '*** Function:  ShowSuggestedValueProperties
        '*** Purpose:   Shows suggested value properties
        '*** Input:     nIndex is the index of the parent node
        '***            oSuggestedValue - the custom property object
        '*** Output:    none
        '**************************************************
        Private Sub ShowSuggestedValueProperties(ByVal parent As TreeNode, ByRef oSuggestedValue As InteropServices.SuggestedValue)

            '*** OrderNumber
            parent.Nodes.Add("OrderNumber = " & Convert.ToString(oSuggestedValue.OrderNumber))

            '*** Value
            parent.Nodes.Add("Value = " & Convert.ToString(oSuggestedValue.Value))

        End Sub

        '**************************************************
        '*** Function:  ShowSuggestedValuesProperties
        '*** Purpose:   Show a suggested value collection in the tree
        '*** Input:     nIndex is the index of the parent
        '***            oSuggestedValues - the suggested values object
        '*** Output:    none
        '**************************************************
        Private Sub ShowSuggestedValuesProperties(ByVal parent As TreeNode, ByRef oSuggestedValues As InteropServices.SuggestedValues)

            Dim nodeTemp As TreeNode

            '*** Count
            parent.Nodes.Add("Count = " & Convert.ToString(oSuggestedValues.Count))

            '*** Iterate over each page
            Dim intNodeNum As Short
            intNodeNum = 1

            Try
                For Each oSuggestedValue As InteropServices.SuggestedValue In oSuggestedValues
                    Using oSuggestedValueWrapper As New ApiObjectWrapper(Of InteropServices.SuggestedValue)(oSuggestedValue)
                        '*** Add the parent node as the item number
                        nodeTemp = parent.Nodes.Add(Convert.ToString(intNodeNum))

                        '*** Add the sub-nodes
                        ShowSuggestedValueProperties(nodeTemp, oSuggestedValueWrapper.WrappedObject)

                        '*** Increment the item number
                        intNodeNum = intNodeNum + 1

                    End Using
                Next
            Catch ex As Exception
                Throw
            End Try

        End Sub

        '**************************************************
        '*** Routine:   FindFolderByID
        '*** Purpose:   Allow the user to find the folder by
        '***            folder ID in the batch.
        '*** Input:     oFolders - Folders collection
        '***            lFolderID - folder ID to look for
        '*** Output:    Folder object if found, otherwise Nothing
        '**************************************************
        Private Function FindFolderByID(ByRef oFolders As InteropServices.Folders, ByRef lFolderID As Integer) As InteropServices.Folder

            '*** Find the folder ID at the current level
            For Each oFolder As InteropServices.Folder In oFolders
                If lFolderID = oFolder.ID Then
                    Return oFolder
                End If
                oFolder.Dispose()
            Next

            '*** Otherwise, search under the child folders
            For Each oFolder As InteropServices.Folder In oFolders
                Using oFolderWrapper As New ApiObjectWrapper(Of InteropServices.Folder)(oFolder)
                    Using oSubFolders As New ApiObjectWrapper(Of InteropServices.Folders)(oFolderWrapper.WrappedObject.Folders)

                        If Not oSubFolders.IsNull Then
                            Dim oTargetFolder As InteropServices.Folder = FindFolderByID(oSubFolders.WrappedObject, lFolderID)

                            If Not IsNothing(oTargetFolder) Then
                                Return oTargetFolder
                            End If
                        End If
                    End Using
                End Using
            Next
            Return Nothing

        End Function

        '**************************************************
        '*** Routine:   FindFolderByorderID
        '*** Purpose:   Allow the user to find the folder by
        '***            folder order ID in the folder list.
        '*** Input:     oFolders - Folders collection
        '***            lFolderOrderID - folder order ID to look for
        '*** Output:    Folder object if found, otherwise Nothing
        '**************************************************
        Private Function FindFolderByOrderID(ByRef oFolders As InteropServices.Folders, ByRef lFolderOrderID As Integer) As InteropServices.Folder

            Try
                '*** Find the folder order ID at the current level
                For Each oFolder As InteropServices.Folder In oFolders
                    If lFolderOrderID = oFolder.OrderNumber Then
                        Return oFolder
                    End If
                    oFolder.Dispose()
                Next
                Return Nothing
            Catch ex As Exception
                Throw
            End Try

        End Function

        '**************************************************
        '*** Routine:   cmdAddMenu_Click()
        '*** Purpose:   Allow the user to add menus
        '*** Input:     none
        '*** Output:    none
        '**************************************************
        Private Sub cmdAddMenu_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdAddMenu.Click

            Dim oAddMenuForm As AddMenuForm

            Try
                oAddMenuForm = New AddMenuForm(m_oApp, m_oMenuCollection)
                oAddMenuForm.ShowDialog(Me)

                Dim oMenuItem As MenuItem
                For Each oMenuItem In m_oMenuCollection
                    LogEvent("Added = " & oMenuItem.strMenu & ", " & oMenuItem.strLocation)
                Next oMenuItem
            Catch ex As Exception
                ExceptionHandler.HandleException("AddMenu Error: ", ex)
            Finally
                If Not IsNothing(oAddMenuForm) Then
                    oAddMenuForm.Dispose()
                    oAddMenuForm = Nothing
                End If
            End Try
        End Sub

        '**************************************************
        '*** Routine:   cmdContext_Click
        '*** Purpose:   Change the active context
        '*** Input:     none
        '*** Output:    none
        '**************************************************
        Private Sub cmdContext_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdContext.Click

            Try
                Dim bResult As Boolean
                bResult = False

                '*** Get the number
                Dim lNewNumber As Integer
                lNewNumber = Convert.ToInt32(txtContext.Text)

                '*** Change the context
                If optDocument.Checked Then
                    bResult = m_oApp.SetActiveContext(lNewNumber, 0, 0)
                ElseIf optPage.Checked Then
                    bResult = m_oApp.SetActiveContext(0, lNewNumber, 0)
                ElseIf optField.Checked Then
                    bResult = m_oApp.SetActiveContext(0, 0, lNewNumber)
                End If

                '*** Report back if it failed
                If Not bResult Then
                    MsgBox("Could not change context - SetActiveContext returned False")
                End If
            Catch ex As Exception
                ExceptionHandler.HandleException("Unable to set context: ", ex)
            End Try

        End Sub

        '**************************************************
        '*** Routine:   EditBatch
        '*** Purpose:   Edit the batch property
        '*** Input:     strProperty is the property to edit
        '***            strValue is the new value to assign
        '*** Output:    none
        '**************************************************
        Private Sub EditBatch(ByVal strProperty As String, ByVal strValue As String)

            Try
                '*** Batch properties
                Select Case strProperty
                    Case "Description"
                        m_oApp.ActiveBatch.Description = strValue
                    Case "Priority"
                        m_oApp.ActiveBatch.Priority = Convert.ToInt32(strValue)
                    Case "AutomaticSeparationAndFormID"
                        m_oApp.ActiveBatch.AutomaticSeparationAndFormID = Convert.ToBoolean(strValue)
                End Select
                RefreshTree() ' Force refresh
            Catch ex As Exception
                Throw
            End Try

        End Sub

        '**************************************************
        '*** Routine:   EditBatchField
        '*** Purpose:   Edit the batch field
        '*** Input:     strProperty is the property to edit
        '***            strValue is the new value to assign
        '***            lIndex is the index of the object
        '*** Output:    none
        '**************************************************
        Private Sub EditBatchField(ByVal strProperty As String, ByVal strValue As String, ByVal lIndex As Integer)

            Using oBatchField As New ApiObjectWrapper(Of InteropServices.BatchField)(GetActiveBatchBatchFieldByIndex(lIndex))
                '*** Batch Field properties
                If Not oBatchField.IsNull Then
                    Select Case strProperty
                        Case "Value"
                            oBatchField.WrappedObject.Value = strValue
                    End Select
                    RefreshTree() ' Force refresh
                End If
            End Using
        End Sub

        '**************************************************
        '*** Routine:   GetActiveBatchBatchFieldByIndex
        '*** Purpose:   Retrieves the batch field by its index
        '*** Input:     
        '***            lIndex is the index of the object
        '*** Output:    BatchField
        '**************************************************
        Private Function GetActiveBatchBatchFieldByIndex(ByVal lIndex As Integer) As InteropServices.BatchField
            Using oActiveBatch As InteropServices.Batch = m_oApp.ActiveBatch
                Using oBatchFields As New ApiObjectWrapper(Of InteropServices.BatchFields)(oActiveBatch.BatchFields)
                    If Not oBatchFields.IsNull Then
                        Return oBatchFields.WrappedObject.Item(lIndex)
                    End If
                End Using
            End Using
            Return Nothing
        End Function

        '**************************************************
        '*** Routine:   EditExpectedBatchTotal
        '*** Purpose:   Edit the batch total
        '*** Input:     strProperty is the property to edit
        '***            strValue is the new value to assign
        '***            lIndex is the index of the object
        '*** Output:    none
        '**************************************************
        Private Sub EditExpectedBatchTotal(ByVal strProperty As String, ByVal strValue As String, ByVal lIndex As Integer)

            Using oExpectedBatchTotal As New ApiObjectWrapper(Of InteropServices.ExpectedBatchTotal)(GetActiveBatchExpectedBatchTotalByIndex(lIndex))
                If Not oExpectedBatchTotal.IsNull Then
                    '*** Batch Field properties
                    Select Case strProperty
                        Case "Value"
                            oExpectedBatchTotal.WrappedObject.Value = strValue
                    End Select
                    RefreshTree() ' Force refresh
                End If
            End Using
        End Sub

        '**************************************************
        '*** Routine:   GetActiveBatchExpectedBatchTotalByIndex
        '*** Purpose:   Retrieves the batch total by its index
        '*** Input:     
        '***            lIndex is the index of the object
        '*** Output:    ExpectedBatchTotal
        '**************************************************
        Private Function GetActiveBatchExpectedBatchTotalByIndex(ByVal lIndex As Integer) As InteropServices.ExpectedBatchTotal

            Using oActiveBatch As InteropServices.Batch = m_oApp.ActiveBatch
                Using oExpectedBatchTotals As New ApiObjectWrapper(Of InteropServices.ExpectedBatchTotals)(oActiveBatch.ExpectedBatchTotals)
                    If Not oExpectedBatchTotals.IsNull Then
                        Return oExpectedBatchTotals.WrappedObject.Item(lIndex)
                    End If
                End Using
                Return Nothing
            End Using

        End Function
        '**************************************************
        '*** Routine:   EditDocument
        '*** Purpose:   Edit the document
        '*** Input:     strProperty is the property to edit
        '***            strValue is the new value to assign
        '***            lIndex is the index of the object
        '*** Output:    none
        '**************************************************
        Private Sub EditDocument(ByVal strProperty As String, ByVal strValue As String, ByVal lIndex As Integer)

            Try
                Using oActiveBatch As New ApiObjectWrapper(Of InteropServices.Batch)(m_oApp.ActiveBatch)
                    Using oDoc As New ApiObjectWrapper(Of InteropServices.Document)(GetActiveBatchDocumentByIndex(lIndex))
                        If Not oDoc.IsNull Then
                            '*** Document properties
                            Select Case strProperty
                                Case "Note"
                                    oDoc.WrappedObject.Note = strValue
                                Case "Rejected"
                                    oDoc.WrappedObject.Rejected = Convert.ToBoolean(strValue)
                                Case "FormType"
                                    Using oFormTypes As New ApiObjectWrapper(Of InteropServices.FormTypes)(oActiveBatch.WrappedObject.FormTypes)
                                        If Not oFormTypes.IsNull Then
                                            Dim oFormType As InteropServices.FormType = Nothing
                                            Try
                                                oFormType = oFormTypes.WrappedObject.Item(strValue)
                                            Catch ex As Exception
                                                oFormType = Nothing
                                            End Try

                                            Using oFormTypeWrap As New ApiObjectWrapper(Of InteropServices.FormType)(oFormType)
                                                oDoc.WrappedObject.FormType = oFormTypeWrap.WrappedObject
                                            End Using
                                        End If
                                    End Using
                            End Select
                        End If
                    End Using
                End Using
            Catch ex As Exception
                Throw
            End Try

        End Sub

        '**************************************************
        '*** Routine:   EditFolder
        '*** Purpose:   Edit the folder
        '*** Input:     strProperty is the property to edit
        '***            strValue is the new value to assign
        '***            lIndex is the index of the object
        '*** Output:    none
        '**************************************************
        Private Sub EditFolder(ByVal strProperty As String, ByVal strValue As String, ByVal lIndex As Integer)

            Try
                Using oActiveBatch As New ApiObjectWrapper(Of InteropServices.Batch)(m_oApp.ActiveBatch)
                    Using oFolders As New ApiObjectWrapper(Of InteropServices.Folders)(oActiveBatch.WrappedObject.Folders)
                        If Not oFolders.IsNull Then
                            Using oFolder As New ApiObjectWrapper(Of InteropServices.Folder)(FindFolderByID(oFolders.WrappedObject, lIndex))
                                If Not oFolder.IsNull Then
                                    '*** Folder properties
                                    Select Case strProperty
                                        Case "Validated"
                                            oFolder.WrappedObject.Validated = Convert.ToBoolean(strValue)
                                        Case "Verified"
                                            oFolder.WrappedObject.Verified = Convert.ToBoolean(strValue)
                                    End Select
                                    RefreshTree() ' Force refresh
                                End If
                            End Using
                        End If
                    End Using
                End Using
            Catch ex As Exception
                Throw
            End Try

        End Sub

        '**************************************************
        '*** Routine:   EditPage
        '*** Purpose:   Edit the page
        '*** Input:     strProperty is the property to edit
        '***            strValue is the new value to assign
        '***            lIndex is the index of the object
        '***            lParentIndex is the index of the parent
        '*** Output:    none
        '**************************************************
        Private Sub EditPage(ByVal strProperty As String, ByVal strValue As String, ByVal lIndex As Integer, ByVal lParentIndex As Integer)

            Using oActiveBatch As New ApiObjectWrapper(Of InteropServices.Batch)(m_oApp.ActiveBatch)
                Dim oPages As InteropServices.Pages = Nothing
                '*** Page properties
                If lParentIndex Then
                    Using oDoc As New ApiObjectWrapper(Of InteropServices.Document)(GetActiveBatchDocumentByIndex(lParentIndex))
                        If Not oDoc.IsNull Then
                            oPages = oDoc.WrappedObject.Pages
                        End If
                    End Using
                Else
                    oPages = oActiveBatch.WrappedObject.LoosePages
                End If
                Using oPagesWrap As New ApiObjectWrapper(Of InteropServices.Pages)(oPages)
                    If Not oPagesWrap.IsNull Then
                        Dim oPage As New ApiObjectWrapper(Of InteropServices.Page)(oPagesWrap.WrappedObject.Item(lIndex))
                        If Not oPage.IsNull Then
                            Select Case strProperty
                                Case "OriginalFileName"
                                    oPage.WrappedObject.OriginalFileName = strValue
                                Case "Note"
                                    oPage.WrappedObject.Note = strValue
                                Case "Rejected"
                                    oPage.WrappedObject.Rejected = Convert.ToBoolean(strValue)
                            End Select
                        End If
                    End If
                End Using
            End Using
        End Sub

        '**************************************************
        '*** Routine:   EditIndexField
        '*** Purpose:   Edit the index field
        '*** Input:     strProperty is the property to edit
        '***            strValue is the new value to assign
        '***            lIndex is the index of the object
        '***            lParentIndex is the index of the parent
        '*** Output:    none
        '**************************************************
        Private Sub EditIndexField(ByVal strProperty As String, ByVal strValue As String, ByVal lIndex As Integer, ByVal lParentIndex As Integer)
            Using oDocWrapper As New ApiObjectWrapper(Of InteropServices.Document)(GetActiveBatchDocumentByIndex(lParentIndex))
                If Not oDocWrapper.IsNull Then
                    Dim oIndexField As InteropServices.IndexField = GetDocumentIndexFieldByIndex(oDocWrapper.WrappedObject, lIndex)
                    Using oIndexFieldWrapper As New ApiObjectWrapper(Of InteropServices.IndexField)(oIndexField)
                        If Not oIndexFieldWrapper.IsNull Then
                            Select Case strProperty
                                Case "Value"
                                    oIndexFieldWrapper.WrappedObject.Value = strValue
                                Case "Confidence"
                                    oIndexFieldWrapper.WrappedObject.Confidence = CShort(strValue)
                            End Select
                            RefreshTree() ' Force refresh
                        End If
                    End Using
                End If
            End Using
        End Sub

        '**************************************************
        '*** Routine:   EditCustomProperty
        '*** Purpose:   Edit the custom property
        '*** Input:     strProperty is the property to edit
        '***            strValue is the new value to assign
        '***            lIndex is the index of the object
        '***            lParentIndex is the index of the parent
        '*** Output:    none
        '**************************************************
        Private Sub EditCustomProperty(ByVal strProperty As String, ByVal strValue As String, ByVal lIndex As Integer, ByVal lParentIndex As Integer)

            '*** Custom Property properties
            Using oDoc As New ApiObjectWrapper(Of InteropServices.Document)(GetActiveBatchDocumentByIndex(lParentIndex))
                If Not oDoc.IsNull Then
                    Dim oCustomProp As New ApiObjectWrapper(Of InteropServices.CustomProperty)(GetDocumentCustomPropertyByIndex(oDoc.WrappedObject, lIndex))
                    If Not oCustomProp.IsNull Then
                        Select Case strProperty
                            Case "Value"
                                oCustomProp.WrappedObject.Value = strValue
                        End Select
                        RefreshTree() ' Force refresh
                    End If
                End If
            End Using
        End Sub

        Private Function GetActiveBatchDocumentByIndex(ByVal lIndex As Integer) As InteropServices.Document
            Using oActiveBatch As New ApiObjectWrapper(Of InteropServices.Batch)(m_oApp.ActiveBatch)
                Using oDocs As New ApiObjectWrapper(Of InteropServices.Documents)(oActiveBatch.WrappedObject.Documents)
                    If Not oDocs.IsNull Then
                        Return oDocs.WrappedObject.Item(lIndex)
                    End If
                End Using
            End Using
            Return Nothing
        End Function

        Private Function GetDocumentIndexFieldByIndex(ByVal oDocument As InteropServices.Document, ByVal lIndex As Integer) As InteropServices.IndexField
            Using oIndexFields As New ApiObjectWrapper(Of InteropServices.IndexFields)(oDocument.IndexFields)
                If Not oIndexFields.IsNull Then
                    Return oIndexFields.WrappedObject.Item(lIndex)
                End If
                Return Nothing
            End Using
        End Function

        Private Function GetDocumentCustomPropertyByIndex(ByVal oDocument As InteropServices.Document, ByVal lIndex As Integer) As InteropServices.CustomProperty
            Using oCustomProperties As New ApiObjectWrapper(Of InteropServices.CustomProperties)(oDocument.CustomProperties)
                If Not oCustomProperties.IsNull Then
                    Return oCustomProperties.WrappedObject.Item(lIndex)
                End If
                Return Nothing
            End Using
        End Function

        '**************************************************
        '*** Routine:   cmdEdit_Click
        '*** Purpose:   Try to edit the currently selected tree item
        '*** Input:     none
        '*** Output:    none
        '**************************************************
        Private Sub cmdEdit_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdEdit.Click

            Dim frmEntry As DataEntryForm

            '*** Must have error handler to catch type and/or overflow problems
            Try
                Dim nodx As TreeNode

                '*** Get the selected node
                nodx = TreeView1.SelectedNode
                If IsNothing(nodx) Then
                    MsgBox("No element is selected")
                    Exit Sub
                End If

                Dim strType As String
                Dim strProperty As String
                Dim lIndex As Integer
                Dim lParentIndex As Integer

                '*** Get the key from the node
                GetKey(nodx, strType, strProperty, lIndex, lParentIndex)

                '*** Make sure we can edit this property
                If String.IsNullOrEmpty(strType) Or strProperty.Length = 0 Then
                    MsgBox("That property cannot be edited")
                    Exit Sub
                End If

                frmEntry = New DataEntryForm

                '*** Set the caption
                frmEntry.EntryCaption = "Enter new value for the '" & strProperty & "' property:"

                '*** Scavenge the value based on the display tag
                Dim strValue As String
                strValue = LTrim(Field(nodx.Text, "=", 2))
                frmEntry.Value = strValue

                '*** Show the form modally
                frmEntry.ShowDialog(Me)

                '*** Exit if cancel
                If Not frmEntry.OK Then Exit Sub

                strValue = frmEntry.Value

                Select Case strType
                    Case "Batch"
                        EditBatch(strProperty, strValue)

                    Case "BatchField"
                        EditBatchField(strProperty, strValue, lIndex)

                    Case "ExpectedBatchTotal"
                        EditExpectedBatchTotal(strProperty, strValue, lIndex)

                    Case "Document"
                        EditDocument(strProperty, strValue, lIndex)

                    Case "Folder"
                        EditFolder(strProperty, strValue, lIndex)

                    Case "Page"
                        EditPage(strProperty, strValue, lIndex, lParentIndex)

                    Case "IndexField"
                        EditIndexField(strProperty, strValue, lIndex, lParentIndex)

                    Case "CustomProperty"

                End Select
            Catch ex As Exception
                ExceptionHandler.HandleException("Unable to set property: ", ex)
            Finally
                If Not IsNothing(frmEntry) Then
                    frmEntry.Dispose()
                    frmEntry = Nothing
                End If
            End Try

        End Sub

        '**************************************************
        '*** Routine:   ResetKeySequence
        '*** Purpose:   Reset the unique key sequence - Use when tree refreshed
        '*** Input:     none
        '*** Output:    none
        '**************************************************
        Private Sub ResetKeySequence()
            m_nNodeKeySeq = 0
        End Sub

        '**************************************************
        '*** Routine:   SetKey
        '*** Purpose:   Sets a key on a tree node so it can be edited
        '*** Input:     nodx is the tree node
        '***            strType is the node type
        '***            strProperty is the property of the node
        '***            lIndex is the index of the object
        '***            lParentIndex is the index of the parent
        '*** Output:    none
        '**************************************************
        Private Sub SetKey(ByRef nodx As TreeNode, ByVal strType As String, ByVal strProperty As String, ByVal lIndex As Integer, ByVal lParentIndex As Integer)

            '*** 
            '*** Cram all that data into the key - Add a sequence number to keep keys unique
            '*** 

            m_nNodeKeySeq = m_nNodeKeySeq + 1
            nodx.Tag = strType & m_strKeyChar & strProperty & m_strKeyChar & Convert.ToString(lIndex) & m_strKeyChar & Convert.ToString(lParentIndex) & m_strKeyChar & Convert.ToString(m_nNodeKeySeq)

            '*** Now, put a star in front of the text label so the user knows that it's keyed for write
            nodx.Text = "*" & nodx.Text

        End Sub

        '**************************************************
        '*** Routine:   GetKey
        '*** Purpose:   Extract a series of values from the passed tree node
        '*** Input:     nodx is the tree node
        '*** Output:    strType is the node type
        '***            strProperty is the property of the node
        '***            lIndex is the index of the object
        '***            lParentIndex is the index of the parent
        '**************************************************
        Private Sub GetKey(ByRef nodx As TreeNode, ByRef strType As String, ByRef strProperty As String, ByRef lIndex As Integer, ByRef lParentIndex As Integer)

            Dim strKey As String
            strKey = CType(nodx.Tag, String)

            strType = Field(strKey, m_strKeyChar, 1)
            strProperty = Field(strKey, m_strKeyChar, 2)

            Dim strIndex As String
            strIndex = Field(strKey, m_strKeyChar, 3)
            If strIndex.Length = 0 Then lIndex = 0 Else lIndex = CShort(strIndex)

            Dim strParentIndex As String
            strParentIndex = Field(strKey, m_strKeyChar, 4)
            If strParentIndex.Length = 0 Then lParentIndex = 0 Else lParentIndex = CShort(strParentIndex)

        End Sub

        '**************************************************
        '*** Routine:   Field
        '*** Purpose:   Extract a substring field
        '*** Input:     strSearched is the string to search
        '***            strChar is the (single character) search string
        '***            nField is the field number (1-based)
        '*** Output:    The substring from the nField field
        '**************************************************
        Private Function Field(ByVal strSearched As String, ByVal strChar As String, ByVal nField As Short) As String

            Dim nPos As Short
            Field = ""

            '*** Check for bad case
            If nField = 0 Then Exit Function

            '*** 
            '*** Skip to the correct field
            '*** 

            nField = nField - 1
            While nField > 0
                nPos = InStr(strSearched, strChar)
                If nPos >= 1 Then
                    strSearched = Mid(strSearched, nPos + 1)
                Else
                    Exit Function ' Got nothing
                End If
                nField = nField - 1
            End While

            '*** 
            '*** Extract the field
            '*** 

            nPos = InStr(strSearched, strChar)
            If nPos >= 1 Then
                Field = VB.Left(strSearched, nPos - 1)
            Else
                Field = strSearched
            End If

        End Function
        '**************************************************
        '*** Routine:   cmdRefresh_Click
        '*** Purpose:   Clear the tree control
        '***            and fill it again
        '*** Input:     none
        '*** Output:    none
        '**************************************************
        Private Sub cmdError_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdError.Click

            Try
                m_oApp.LogError(Convert.ToInt32(txtErr1.Text), Convert.ToInt32(txtErr2.Text), Convert.ToInt32(txtErr3.Text), txtDescription.Text, txtModule.Text, Convert.ToInt32(txtLineNumber.Text))
                MsgBox("Logged error: " & txtDescription.Text)
            Catch ex As Exception
                ExceptionHandler.HandleException("Unable to log error: ", ex)
            End Try

        End Sub

        '**************************************************
        '*** Routine:   cmdGetCSS_Click
        '*** Purpose:   Get a custom storage string for the selected item
        '*** Input:     none
        '*** Output:    none
        '**************************************************
        Private Sub cmdGetCSS_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdGetCSS.Click

            If Not optCSSType0.Checked And Not optCSSType1.Checked And Not optCSSType2.Checked _
            And Not optCSSType3.Checked And Not optCSSType4.Checked And Not optCSSType5.Checked _
            And Not optCSSType6.Checked And Not optCSSType7.Checked And Not optCSSType8.Checked Then
                MessageBox.Show("Please select a custom storage type")
                Exit Sub
            End If

            Dim oDocument As InteropServices.Document = Nothing
            Dim oFolder As InteropServices.Folder = Nothing
            Try
                '*** 
                '*** Get the storage string with the specified name
                '*** 

                Dim strName As String
                Dim strValue As String
                strName = txtNameCSS.Text

                Using oBatchWrapper As New ApiObjectWrapper(Of InteropServices.IBatch)(m_oApp.ActiveBatch)
                    Dim oBatchClass As InteropServices.BatchClass = Nothing
                    Dim oDocumentClass As InteropServices.DocumentClass = Nothing
                    Dim oFolderClasses As InteropServices.FolderClasses = Nothing
                    Dim oFolderClass As InteropServices.FolderClass = Nothing
                    Dim oPage As InteropServices.Page = Nothing
                    txtValueCSS.Text = ""
                    If Not oBatchWrapper.IsNull Then
                        oDocument = oBatchWrapper.WrappedObject.ActiveDocument
                        oFolder = oBatchWrapper.WrappedObject.ActiveFolder
                        Select Case True
                            Case optCSSType0.Checked '*** Batch
                                strValue = oBatchWrapper.WrappedObject.CustomStorageString(strName)
                            Case optCSSType1.Checked '*** Document
                                strValue = oDocument.CustomStorageString(strName)
                            Case optCSSType2.Checked '*** Folder
                                If Not IsNothing(oFolder) Then
                                    strValue = oFolder.CustomStorageString(strName)
                                End If
                            Case optCSSType3.Checked '*** Page
                                '*** Different APIs get a doc page and a loose page
                                If IsNothing(oDocument) Then
                                    Using oLoosePageWrapper As New ApiObjectWrapper(Of InteropServices.IPage)(oBatchWrapper.WrappedObject.ActiveLoosePage)
                                        Debug.Assert(Not oLoosePageWrapper.IsNull)
                                        strValue = oLoosePageWrapper.WrappedObject.CustomStorageString(strName)
                                    End Using
                                Else
                                    Using oPageWrapper As New ApiObjectWrapper(Of InteropServices.IPage)(oDocument.ActivePage)
                                        If Not oPageWrapper.IsNull Then
                                            strValue = oPageWrapper.WrappedObject.CustomStorageString(strName)
                                        End If
                                    End Using
                                End If
                            Case optCSSType4.Checked '*** Batch Class
                                Using oBatchClassesCollWrapper As New ApiObjectWrapper(Of InteropServices.BatchClasses)(m_oApp.BatchClasses)
                                    If Not oBatchClassesCollWrapper.IsNull Then
                                        oBatchClass = oBatchClassesCollWrapper.WrappedObject.Item(oBatchWrapper.WrappedObject.ClassName)
                                        Debug.Assert(Not IsNothing(oBatchClass))
                                        Using oBatchClassWraper As New ApiObjectWrapper(Of InteropServices.BatchClass)(oBatchClass)
                                            strValue = oBatchClassWraper.WrappedObject.CustomStorageString(strName)
                                        End Using
                                    End If
                                End Using
                            Case optCSSType5.Checked '*** Document Class
                                Using oDocClassCollWrapper As New ApiObjectWrapper(Of InteropServices.DocumentClasses)(oBatchWrapper.WrappedObject.DocumentClasses)
                                    If Not oDocClassCollWrapper.IsNull Then
                                        oDocumentClass = oDocClassCollWrapper.WrappedObject.Item(oDocument.ClassName)
                                        Debug.Assert(Not IsNothing(oDocumentClass))
                                        Using oDocumentClassWrapper As New ApiObjectWrapper(Of InteropServices.DocumentClass)(oDocumentClass)
                                            strValue = oDocumentClassWrapper.WrappedObject.CustomStorageString(strName)
                                        End Using
                                    End If
                                End Using
                            Case optCSSType6.Checked '*** Folder Class
                                Using oApiWrapper As New ApiObjectWrapper(Of InteropServices.FolderClasses)(oBatchWrapper.WrappedObject.FolderClasses)
                                    If Not oApiWrapper.IsNull Then
                                        Debug.Assert(Not IsNothing(oFolder))
                                        oFolderClass = oApiWrapper.WrappedObject.Item(oFolder.ClassName)
                                        Debug.Assert(Not IsNothing(oFolderClass))
                                        Using oFolderClassWrapper As New ApiObjectWrapper(Of InteropServices.FolderClass)(oFolderClass)
                                            strValue = oFolderClassWrapper.WrappedObject.CustomStorageString(strName)
                                        End Using
                                    End If
                                End Using
                            Case optCSSType7.Checked '*** Form Type
                                Using oApiWrapper As New ApiObjectWrapper(Of InteropServices.FormType)(oDocument.FormType)
                                    If Not oApiWrapper.IsNull Then
                                        strValue = oApiWrapper.WrappedObject.CustomStorageString(strName)
                                    End If
                                End Using
                            Case optCSSType8.Checked '*** Field Type (based off of the index field)
                                Using oApiWrapper As New ApiObjectWrapper(Of InteropServices.IndexField)(oDocument.ActiveIndexField)
                                    If Not oApiWrapper.IsNull Then
                                        strValue = oApiWrapper.WrappedObject.TypeCustomStorageString(strName)
                                    End If
                                End Using
                        End Select
                        txtValueCSS.Text = strValue
                    End If
                End Using
            Catch ex As Exception
                ExceptionHandler.HandleException("Unable to get custom storage string: ", ex)
            Finally
                If Not IsNothing(oDocument) Then
                    oDocument.Dispose()
                    oDocument = Nothing
                End If
                If Not IsNothing(oFolder) Then
                    oFolder.Dispose()
                    oFolder = Nothing
                End If
            End Try

        End Sub

        '**************************************************
        '*** Routine:   cmdSetCSS_Click
        '*** Purpose:   Set a custom storage string for the selected item
        '*** Input:     none
        '*** Output:    none
        '**************************************************
        Private Sub cmdSetCSS_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdSetCSS.Click

            If Not optCSSType0.Checked And Not optCSSType1.Checked And Not optCSSType2.Checked _
            And Not optCSSType3.Checked And Not optCSSType4.Checked And Not optCSSType5.Checked _
            And Not optCSSType6.Checked And Not optCSSType7.Checked And Not optCSSType8.Checked Then
                MsgBox("Please select a custom storage type")
                Exit Sub
            End If

            Dim oDocument As InteropServices.Document = Nothing
            Dim oFolder As InteropServices.Folder = Nothing
            Dim oPage As InteropServices.Page = Nothing

            Try
                '*** 
                '*** Get the storage string with the specified name
                '***

                Dim strName As String
                Dim strValue As String
                strName = txtNameCSS.Text
                strValue = txtValueCSS.Text

                Using oActiveBatch As New ApiObjectWrapper(Of InteropServices.IBatch)(m_oApp.ActiveBatch)
                    If Not oActiveBatch.IsNull Then
                        oDocument = oActiveBatch.WrappedObject.ActiveDocument
                        oFolder = oActiveBatch.WrappedObject.ActiveFolder
                        Select Case True
                            Case optCSSType0.Checked '*** Batch
                                oActiveBatch.WrappedObject.CustomStorageString(strName) = strValue
                            Case optCSSType1.Checked '*** Document
                                Debug.Assert(Not IsNothing(oDocument))
                                oDocument.CustomStorageString(strName) = strValue
                            Case optCSSType2.Checked '*** Folder
                                '*** Folder may not exist
                                If Not IsNothing(oFolder) Then
                                    oFolder.CustomStorageString(strName) = strValue
                                End If
                            Case optCSSType3.Checked '*** Page
                                '*** Different APIs get a doc page and a loose page

                                If IsNothing(oDocument) Then
                                    oPage = oActiveBatch.WrappedObject.ActiveLoosePage
                                    Debug.Assert(Not IsNothing(oPage))
                                    oPage.CustomStorageString(strName) = strValue
                                Else
                                    oPage = oDocument.ActivePage
                                    Debug.Assert(Not IsNothing(oPage))
                                    oPage.CustomStorageString(strName) = strValue
                                End If
                            Case Else
                                MsgBox("You can only set custom string values for Batch, Document and Page objects")
                        End Select
                    End If
                End Using
            Catch ex As Exception
                ExceptionHandler.HandleException("Unable to set custom storage string: ", ex)
            Finally
                If Not IsNothing(oPage) Then
                    oPage.Dispose()
                End If
                If Not IsNothing(oFolder) Then
                    oFolder.Dispose()
                End If
                If Not IsNothing(oDocument) Then
                    oDocument.Dispose()
                End If
            End Try

        End Sub

        '**************************************************
        '*** Routine:   cmdHoldReferences_Click
        '*** Purpose:   Hold references to objects so we can check to see
        '***            if they are still valid in the future
        '*** Input:     none
        '*** Output:    none
        '**************************************************
        Private Sub cmdHoldReferences_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdHoldReferences.Click

            Try
                ClearWrappedObjects()

                '*** 
                '*** Don't need to save the application - its always the same
                '*** Save application-based objects
                '*** 

                m_oHeldBatch = m_oApp.ActiveBatch

                If Not IsNothing(m_oHeldBatch) Then
                    '*** Save batch based objects
                    m_oHeldDocuments = m_oHeldBatch.Documents
                    m_oHeldDocument = m_oHeldBatch.ActiveDocument

                    If Not IsNothing(m_oHeldDocument) Then
                        '*** Save document-based objects
                        m_oHeldPages = m_oHeldDocument.Pages
                        If m_oHeldPages.Count Then m_oHeldPage = m_oHeldPages(1)

                        '*** 
                        '*** There may be no access to index fields
                        '*** 

                        If m_bHasAscentCaptureFeatures Then
                            Try
                                Using oFormTypes As InteropServices.FormTypes = m_oHeldBatch.FormTypes
                                    m_oHeldDocument.FormType = oFormTypes.Item(1)
                                    m_oHeldFields = m_oHeldDocument.IndexFields
                                End Using
                            Catch ex As Exception
                                m_oHeldFields = Nothing
                            End Try

                            If Not IsNothing(m_oHeldFields) Then
                                Dim oIndexField As InteropServices.IndexField = m_oHeldDocument.ActiveIndexField
                                If Not IsNothing(oIndexField) Then
                                    '*** Save field
                                    m_oHeldField = oIndexField

                                    '*** Save suggested value stuff
                                    m_oHeldSuggestedValues = m_oHeldField.SuggestedValues
                                    If m_oHeldSuggestedValues.Count Then
                                        m_oHeldSuggestedValue = m_oHeldSuggestedValues(1)
                                    End If
                                End If
                            End If

                            '*** No custom properties if no export connector
                            Try
                                m_oHeldCustomProperties = m_oHeldDocument.CustomProperties
                            Catch ex As Exception
                                m_oHeldCustomProperties = Nothing
                            End Try

                            If Not IsNothing(m_oHeldCustomProperties) Then
                                If m_oHeldCustomProperties.Count Then m_oHeldCustomProperty = m_oHeldCustomProperties(1)
                            End If
                        End If
                    End If
                End If
            Catch ex As Exception
                ExceptionHandler.HandleException("Hold references Error : ", ex)
            End Try

        End Sub

        '**************************************************
        '*** Routine:   cmdShowMenu_Click(
        '*** Purpose:   Allow the show/hide to menus
        '*** Input:     none
        '*** Output:    none
        '**************************************************
        Private Sub cmdShowMenu_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdShowMenu.Click

            Dim oShowMenuForm As ShowMenuForm

            Try
                Dim nCount As Short

                '*** We don't want to bring up an empty dialog.
                nCount = m_oMenuCollection.Count

                If (nCount = 0) Then
                    MsgBox("No menus have been defined")
                    Exit Sub
                Else
                    oShowMenuForm = New ShowMenuForm(m_oApp, m_oMenuCollection)
                    oShowMenuForm.ShowDialog(Me)
                End If
            Catch ex As Exception
                ExceptionHandler.HandleException("ShowMenu Error: ", ex)
            Finally
                If Not IsNothing(oShowMenuForm) Then
                    oShowMenuForm.Dispose()
                    oShowMenuForm = Nothing
                End If
            End Try

        End Sub
        '**************************************************
        '*** Routine:   cmdTestReferences_Click
        '*** Purpose:   Hold references to objects so we can check to see
        '***            if they are still valid in the future
        '*** Input:     none
        '*** Output:    none
        '**************************************************
        Private Sub cmdTestReferences_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdTestReferences.Click

            '***
            '*** Get a sample property off of each held object to see if it is ok.
            '*** If the object is bad, then we'll catch the error and set strTest as an empty string
            '***

            Dim strResults As String
            Dim strTest As String

            Try
                strTest = Convert.ToString(m_oApp.DataEntryMode)
            Catch ex As Exception
                strTest = ""
            Finally
                AddReferenceLine(m_oApp, strResults, "Application", strTest)
            End Try

            Try
                strTest = Convert.ToString(m_oHeldBatch.ClassName)
            Catch ex As Exception
                strTest = ""
            Finally
                AddReferenceLine(m_oHeldBatch, strResults, "Batch", strTest)
            End Try

            Try
                strTest = Convert.ToString(m_oHeldDocuments.Count)
            Catch ex As Exception
                strTest = ""
            Finally
                AddReferenceLine(m_oHeldDocuments, strResults, "Documents", strTest)
            End Try

            Try
                strTest = Convert.ToString(m_oHeldDocument.ClassName)
            Catch ex As Exception
                strTest = ""
            Finally
                AddReferenceLine(m_oHeldDocument, strResults, "Document", strTest)
            End Try

            Try
                strTest = Convert.ToString(m_oHeldPages.Count)
            Catch ex As Exception
                strTest = ""
            Finally
                AddReferenceLine(m_oHeldPages, strResults, "Pages", strTest)
            End Try

            Try
                strTest = Convert.ToString(m_oHeldPage.FileName)
            Catch ex As Exception
                strTest = ""
            Finally
                AddReferenceLine(m_oHeldPage, strResults, "Page", strTest)
            End Try

            Try
                strTest = Convert.ToString(m_oHeldFields.Count)
            Catch ex As Exception
                strTest = ""
            Finally
                AddReferenceLine(m_oHeldFields, strResults, "IndexFields", strTest)
            End Try

            Try
                strTest = Convert.ToString(m_oHeldField.Name)
            Catch ex As Exception
                strTest = ""
            Finally
                AddReferenceLine(m_oHeldField, strResults, "IndexField", strTest)
            End Try

            Try
                strTest = Convert.ToString(m_oHeldCustomProperties.Count)
            Catch ex As Exception
                strTest = ""
            Finally
                AddReferenceLine(m_oHeldCustomProperties, strResults, "CustomProperties", strTest)
            End Try

            Try
                strTest = Convert.ToString(m_oHeldCustomProperty.Name)
            Catch ex As Exception
                strTest = ""
            Finally
                AddReferenceLine(m_oHeldCustomProperty, strResults, "CustomProperty", strTest)
            End Try

            Try
                strTest = Convert.ToString(m_oHeldSuggestedValues.Count)
            Catch ex As Exception
                strTest = ""
            Finally
                AddReferenceLine(m_oHeldSuggestedValues, strResults, "SuggestedValues", strTest)
            End Try

            Try
                strTest = Convert.ToString(m_oHeldSuggestedValue.Value)
            Catch ex As Exception
                strTest = ""
            Finally
                AddReferenceLine(m_oHeldSuggestedValue, strResults, "SuggestedValue", strTest)
            End Try

            '*** Display the results
            MsgBox(strResults)

        End Sub

        '**************************************************
        '*** Routine:   AddReferenceLine
        '*** Purpose:   Adds a valid/invalid line to the references results.
        '*** Input:     oObject is a test object - Use this to see if it's nothing
        '***            strResults is the final results string
        '***            strCaption is the caption for the line
        '***            strTest is empty if the reference is invalid, or non-empty if it's valid
        '*** Output:    strResults contains the new results for this line
        '***            strTest is cleared to an empty string
        '**************************************************
        Private Sub AddReferenceLine(ByVal oObject As Object, ByRef strResults As String, ByVal strCaption As String, ByRef strTest As String)

            '*** Add the caption
            strResults = strResults & strCaption & ":  "

            '***
            '*** Add the results
            '***

            If IsNothing(oObject) Then
                '*** Object was not set in the first place
                strResults = strResults & "Not set"
            Else
                If strTest.Length = 0 Then
                    '*** Object was originally set, but is now invalid
                    strResults = strResults & "Invalid"
                Else
                    '*** Object was originally set, and is still valid.
                    strResults = strResults & "Valid"
                End If
            End If

            '*** Add a new line
            strResults = strResults & Chr(13) & Chr(10)

            '*** Reset strTest for the next line
            strTest = ""

        End Sub

        '**************************************************
        '*** Property:  FullRefresh
        '*** Purpose:   Returns true if we should do a "full" tree refresh
        '*** Input:     none
        '*** Output:    True if full tree refresh, False o/w
        '**************************************************
        Private ReadOnly Property FullRefresh() As Boolean

            Get
                Return (chkFullRefresh.CheckState = System.Windows.Forms.CheckState.Checked)
            End Get

        End Property

        '**************************************************
        '*** Routine:   cmdRefresh_Click
        '*** Purpose:   Clear the tree control
        '***            and fill it again
        '*** Input:     none
        '*** Output:    none
        '**************************************************
        Private Sub cmdRefresh_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdRefresh.Click

            Try
                FillTree()
            Catch ex As Exception
                ExceptionHandler.HandleException("Refresh Error : ", ex)
            End Try

        End Sub

        '**************************************************
        '*** Routine:   cmdSendKeys_Click
        '*** Purpose:   Send keys to main frame
        '*** Input:     txtsendkeys contains the text to send
        '*** Output:    none
        '**************************************************
        Private Sub cmdSendKeys_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdSendKeys.Click

            Try
                SendKeys.SendWait(txtSendKeys.Text)
            Catch ex As Exception
                ExceptionHandler.HandleException("Unable to send keys: ", ex)
            End Try

        End Sub

        '**************************************************
        '*** Routine:   cmdTranslate_Click
        '*** Purpose:   Translate the ascent capture values
        '*** Input:     none
        '*** Output:    none
        '**************************************************
        Private Sub cmdTranslate_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdTranslate.Click

            Try
                Dim strText As String
                strText = txtAscentCaptureValues.Text
                m_oApp.TranslateAscentCaptureValues(strText)
                txtAscentCaptureValues.Text = strText
            Catch ex As Exception
                ExceptionHandler.HandleException("Translation Error: ", ex)
            End Try

        End Sub

        '**************************************************
        '*** Routine:   ClearWrappedObjects
        '*** Purpose:   Init held objects
        '*** Input:     none
        '*** Output:    none
        '**************************************************
        Private Sub ClearWrappedObjects()

            If Not IsNothing(m_oHeldBatch) Then
                m_oHeldBatch.Dispose()
                m_oHeldBatch = Nothing
            End If

            If Not IsNothing(m_oHeldDocuments) Then
                m_oHeldDocuments.Dispose()
                m_oHeldDocuments = Nothing
            End If

            If Not IsNothing(m_oHeldDocument) Then
                m_oHeldDocument.Dispose()
                m_oHeldDocument = Nothing
            End If

            If Not IsNothing(m_oHeldPages) Then
                m_oHeldPages.Dispose()
                m_oHeldPages = Nothing
            End If

            If Not IsNothing(m_oHeldPage) Then
                m_oHeldPage.Dispose()
                m_oHeldPage = Nothing
            End If

            If Not IsNothing(m_oHeldFields) Then
                m_oHeldFields.Dispose()
                m_oHeldFields = Nothing
            End If

            If Not IsNothing(m_oHeldField) Then
                m_oHeldField.Dispose()
                m_oHeldField = Nothing
            End If

            If Not IsNothing(m_oHeldCustomProperties) Then
                m_oHeldCustomProperties.Dispose()
                m_oHeldCustomProperties = Nothing
            End If

            If Not IsNothing(m_oHeldCustomProperty) Then
                m_oHeldCustomProperty.Dispose()
                m_oHeldCustomProperty = Nothing
            End If

            If Not IsNothing(m_oHeldSuggestedValues) Then
                m_oHeldSuggestedValues.Dispose()
                m_oHeldSuggestedValues = Nothing
            End If

            If Not IsNothing(m_oHeldSuggestedValue) Then
                m_oHeldSuggestedValue.Dispose()
                m_oHeldSuggestedValue = Nothing
            End If

        End Sub

        '**************************************************
        '*** Routine:   HideUserControl
        '*** Purpose:   The user control is being hidden
        '*** Input:     none
        '*** Output:    none
        '**************************************************
        Private Sub LogHideUserControl()

            LogEvent("Hide")

        End Sub

        '**************************************************
        '*** Routine:   InitUserControl
        '*** Purpose:   Init member variables
        '*** Input:     none
        '*** Output:    none
        '**************************************************
        Private Sub InitUserControl()

            Try
                m_nDocumentNumber = 0
                m_nFolderNumber = 0
                m_nPageNumber = 0
                m_nFieldNumber = 0
                m_nNodeKeySeq = 0
                m_strKeyChar = Chr(0)
                m_bHasAscentCaptureFeatures = False
                m_oMenuCollection = New MenuCollection
                ClearWrappedObjects()
            Catch ex As Exception
                ExceptionHandler.HandleException("InitProperties Error : ", ex)
            End Try

        End Sub

        '**************************************************
        '*** Routine:   ResizeUserControl
        '*** Purpose:   Logs the new panel size in pixels
        '*** Input:     none
        '*** Output:    none
        '**************************************************
        Private Sub ResizeUserControl(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Resize

            LogEvent("Resize ( " & Width & ", " & Height & " )")

        End Sub

        '**************************************************
        '*** Routine:   ShowUserControl
        '*** Purpose:   The user control is being shown
        '*** Input:     none
        '*** Output:    none
        '**************************************************
        Private Sub LogShowUserControl()

            LogEvent("Show")
        End Sub

		'**************************************************
		'*** Routine:   TerminateUserControl
		'*** Purpose:   Do any cleanup on the control
		'*** Input:     none
		'*** Output:    none
		'**************************************************
		Private Sub TerminateUserControl()

			Try
				m_oMenuCollection = Nothing
				'*** Release underlying objects when no longer in use
				ClearWrappedObjects()
			Catch ex As Exception
				ExceptionHandler.HandleException("Terminate Error : ", ex)
			Finally
				'*** Release underlying objects when no longer in use
				If Not IsNothing(m_oApp) Then
					m_oApp.Dispose()
					m_oApp = Nothing
				End If
			End Try

		End Sub

		'**************************************************
		'*** Routine:   OnGotFocus
		'*** Purpose:   Restore focus to the last active 
		'***            control
		'*** Input:     eventArgs - just passed to the base
		'***            class event handler
		'*** Output:    none
		'**************************************************
		Protected Overrides Sub OnGotFocus(ByVal eventArgs As EventArgs)
			MyBase.OnGotFocus(eventArgs)
			If Not ActiveControl Is Nothing Then ActiveControl.Focus()
		End Sub

	End Class

End Namespace

