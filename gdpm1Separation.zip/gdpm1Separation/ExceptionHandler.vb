Option Explicit On 

Namespace Kofax.Samples.SmpleOcx

    Friend Class ExceptionHandler

        '******************************************************************************
        '***
        '*** Class:     ExceptionHandler
        '*** Purpose:   Handles exceptions within the program
        '***
        '*** (c) Copyright 2006 Kofax Image Products
        '*** All rights reserved.
        '***
        '******************************************************************************

        '**************************************************
        '*** Routine:   HandleException
        '*** Purpose:   Display an exception message
        '*** Input:     strMessage is the method where the
        '***            exception occured
        '*** Output:    none
        '**************************************************
        Public Shared Sub HandleException(ByRef strMessage As String, ByVal ex As Exception)
            MsgBox(strMessage & " " & ex.Message)
        End Sub

    End Class

End Namespace
