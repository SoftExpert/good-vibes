Option Strict Off
Option Explicit On 

Namespace Kofax.Samples.SmpleOcx

    Friend Class DataEntryForm
        Inherits System.Windows.Forms.Form
#Region "Windows Form Designer generated code "
        Public Sub New()
            MyBase.New()

            Try
                'This call is required by the Windows Form Designer.
                InitializeComponent()
            Catch ex As Exception
                ExceptionHandler.HandleException("New Error: ", ex)
            End Try
        End Sub
        'Form overrides dispose to clean up the component list.
        Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
            If Disposing Then
                If Not IsNothing(components) Then
                    components.Dispose()
                End If
            End If
            MyBase.Dispose(Disposing)
        End Sub
        'Required by the Windows Form Designer
        Private components As System.ComponentModel.IContainer
        Public ToolTip1 As System.Windows.Forms.ToolTip
        Public WithEvents txtValue As System.Windows.Forms.TextBox
        Public WithEvents cmdCancel As System.Windows.Forms.Button
        Public WithEvents cmdOK As System.Windows.Forms.Button
        Public WithEvents lblCaption As System.Windows.Forms.Label
        'NOTE: The following procedure is required by the Windows Form Designer
        'It can be modified using the Windows Form Designer.
        'Do not modify it using the code editor.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
			Me.components = New System.ComponentModel.Container()
			Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(DataEntryForm))
			Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
			Me.txtValue = New System.Windows.Forms.TextBox()
			Me.cmdCancel = New System.Windows.Forms.Button()
			Me.cmdOK = New System.Windows.Forms.Button()
			Me.lblCaption = New System.Windows.Forms.Label()
			Me.SuspendLayout()
			'
			'txtValue
			'
			Me.txtValue.AcceptsReturn = True
			Me.txtValue.BackColor = System.Drawing.SystemColors.Window
			Me.txtValue.Cursor = System.Windows.Forms.Cursors.IBeam
			resources.ApplyResources(Me.txtValue, "txtValue")
			Me.txtValue.ForeColor = System.Drawing.SystemColors.WindowText
			Me.txtValue.Name = "txtValue"
			'
			'cmdCancel
			'
			Me.cmdCancel.BackColor = System.Drawing.SystemColors.Control
			Me.cmdCancel.Cursor = System.Windows.Forms.Cursors.Default
			Me.cmdCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel
			resources.ApplyResources(Me.cmdCancel, "cmdCancel")
			Me.cmdCancel.ForeColor = System.Drawing.SystemColors.ControlText
			Me.cmdCancel.Name = "cmdCancel"
			Me.cmdCancel.UseVisualStyleBackColor = False
			'
			'cmdOK
			'
			Me.cmdOK.BackColor = System.Drawing.SystemColors.Control
			Me.cmdOK.Cursor = System.Windows.Forms.Cursors.Default
			resources.ApplyResources(Me.cmdOK, "cmdOK")
			Me.cmdOK.ForeColor = System.Drawing.SystemColors.ControlText
			Me.cmdOK.Name = "cmdOK"
			Me.cmdOK.UseVisualStyleBackColor = False
			'
			'lblCaption
			'
			Me.lblCaption.BackColor = System.Drawing.SystemColors.Control
			Me.lblCaption.Cursor = System.Windows.Forms.Cursors.Default
			resources.ApplyResources(Me.lblCaption, "lblCaption")
			Me.lblCaption.ForeColor = System.Drawing.SystemColors.ControlText
			Me.lblCaption.Name = "lblCaption"
			'
			'DataEntryForm
			'
			Me.AcceptButton = Me.cmdOK
			resources.ApplyResources(Me, "$this")
			Me.BackColor = System.Drawing.SystemColors.Control
			Me.CancelButton = Me.cmdCancel
			Me.Controls.Add(Me.txtValue)
			Me.Controls.Add(Me.cmdCancel)
			Me.Controls.Add(Me.cmdOK)
			Me.Controls.Add(Me.lblCaption)
			Me.Cursor = System.Windows.Forms.Cursors.Default
			Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
			Me.MaximizeBox = False
			Me.MinimizeBox = False
			Me.Name = "DataEntryForm"
			Me.ShowInTaskbar = False
			Me.ResumeLayout(False)
			Me.PerformLayout()

		End Sub
#End Region

        '********************************************************************************
        '***
        '*** Module:    DataEntryForm 
        '*** Purpose:   Simple data-entry form
        '***
        '*** (c) Copyright 2006 Kofax Image Products.
        '*** All rights reserved.
        '***
        '********************************************************************************

        Private m_bOk As Boolean

        '**************************************************
        '*** Routine:   OK
        '*** Purpose:   Returns true if the user clicked ok
        '*** Input:     none
        '*** Output:    Returns true if the user clicked ok
        '**************************************************
        Public ReadOnly Property OK() As Boolean
            Get
                OK = m_bOk
            End Get
        End Property

        '**************************************************
        '*** Routine:   EntryCaption
        '*** Purpose:   set the caption
        '*** Input:     strCaption is the caption
        '*** Output:    none
        '**************************************************
        Public WriteOnly Property EntryCaption() As String
            Set(ByVal Value As String)
                Me.lblCaption.Text = Value
            End Set
        End Property

        '**************************************************
        '*** Routine:   Value
        '*** Purpose:   Get/Set the data-entry text
        '*** Input:     Value is the data-entry text
        '*** Output:    The data-entry text
        '**************************************************
        Public Property Value() As String
            Get
                Value = Me.txtValue.Text
            End Get
            Set(ByVal Value As String)
                Me.txtValue.Text = Value
            End Set
        End Property

        '**************************************************
        '*** Routine:   cmdCancel_Click
        '*** Purpose:   Set that we did NOT click ok and hide us
        '*** Input:     none
        '*** Output:    none
        '**************************************************
        Private Sub cmdCancel_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdCancel.Click
            m_bOk = False
            Me.Hide()
        End Sub

        '**************************************************
        '*** Routine:   cmdOK_Click
        '*** Purpose:   Set that we clicked ok and hide us
        '*** Input:     none
        '*** Output:    none
        '**************************************************
        Private Sub cmdOK_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdOK.Click
            m_bOk = True
            Me.Hide()
        End Sub
        '**************************************************
        '*** Routine:   ActivatedDataEntryForm
        '*** Purpose:   Select the edit text
        '*** Input:     none
        '*** Output:    none
        '**************************************************
        Private Sub ActivatedDataEntryForm(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Activated
            txtValue.SelectionStart = 0
            txtValue.SelectionLength = Len(txtValue.Text)
        End Sub

        '**************************************************
        '*** Routine:   LoadDataEntryForm
        '*** Purpose:   Init the local variables
        '*** Input:     none
        '*** Output:    none
        '**************************************************
        Private Sub LoadDataEntryForm(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Load
            m_bOk = False
        End Sub

    End Class

End Namespace
