Option Strict Off
Option Explicit On 

Imports System.Runtime.InteropServices
Imports InteropServices = Kofax.Capture.CaptureModule.InteropServices

Namespace Kofax.Samples.SmpleOcx

    Friend Class AddMenuForm
        Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

		Public Sub New(ByRef oApp As InteropServices.Application, ByRef oMenuCollecion As MenuCollection)
			MyBase.New()

			Try
				'This call is required by the Windows Form Designer.
				IsInitializing = True
				InitializeComponent()
				IsInitializing = False

				'*** Sets the application object from the control
				Try
					m_oApp = oApp
				Catch ex As Exception
					MsgBox("ApplicationError Error: " & ex.Message)
				End Try

				'*** This collection keeps track of every menu item added
				m_oMenuCollection = New MenuCollection
				m_oMenuCollection = oMenuCollecion
			Catch ex As Exception
				ExceptionHandler.HandleException("New Error: ", ex)
			End Try
		End Sub

        'Form overrides dispose to clean up the component list.
        Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
            If disposing Then
                m_oApp = Nothing
                m_oMenuCollection = Nothing
                If Not IsNothing(components) Then
                    components.Dispose()
                End If
            End If
            MyBase.Dispose(disposing)
        End Sub

        'Required by the Windows Form Designer
        Private components As System.ComponentModel.IContainer

        'NOTE: The following procedure is required by the Windows Form Designer
        'It can be modified using the Windows Form Designer.  
        'Do not modify it using the code editor.
        Friend WithEvents cmdClose As System.Windows.Forms.Button
        Friend WithEvents txtEventText As System.Windows.Forms.TextBox
        Friend WithEvents txtMenuBar As System.Windows.Forms.TextBox
        Friend WithEvents cmdSave As System.Windows.Forms.Button
        Friend WithEvents txtMenuText As System.Windows.Forms.TextBox
        Friend WithEvents cmbMenu As System.Windows.Forms.ComboBox
        Friend WithEvents lblLocation As System.Windows.Forms.Label
        Friend WithEvents lblEventText As System.Windows.Forms.Label
        Friend WithEvents lblMenuBarText As System.Windows.Forms.Label
        Friend WithEvents lblMenuText As System.Windows.Forms.Label
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
			Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(AddMenuForm))
			Me.cmdSave = New System.Windows.Forms.Button()
			Me.cmdClose = New System.Windows.Forms.Button()
			Me.txtEventText = New System.Windows.Forms.TextBox()
			Me.txtMenuBar = New System.Windows.Forms.TextBox()
			Me.lblLocation = New System.Windows.Forms.Label()
			Me.lblEventText = New System.Windows.Forms.Label()
			Me.lblMenuBarText = New System.Windows.Forms.Label()
			Me.lblMenuText = New System.Windows.Forms.Label()
			Me.txtMenuText = New System.Windows.Forms.TextBox()
			Me.cmbMenu = New System.Windows.Forms.ComboBox()
			Me.SuspendLayout()
			'
			'cmdSave
			'
			resources.ApplyResources(Me.cmdSave, "cmdSave")
			Me.cmdSave.Name = "cmdSave"
			'
			'cmdClose
			'
			Me.cmdClose.DialogResult = System.Windows.Forms.DialogResult.Cancel
			resources.ApplyResources(Me.cmdClose, "cmdClose")
			Me.cmdClose.Name = "cmdClose"
			'
			'txtEventText
			'
			resources.ApplyResources(Me.txtEventText, "txtEventText")
			Me.txtEventText.Name = "txtEventText"
			'
			'txtMenuBar
			'
			resources.ApplyResources(Me.txtMenuBar, "txtMenuBar")
			Me.txtMenuBar.Name = "txtMenuBar"
			'
			'lblLocation
			'
			Me.lblLocation.FlatStyle = System.Windows.Forms.FlatStyle.System
			resources.ApplyResources(Me.lblLocation, "lblLocation")
			Me.lblLocation.Name = "lblLocation"
			'
			'lblEventText
			'
			Me.lblEventText.FlatStyle = System.Windows.Forms.FlatStyle.System
			resources.ApplyResources(Me.lblEventText, "lblEventText")
			Me.lblEventText.Name = "lblEventText"
			'
			'lblMenuBarText
			'
			Me.lblMenuBarText.FlatStyle = System.Windows.Forms.FlatStyle.System
			resources.ApplyResources(Me.lblMenuBarText, "lblMenuBarText")
			Me.lblMenuBarText.Name = "lblMenuBarText"
			'
			'lblMenuText
			'
			Me.lblMenuText.FlatStyle = System.Windows.Forms.FlatStyle.System
			resources.ApplyResources(Me.lblMenuText, "lblMenuText")
			Me.lblMenuText.Name = "lblMenuText"
			'
			'txtMenuText
			'
			resources.ApplyResources(Me.txtMenuText, "txtMenuText")
			Me.txtMenuText.Name = "txtMenuText"
			'
			'cmbMenu
			'
			resources.ApplyResources(Me.cmbMenu, "cmbMenu")
			Me.cmbMenu.Name = "cmbMenu"
			'
			'AddMenuForm
			'
			Me.AcceptButton = Me.cmdSave
			resources.ApplyResources(Me, "$this")
			Me.CancelButton = Me.cmdClose
			Me.Controls.Add(Me.cmbMenu)
			Me.Controls.Add(Me.txtMenuText)
			Me.Controls.Add(Me.txtMenuBar)
			Me.Controls.Add(Me.txtEventText)
			Me.Controls.Add(Me.lblMenuText)
			Me.Controls.Add(Me.lblMenuBarText)
			Me.Controls.Add(Me.lblEventText)
			Me.Controls.Add(Me.lblLocation)
			Me.Controls.Add(Me.cmdClose)
			Me.Controls.Add(Me.cmdSave)
			Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
			Me.MaximizeBox = False
			Me.MinimizeBox = False
			Me.Name = "AddMenuForm"
			Me.ShowInTaskbar = False
			Me.ResumeLayout(False)
			Me.PerformLayout()

		End Sub

#End Region

        '********************************************************************************
        '***
        '*** Module:    AddMenuForm
        '*** Purpose:   Dynamically add menus to the application
        '***
        '*** (c) Copyright 2006 Kofax Image Products.
        '*** All rights reserved.
        '***
        '********************************************************************************

		'*** The InteropServices.Application provides the base of the
        '*** Ascent Capture OLE Automation Hierarchy.
		Private m_oApp As InteropServices.Application

        '*** Menus
        Private m_oMenuCollection As MenuCollection

        Dim m_MenuLocationKeys(4) As String

        '*** Checks if the form is being initialized
        Private m_bIsInitializing As Boolean = False

        '**************************************************
        '*** Function:  LoadAddMenuForm
        '*** Purpose:   Load the form and initialize the controls
        '*** Input:     none
        '*** Output:    none
        '**************************************************
        Private Sub LoadAddMenuForm(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Load
            Dim nIndex As Short

            '*** Registry keys for menu locations. NOT to be internationalized.
            '*** MenuBar is the MainFrame menu.  All other are tree nodes.

            '*** Possible locations for user defined menus for Administrator

            m_MenuLocationKeys(0) = "MenuBar"
            m_MenuLocationKeys(1) = "Batch"
            m_MenuLocationKeys(2) = "Document"
            m_MenuLocationKeys(3) = "Page"


            For nIndex = 0 To 3
                cmbMenu.Items.Add((m_MenuLocationKeys(nIndex)))
            Next
            cmbMenu.Text = "MenuBar"

        End Sub

        '**************************************************
        '*** Function:  ClosedAddMenuForm
        '*** Purpose:   Free the app to prevent a leak
        '*** Input:     Cancel- ignored
        '*** Output:    none
        '**************************************************
        Private Sub ClosedAddMenuForm(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Closed
            m_oApp = Nothing
            m_oMenuCollection = Nothing
        End Sub

        '**************************************************
        '*** Function:  cmdSave_Click
        '*** Purpose:   Ok, add the menu item
        '*** Input:     none
        '*** Output:    none
        '**************************************************
        Private Sub cmdSave_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdSave.Click
            Try
                Dim bRet As Boolean

                If txtMenuText.Text.Length = 0 Or txtEventText.Text.Length = 0 Then
                    MsgBox(lblMenuText.Text & " and " & lblEventText.Text & " must be filled in.")
                    Exit Sub
                End If

                If cmbMenu.Text = "MenuBar" And txtMenuBar.Text.Length = 0 Then
                    MsgBox(lblLocation.Text & " and " & lblMenuBarText.Text & " must be filled in.")
                    Exit Sub
                End If

                bRet = m_oApp.AddMenu(txtEventText.Text, txtMenuText.Text, cmbMenu.Text, txtMenuBar.Text)
                Dim oMenuItem As New MenuItem
                oMenuItem.strName = txtEventText.Text
                oMenuItem.strMenu = txtMenuText.Text
                oMenuItem.strLocation = cmbMenu.Text
				oMenuItem.lState = InteropServices.KfxShowMenu.KfxMenuShow

                If (cmbMenu.Text = m_MenuLocationKeys(0)) Then
                    oMenuItem.strMenuBarText = txtMenuBar.Text
                End If

                oMenuItem.lState = 0
                m_oMenuCollection.Add(oMenuItem)
            Catch ex As Exception
                ExceptionHandler.HandleException("Save Error: ", ex)
            End Try
        End Sub

        '**************************************************
        '*** Function:  cmdClose_Click
        '*** Purpose:   Closes the dialog.
        '*** Input:     none
        '*** Output:    none
        '**************************************************
        Private Sub cmdClose_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdClose.Click
            Me.Close()
        End Sub

        '**************************************************
        '*** Function:  cmbMenu_Click
        '*** Purpose:   Changes the menu that the item goes on
        '***            Only the MenuBar requires a title
        '*** Input:     none
        '*** Output:    none
        '**************************************************
        Private Sub cmbMenu_SelectedIndexChanged(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmbMenu.SelectedIndexChanged

            '*** This check prevents the event from firing when
            '*** the form is initialized
            If Not Me.IsInitializing Then

                If (cmbMenu.SelectedIndex = -1) Then
                    MsgBox("No Item Selected")
                    Exit Sub
                End If

                '*** If it is a MenuBar, enable the menubar title text
                If cmbMenu.SelectedIndex <> 0 Then
                    TxtMenuBar.Visible = False
                    lblMenuBarText.Visible = False
                Else
                    TxtMenuBar.Visible = True
                    lblMenuBarText.Visible = True
                End If
            End If

        End Sub

        '**************************************************
        '*** Property:  IsInitializing
        '*** Purpose:   Checks if the form is being initialized
        '*** Input:     none
        '*** Output:    none
        '**************************************************
        Private Property IsInitializing() As Boolean
            Get
                IsInitializing = m_bIsInitializing
            End Get
            Set(ByVal Value As Boolean)
                m_bIsInitializing = Value
            End Set
        End Property

    End Class

End Namespace