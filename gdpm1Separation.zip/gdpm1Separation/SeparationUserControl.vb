Option Strict Off
Option Explicit On

Imports Microsoft.Win32
Imports System.Runtime.InteropServices
Imports VB = Microsoft.VisualBasic
Imports System.Threading
Imports InteropServices = Kofax.Capture.CaptureModule.InteropServices
Imports Kofax.Capture.CaptureModule
Imports Kofax.SDK.CaptureInfo
Imports System.IO
Imports System.Reflection
Imports System.Timers
Imports System.Reflection.Emit

Namespace Kofax.Samples.SmpleOcx

    <ProgId("SeparationOCX.SeparationUserControl")>
    <Guid("5E3C7D6A-08D9-4124-B9C9-84EFD8CAF6BF")>
    Public Class SeparationUserControl
        Inherits System.Windows.Forms.UserControl
#Region "Windows Form Designer generated code "
        Public Sub New()
            MyBase.New()

            'Set UI Culture
            CaptureInfo.SetThreadUILanguage(Thread.CurrentThread)

            Try
                'This call is required by the Windows Form Designer.
                InitializeComponent()
                InitUserControl()
                TabStop = True
            Catch ex As Exception
                ExceptionHandler.HandleException("New Error: ", ex)
            End Try
        End Sub
        'Form overrides dispose to clean up the component list.
        Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
            If Disposing Then
                If Not components Is Nothing Then
                    components.Dispose()
                End If
            End If
            MyBase.Dispose(Disposing)
        End Sub
        'Required by the Windows Form Designer
        Private components As System.ComponentModel.IContainer
        Private WithEvents Label1 As Windows.Forms.Label
        Friend WithEvents informations As Windows.Forms.Label
        Friend WithEvents chkDebug As CheckBox
        Friend WithEvents txtLog As RichTextBox
        Public ToolTip1 As System.Windows.Forms.ToolTip
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
            Me.components = New System.ComponentModel.Container()
            Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(SeparationUserControl))
            Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
            Me.Label1 = New System.Windows.Forms.Label()
            Me.informations = New System.Windows.Forms.Label()
            Me.chkDebug = New System.Windows.Forms.CheckBox()
            Me.txtLog = New System.Windows.Forms.RichTextBox()
            Me.SuspendLayout()
            '
            'Label1
            '
            resources.ApplyResources(Me.Label1, "Label1")
            Me.Label1.Name = "Label1"
            '
            'informations
            '
            Me.informations.BackColor = System.Drawing.SystemColors.Info
            resources.ApplyResources(Me.informations, "informations")
            Me.informations.Name = "informations"
            '
            'chkDebug
            '
            resources.ApplyResources(Me.chkDebug, "chkDebug")
            Me.chkDebug.Name = "chkDebug"
            Me.chkDebug.UseVisualStyleBackColor = True
            '
            'txtLog
            '
            Me.txtLog.BackColor = System.Drawing.SystemColors.Info
            Me.txtLog.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
            resources.ApplyResources(Me.txtLog, "txtLog")
            Me.txtLog.Name = "txtLog"
            Me.txtLog.ReadOnly = True
            Me.txtLog.ShortcutsEnabled = False
            Me.txtLog.ShowSelectionMargin = True
            '
            'SeparationUserControl
            '
            Me.Controls.Add(Me.txtLog)
            Me.Controls.Add(Me.chkDebug)
            Me.Controls.Add(Me.informations)
            Me.Controls.Add(Me.Label1)
            resources.ApplyResources(Me, "$this")
            Me.Name = "SeparationUserControl"
            Me.ResumeLayout(False)
            Me.PerformLayout()

        End Sub
#End Region
        '********************************************************************************
        '***
        '*** Module:    SeparationUserControl
        '*** Purpose:   OCX that tests all events, methods and properties
        '***            exposed by Ascent Capture
        '***
        '*** (c) Copyright 2006 Kofax Image Products.
        '*** All rights reserved.
        '***
        '********************************************************************************


        '*** The InteropServices.Application provides the base of the
        '*** Ascent Capture OLE Automation Hierarchy.
        Private m_oApp As InteropServices.Application

        '*** 
        '*** Current document, folder , page, and field numbers
        '*** 

        Private m_nDocumentNumber As Short
        Private m_nFolderNumber As Short
        Private m_nPageNumber As Short
        Private m_nFieldNumber As Short

        '*** Sequence number to keep tree keys different
        Private m_nNodeKeySeq As Short

        '*** Maximum elements in event list
        Private Const m_lMaxListSize As Integer = 200

        '*** Divider character for keys - Set when we init properties
        Private m_strKeyChar As String

        '*** Remember if we have ascent capture features
        Private m_bHasAscentCaptureFeatures As Boolean

        '*** 
        '*** Held object references to test object lifetime
        '*** 

        Private m_oHeldBatch As InteropServices.Batch
        Private m_oHeldDocuments As InteropServices.Documents
        Private m_oHeldDocument As InteropServices.Document
        Private m_oHeldPages As InteropServices.Pages
        Private m_oHeldPage As InteropServices.Page
        Private m_oHeldFields As InteropServices.IndexFields
        Private m_oHeldField As InteropServices.IndexField
        Private m_oHeldCustomProperties As InteropServices.CustomProperties
        Private m_oHeldCustomProperty As InteropServices.CustomProperty
        Private m_oHeldSuggestedValues As InteropServices.SuggestedValues
        Private m_oHeldSuggestedValue As InteropServices.SuggestedValue

        '*** We need to remember all of the menu items
        Dim m_oMenuCollection As MenuCollection

        Private Mode_debug As Boolean
        Private timtst As Boolean

        Private WithEvents Timer1 As System.Timers.Timer

        '**************************************************
        '*** Function:  Application
        '*** Purpose:   Sets the application object - Base of hierarchy
        '*** Input:     none
        '*** Output:    none
        '**************************************************
        Public WriteOnly Property Application() As InteropServices.Application
            Set(ByVal Value As InteropServices.Application)
                Try
                    m_oApp = Value

                    '*** See if we are actually running with Ascent Capture or some derivitive product
                    m_bHasAscentCaptureFeatures = m_oApp.HasAscentCaptureFeatures

                Catch ex As Exception
                    ExceptionHandler.HandleException("ApplicationError Error: ", ex)
                End Try
            End Set
        End Property

        Private vAppPath As String
        Public ReadOnly Property AppPath As String
            Get
                If String.IsNullOrEmpty(vAppPath) Then
                    vAppPath = Path.GetDirectoryName((New System.Uri(Assembly.GetExecutingAssembly().EscapedCodeBase)).LocalPath)
                End If
                Return vAppPath
            End Get
        End Property

        '**************************************************
        '*** Function:  ActionEvent
        '*** Purpose:   Receive each action event, respond by
        '***            adding the event to the listbox
        '*** Input:     nActionNumber - number assigned to
        '***                            event
        '*** Output:    vArgument - currently NOT used
        '***            pnCancel - Response to the event.
        '***                       Only DocumentClosing and
        '***                       FieldExiting process the response
        '*** Return:    ActionEvent returned is currently ignored.
        '**************************************************
        Public Function ActionEvent(ByVal nActionNumber As Short, ByRef vArgument As Object, ByRef pnCancel As Short) As Short

            Dim strActionEvent As String '*** Text to display for action event

            '*** Set the return values
            pnCancel = 0
            ActionEvent = 0

            '*** Get the document, folder , page and field indexes
            m_nDocumentNumber = 0
            m_nFolderNumber = 0
            m_nPageNumber = 0
            m_nFieldNumber = 0

            Using oActiveBatchWrap As New ApiObjectWrapper(Of InteropServices.Batch)(m_oApp.ActiveBatch)

                '*** 
                '*** The following code may fail, but the values will be left to 0 when caught
                '*** 
                If Not oActiveBatchWrap.IsNull Then

                    Try
                        Using oActiveFolderWrap As New ApiObjectWrapper(Of InteropServices.Folder)(oActiveBatchWrap.WrappedObject.ActiveFolder)
                            If Not oActiveFolderWrap.IsNull Then
                                m_nFolderNumber = oActiveFolderWrap.WrappedObject.OrderNumber
                            End If
                        End Using
                    Catch ex As Exception
                        m_nFolderNumber = 0
                    End Try

                    Using oActiveDocWrap As New ApiObjectWrapper(Of InteropServices.Document)(oActiveBatchWrap.WrappedObject.ActiveDocument)

                        If Not oActiveDocWrap.IsNull Then
                            m_nDocumentNumber = oActiveDocWrap.WrappedObject.OrderNumber

                            Using oActivePageWrap As New ApiObjectWrapper(Of InteropServices.Page)(oActiveDocWrap.WrappedObject.ActivePage)
                                If Not oActivePageWrap.IsNull Then
                                    m_nPageNumber = oActivePageWrap.WrappedObject.OrderNumber
                                End If
                            End Using

                            If m_bHasAscentCaptureFeatures Then
                                ' SPR 76462 - Error with document operations of SampleOCX.
                                Using oFormTypeWrap As New ApiObjectWrapper(Of InteropServices.FormType)(oActiveDocWrap.WrappedObject.FormType)
                                    If Not oFormTypeWrap.IsNull Then
                                        Using oActiveIndexFieldWrap As New ApiObjectWrapper(Of InteropServices.IndexField)(oActiveDocWrap.WrappedObject.ActiveIndexField)
                                            If Not oActiveIndexFieldWrap.IsNull Then
                                                m_nFieldNumber = oActiveIndexFieldWrap.WrappedObject.OrderNumber
                                            End If
                                        End Using
                                    End If
                                End Using
                            End If
                        End If
                    End Using
                End If
            End Using
            '*** 
            '*** Display some text for each action event
            '*** 

            Try

                Select Case nActionNumber

                    '*** 
                    '*** Batch Events
                    '*** 

                    Case InteropServices.KfxOcxEvent.KfxOcxEventBatchCreating
                        strActionEvent = "Batch Creating"

                    Case InteropServices.KfxOcxEvent.KfxOcxEventBatchOpened
                        strActionEvent = "Batch Opened"
                        Timer1.Start()

                    Case InteropServices.KfxOcxEvent.KfxOcxEventBatchClosing
                        strActionEvent = "Batch Closing"

                    Case InteropServices.KfxOcxEvent.KfxOcxEventBatchRejecting
                        strActionEvent = "Batch Rejecting"

                    Case InteropServices.KfxOcxEvent.KfxOcxEventBatchSuspending
                        strActionEvent = "Batch Suspending"

                    Case InteropServices.KfxOcxEvent.KfxOcxEventBatchDeleting
                        strActionEvent = "Batch Deleting"

                    Case InteropServices.KfxOcxEvent.KfxOcxEventBatchOpeningNext
                        strActionEvent = "Batch Opening Next"

                    Case InteropServices.KfxOcxEvent.KfxOcxEventBatchOpeningSelect
                        strActionEvent = "Batch Opening Select"

                    Case InteropServices.KfxOcxEvent.KfxOcxEventBatchOpeningID
                        strActionEvent = "Batch Opening ID"

                    Case InteropServices.KfxOcxEvent.KfxOcxEventBatchOpeningCheck
                        '*** Check to see if any batches can be opened when opening
                        '*** in Scan - Otherwise, we will go directly to the new batch dialog
                        strActionEvent = "Batch Opening Check"

                    Case InteropServices.KfxOcxEvent.KfxOcxEventBatchPropertiesDisplaying
                        strActionEvent = "Batch Properties"

                        '*** 
                        '*** Documents
                        '*** 

                    Case InteropServices.KfxOcxEvent.KfxOcxEventDocumentOpened
                        strActionEvent = "Document " & m_nDocumentNumber & " Opened"

                    Case InteropServices.KfxOcxEvent.KfxOcxEventDocumentValidating
                        strActionEvent = "Document " & m_nDocumentNumber & " Validating"

                    Case InteropServices.KfxOcxEvent.KfxOcxEventDocumentClosing
                        strActionEvent = "Document " & m_nDocumentNumber & " Closing"

                        '*** 
                        '*** Folders
                        '*** 

                    Case InteropServices.KfxOcxEvent.KfxOcxEventFolderOpened
                        strActionEvent = "Folder " & m_nFolderNumber & " Opened"

                    Case InteropServices.KfxOcxEvent.KfxOcxEventFolderValidating
                        strActionEvent = "Folder " & m_nFolderNumber & " Validating"

                    Case InteropServices.KfxOcxEvent.KfxOcxEventFolderClosing
                        strActionEvent = "Folder " & m_nFolderNumber & " Closing"

                        '*** 
                        '*** Fields
                        '*** 

                    Case InteropServices.KfxOcxEvent.KfxOcxEventFieldEntered
                        strActionEvent = "Field " & m_nFieldNumber & " Entered"

                    Case InteropServices.KfxOcxEvent.KfxOcxEventFieldExiting
                        strActionEvent = "Field " & m_nFieldNumber & " Exiting"

                        '*** 
                        '*** Content/Context change
                        '*** 

                    Case InteropServices.KfxOcxEvent.KfxOcxEventContextChanged
                        strActionEvent = "Context Changed ( Document " & m_nDocumentNumber & ", Folder " & m_nFolderNumber & ", Page " & m_nPageNumber & ", Field " & m_nFieldNumber & " )"

                    Case InteropServices.KfxOcxEvent.KfxOcxEventPropertyChanged
                        strActionEvent = "Property Changed"

                    Case InteropServices.KfxOcxEvent.KfxOcxEventContentChanged
                        strActionEvent = "Content Changed"

                        '*** 
                        '*** Batch Edit/Data Entry
                        '*** 

                    Case InteropServices.KfxOcxEvent.KfxOcxEventBatchEditModeEntered
                        strActionEvent = "Batch Edit Mode Entered"

                    Case InteropServices.KfxOcxEvent.KfxOcxEventDataEntryModeEntered
                        strActionEvent = "Data Entry Mode Entered"

                        '*** 
                        '*** Scan start/stop
                        '*** 

                    Case InteropServices.KfxOcxEvent.KfxOcxEventScanBatchStarted
                        strActionEvent = "Started Scanning Pages"

                    Case InteropServices.KfxOcxEvent.KfxOcxEventScanPageStarted
                        strActionEvent = "Started Scanning One Page"

                    Case InteropServices.KfxOcxEvent.KfxOcxEventScanStopped
                        strActionEvent = "Scanning Complete"

                        '*** 
                        '*** Error logging event
                        '*** 

                    Case InteropServices.KfxOcxEvent.KfxOcxEventErrorLogging
                        strActionEvent = "Error Logging"

                        '*** 
                        '*** Dialogs
                        '*** 

                    Case InteropServices.KfxOcxEvent.KfxOcxEventAboutBoxDisplaying
                        strActionEvent = "About Box Displaying"

                        '*** 
                        '*** Logging In
                        '*** 

                    Case InteropServices.KfxOcxEvent.KfxOcxEventLoggingIn
                        strActionEvent = "Logging In"
                        '*** For now, we don't actually invoke the login because
                        '*** it makes demonstration of this application annoying.
                        '*** Uncomment the following lines to see a login example.
                        'If Not LogIn() Then
                        'pnCancel = 1
                        'End If

                        '*** 
                        '*** Logging out
                        '*** 

                    Case InteropServices.KfxOcxEvent.KfxOcxEventLoggedOut
                        strActionEvent = "Logged Out"
                        '*** We don't do anything special with this event in the sample

                        '*** 
                        '*** Menu clicked event
                        '*** 

                    Case InteropServices.KfxOcxEvent.KfxOcxEventMenuClicked

                        '*** Special menus that must be added to registry.
                        '*** To test this add "ShowMe" as a EventText

                        If vArgument = "ShowMe" Then
                            m_oApp.ShowWindow(True)
                        End If

                        '*** To test this add "HideMe" as a EventText
                        If vArgument = "HideMe" Then
                            m_oApp.ShowWindow(False)
                        End If

                        '*** To test this add "ShowDialog" as a EventText
                        If vArgument = "ShowDialog" Then
                            MsgBox("Sample Dialog", MsgBoxStyle.OkOnly, "My Dialog")
                        End If

                        strActionEvent = "Menu Clicked (EventText = " & vArgument & " )"

                    Case InteropServices.KfxOcxEvent.KfxOcxEventAppThemeChanged
                        Dim oColor As InteropServices.IRGB = m_oApp.Theme.BackgroundColor
                        Me.BackColor = Drawing.Color.FromArgb(oColor.Red, oColor.Green, oColor.Blue)
                        strActionEvent = "Theme changed"
                    Case Else '*** Other values.
                        strActionEvent = "Unknown ActionEvent " & nActionNumber
                End Select

            Catch ex As Exception
                txtLog.Invoke(Sub() txtLog.AppendText("ActionEvent Error: " & ex.Message & vbCrLf))
                ExceptionHandler.HandleException("ActionEvent Error: ", ex)
            End Try

        End Function

        '**************************************************
        '*** Function:  LogIn
        '*** Purpose:   Display LogIn dialog
        '*** Input:     none
        '*** Output:    none
        '*** Return:    TRUE-login OK, FALSE-don't login
        '**************************************************
        Public Function LogIn() As Boolean

            Dim oLoginForm As LoginForm

            Try
                oLoginForm = New LoginForm
                LogIn = True ' initialize return

                '*** Show the form modally
                oLoginForm.ShowDialog(Me)

                '*** Exit if cancel
                If Not oLoginForm.OK Then
                    LogIn = False
                End If
            Catch ex As Exception
                Throw
            Finally
                If Not IsNothing(oLoginForm) Then
                    oLoginForm.Dispose()
                    oLoginForm = Nothing
                End If
            End Try

        End Function


        '**************************************************
        '*** Function:  HandleBatchEditMovePageToDocument
        '*** Purpose:   Handle Move Page To Document command
        '*** Input:     none
        '*** Output:    none
        '**************************************************
        Private Sub HandleBatchEditMovePageToDocument()


            Dim oInsertPage As InteropServices.Page

            Try
                '*** 
                '*** Get the current page
                '*** 
                Using oPageWrap As New ApiObjectWrapper(Of InteropServices.Page)(GetActivePage())
                    If oPageWrap.IsNull Then
                        MsgBox("No active page.")
                        Exit Sub
                    Else

                        '*** 
                        '*** Get the parameters
                        '*** 
                        Dim oInsertDoc As InteropServices.Document

                        Dim oIndex As Integer = 0
                        Using frmEntry As New DataEntryForm
                            frmEntry.EntryCaption = "Enter document order number:"
                            frmEntry.Value = ""
                            frmEntry.ShowDialog(Me)
                            If Not frmEntry.OK Then Exit Sub
                            oIndex = Convert.ToInt32(frmEntry.Value)
                        End Using

                        Using oActiveBatch As New ApiObjectWrapper(Of InteropServices.Batch)(m_oApp.ActiveBatch)
                            Try
                                '*** 
                                '*** Get the document
                                '*** 
                                Using oDocCollWrap As New ApiObjectWrapper(Of InteropServices.Documents)(oActiveBatch.WrappedObject.Documents)
                                    If Not oDocCollWrap.IsNull Then
                                        oInsertDoc = oDocCollWrap.WrappedObject.Item(oIndex)
                                    End If
                                End Using
                            Catch ex As Exception
                                oInsertDoc = Nothing
                            End Try
                        End Using

                        If IsNothing(oInsertDoc) Then
                            MsgBox("Document not found.")
                            Exit Sub
                        End If

                        Using frmEntry As New DataEntryForm
                            frmEntry.EntryCaption = "Enter order number of page before which to insert or 0 to append:"
                            frmEntry.Value = ""
                            frmEntry.ShowDialog(Me)
                            If Not frmEntry.OK Then Exit Sub
                            oIndex = Convert.ToInt32(frmEntry.Value)
                        End Using

                        Try
                            '*** 
                            '*** Get the page
                            '*** 
                            Using oPageCollWrap As New ApiObjectWrapper(Of InteropServices.Pages)(oInsertDoc.Pages)
                                If Not oPageCollWrap.IsNull Then
                                    oInsertPage = oPageCollWrap.WrappedObject.Item(oIndex)
                                End If
                            End Using
                        Catch ex As Exception
                            oInsertPage = Nothing
                        End Try

                        oPageWrap.WrappedObject.MoveToDocument(oInsertDoc, oInsertPage)
                    End If
                End Using
            Catch ex As Exception
                Throw
            Finally
                If Not IsNothing(oInsertPage) Then
                    oInsertPage.Dispose()
                    oInsertPage = Nothing
                End If
            End Try

        End Sub



        '**************************************************
        '*** Function:  BatchControlRejectBatch
        '*** Purpose:   Handle batch Reject command
        '*** Input:     none
        '*** Output:    none
        '**************************************************
        Private Sub BatchControlRejectBatch()

            Using frmEntry As New DataEntryForm
                '*** Get rejection message
                frmEntry.EntryCaption = "Enter rejection message:"
                frmEntry.Value = ""
                frmEntry.ShowDialog(Me)
                If Not frmEntry.OK Then Exit Sub
                m_oApp.RejectBatch(frmEntry.Value)
            End Using

        End Sub


        '**************************************************
        '*** Function:  GetActivePage
        '*** Purpose:   Return the currently active loose or document page
        '*** Input:     none
        '*** Output:    none
        '**************************************************
        Private Function GetActivePage() As InteropServices.Page

            Dim oPage As InteropServices.Page = Nothing

            Using oActiveBatch As New ApiObjectWrapper(Of InteropServices.Batch)(m_oApp.ActiveBatch)
                oPage = oActiveBatch.WrappedObject.ActiveLoosePage

                If IsNothing(oPage) Then
                    Using oDocWrap As New ApiObjectWrapper(Of InteropServices.Document)(oActiveBatch.WrappedObject.ActiveDocument)
                        If Not oDocWrap.IsNull Then
                            oPage = oDocWrap.WrappedObject.ActivePage
                        End If
                    End Using
                End If
            End Using
            Return oPage

        End Function


        Private Sub Processing(mobat As InteropServices.Batch)

            ' Cette proc�dure permet de s�parer les documents et de supprimer les pages blanches
            ' Fonctionnement :  On parcourt tous les documents, on va chercher dans le fichier Gecod.ini
            '                   le nombre de pages reglementaires de cette classe de document
            '                   S'il y en a plus que pr�vu, on cr�� pour chaque page suppl�mentaire
            '                   un document de type "Annexe � traiter" ou "mixte" (selon la classe de lots)
            '                   En parall�le, pour chaque document, on supprime les pages blanches, c'est
            '                   � dire les pages dont le poids de l'image est inf�rieure au poids max
            '                   param�tr� dans le fichier Gecod.ini


            Dim cptPage As Integer
            Dim nbPageType As Integer
            Dim nbDoc As Integer
            Dim testPB As Boolean
            Dim FileName As String
            Dim IniFile As String

            Dim oDocuments As InteropServices.Documents
            Dim oNewDocuments As InteropServices.Documents
            Dim oDocument As InteropServices.Document
            Dim oNewDocument As InteropServices.Document
            Dim oPages As InteropServices.Pages
            Dim oPage As InteropServices.Page
            Dim i, j As Integer
            Dim test As Boolean
            Dim pos As Integer
            Dim libClass As String
            Dim cptClass As Integer

            Mode_debug = True

            Try



                m_oApp.ValidationMode = InteropServices.KfxApiValidationMode.KfxApiValidationModeBatchEditing

                'Modif JDT Ano 166
                m_oApp.IgnoreDocumentNavigationValidationError = True


                pos = 0

                'Acc�s au fichier Gecod.ini
                If Mode_debug Then
                    txtLog.Invoke(Sub() txtLog.AppendText("AppPath = " & AppPath & vbCrLf))
                End If
                FileName = Path.Combine(AppPath, "Gecod.ini")
                If Not File.Exists(FileName) Then
                    txtLog.Invoke(Sub() txtLog.AppendText("Fichier d'initialisation Gecod.ini introuvable." & vbCrLf))
                    MsgBox("Fichier d'initialisation Gecod.ini introuvable.")
                Else
                    txtLog.Invoke(Sub() txtLog.AppendText("Fichier d'initialisation Gecod.ini trouv�: " & FileName & vbCrLf))
                    IniFile = FileName

                    nbDoc = 1

                    '***** TEST JDT
                    ' Set oDocuments = mobat.Documents
                    '    While (nbDoc <= oDocuments.Count)
                    '    Set oDocument = oDocuments.Item(nbDoc)
                    'test = m_oApp.SetActiveContext(nbDoc, 0, 0)
                    'For i = 1 To oDocument.PageCount
                    'MsgBox "Prochaine page: " & i
                    'test = m_oApp.SetActiveContext(0, i, 0)
                    'Next i
                    'If i = oDocument.PageCount Then Exit Sub
                    'nbDoc = nbDoc + 1
                    'Wend
                    '***** TEST JDT

                    oDocuments = mobat.Documents

                    'Parcours des documents du lot
                    While (nbDoc <= oDocuments.Count)
                        oDocument = oDocuments.Item(nbDoc)

                        'Si la case Nb Page Fixe a �t� coch�e et �gale � 1, il faut emp�cher la suppression de page blanche
                        'Si 0 alors le traitement de s�paration ne s ex�cute pas
                        'Si 1 on peut effectuer le traitement
                        nbPageType = Nothing

                        ' On ne passe en s�paration que si la classe de doc est d�finie pour + d'1 page
                        If GetIniInteger("PASSAGESEPARATION", oDocument.FormType.Name, IniFile, nbPageType) And (nbPageType > 0) Then

                            'Suppression des pages blanches
                            oPages = oDocument.Pages


                            For Each oPage In oPages
                                testPB = DeleteIfEmptyPage(mobat, oPage, IniFile)
                            Next

                            oPages = oDocument.Pages

                            'Attribution du nombre de pages r�glementaire renseign� dans le Gecod.ini
                            If GetIniInteger("NBPAGESFIXE", oDocument.FormType.Name, IniFile, nbPageType) And (nbPageType > 0) Then

                                'test = m_oApp.SetActiveContext(nbDoc, 0, 0)
                                mobat.ActiveDocument = mobat.Documents.Item(nbDoc)

                                'S�paration
                                pos = 0

                                For cptPage = nbPageType + 1 To oPages.Count Step 1
                                    If Mode_debug Then MsgBox("n1")
                                    oDocuments = mobat.Documents
                                    If Mode_debug Then MsgBox("n1.1")
                                    oPage = oPages.Item(oPages.Count)
                                    If Mode_debug Then MsgBox("n1.2")
                                    'Maintenant, il faut mettre le derni�re page dans un nouveau doc

                                    'Cr�ation du nouveau document
                                    If ((nbDoc + pos + 1) > mobat.Documents.Count) Then
                                        If Mode_debug Then MsgBox("n1.3")
                                        oNewDocument = mobat.CreateDocument()
                                    Else
                                        If Mode_debug Then MsgBox("n1.4")
                                        oNewDocument = mobat.CreateDocument(oDocuments.Item(nbDoc + pos + 1))
                                    End If
                                    If Mode_debug Then MsgBox("n2")
                                    'On d�termine la classe associ�e � ce document
                                    libClass = GetIniString("ANNEXE", mobat.ClassName, IniFile)
                                    If Mode_debug Then MsgBox("n2.1")
                                    cptClass = 1
                                    While ((cptClass <= mobat.FormTypes.Count) And (StrComp(mobat.FormTypes.Item(cptClass).Name, libClass) <> 0))
                                        If Mode_debug Then MsgBox("n2.2")
                                        cptClass = cptClass + 1
                                    End While
                                    If Mode_debug Then MsgBox("n3")
                                    'Recherche du lib�ll� de la classe de doc Annexe (nom du formulaire associ�)
                                    If (cptClass <= mobat.FormTypes.Count) Then
                                        oNewDocument.FormType = mobat.FormTypes.Item(cptClass)
                                    Else
                                        oNewDocument.FormType = mobat.FormTypes.Item(3)
                                    End If
                                    If Mode_debug Then MsgBox("Position du Doc: " & nbDoc)
                                    ' test = m_oApp.SetActiveContext(nbDoc, 0, 0)
                                    mobat.ActiveDocument = mobat.Documents.Item(nbDoc)


                                    If Mode_debug Then MsgBox("Position de la page: cptPage:" & cptPage & " - pos:" & pos)
                                    'test = m_oApp.SetActiveContext(0, cptPage - pos, 0)
                                    mobat.ActivePage = mobat.ActiveDocument.Pages.Item(cptPage - pos)

                                    'If Mode_debug Then MsgBox "Position de la page: 1"
                                    '                    test = m_oApp.SetActiveContext(0, 1, 0)
                                    '                    If Mode_debug Then MsgBox "Position de la page: 2"
                                    '                    test = m_oApp.SetActiveContext(0, 2, 0)
                                    '                    If Mode_debug Then MsgBox "Position de la page: 3"
                                    '                    test = m_oApp.SetActiveContext(0, 3, 0)
                                    '                    If Mode_debug Then MsgBox "Position de la page: 4"
                                    '                    test = m_oApp.SetActiveContext(0, 4, 0)
                                    '                    If Mode_debug Then MsgBox "Position de la page: 5"
                                    '                    test = m_oApp.SetActiveContext(0, 5, 0)
                                    '                    If Mode_debug Then MsgBox "Position de la page: 6"
                                    '                    test = m_oApp.SetActiveContext(0, 6, 0)
                                    '                Exit Sub
                                    'test = m_oApp.SetActiveContext(0, 1, 0)

                                    'On met notre page dans le nouveau document
                                    If Mode_debug Then MsgBox("n5")
                                    Call oDocument.ActivePage.MoveToDocument(oNewDocument)
                                    If Mode_debug Then MsgBox("n5.1")
                                    oDocuments = mobat.Documents
                                    If Mode_debug Then MsgBox("n6")
                                    pos = pos + 1
                                    If Mode_debug Then MsgBox("6.1")
                                Next
                                If Mode_debug Then MsgBox("n7")
                                nbDoc = nbDoc + pos
                                If Mode_debug Then MsgBox("n8")
                            End If
                        End If
                        nbDoc = nbDoc + 1
                    End While

                End If
                Exit Sub

            Catch ex As Exception
                txtLog.Invoke(Sub() txtLog.AppendText("Processing Error: " & ex.Message & vbCrLf))
                'Error_Msgbox("Processing: ", ex.Message)
            End Try
        End Sub

        '********************************************************************************
        '*** Sub:       Error_Msgbox
        '*** Purpose:   Displays an error message box
        '*** Inputs:    strFunction - The function where the error occurred
        '*** Outputs:   None
        '********************************************************************************
        Private Sub Error_Msgbox(ByVal strFunction As String, Optional ByVal strError As String = "")

            If Len(strError) = 0 Then
                strError = "Error #" & Err.Number & " occurred in " _
                & Err.Source & vbCrLf & vbCrLf _
                & Err.Description
            End If

            MsgBox(strError, vbOKOnly Or vbCritical)

        End Sub

        Public Function DeleteIfEmptyPage(mobat As InteropServices.Batch, oPage As InteropServices.Page, IniFile As String) As Boolean
            Dim Calibre As Integer

            Try
                Calibre = Convert.ToInt32(GetIniString("PAGEBLANCHE", "POIDSMAX", IniFile))

                If (FileLen(oPage.FileName) < Calibre) Then
                    If Mode_debug Then MsgBox("Image supprim�e")
                    'tstDelete = m_oApp.SetActiveContext(0, oPage.OrderNumber, 0)
                    mobat.ActiveDocument = mobat.Documents.Item(0)
                    mobat.ActivePage = mobat.Documents.Item(0).Pages.Item(0)
                    Call mobat.DeletePage(oPage)
                    Return True
                End If
            Catch ex As Exception

            End Try

            Return False
        End Function

        '**************************************************
        '*** Routine:   InitUserControl
        '*** Purpose:   Init member variables
        '*** Input:     none
        '*** Output:    none
        '**************************************************
        Private Sub InitUserControl()

            Try
                m_nDocumentNumber = 0
                m_nFolderNumber = 0
                m_nPageNumber = 0
                m_nFieldNumber = 0
                m_nNodeKeySeq = 0
                m_strKeyChar = Chr(0)
                m_bHasAscentCaptureFeatures = False
                m_oMenuCollection = New MenuCollection

                Mode_debug = True

                Timer1 = New Timers.Timer(500)
                chkDebug.Checked = Mode_debug

                txtLog.ResetText()

            Catch ex As Exception
                ExceptionHandler.HandleException("InitProperties Error : ", ex)
            End Try

        End Sub

        Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Elapsed
            Timer1.Stop()

            If timtst = False Then
                informations.Invoke(Sub() informations.Text = "Traitement du lot en cours " & vbCrLf & " Veuillez patientez...")

                Call Processing(m_oApp.ActiveBatch)

                informations.Invoke(Sub() informations.Text = "Vous pouvez saisir/valider vos donn�es.")
                timtst = True
                '                tst = m_oApp.SetActiveContext(1, 0, 0)
                If m_oApp.ActiveBatch.Documents.Count > 0 Then
                    m_oApp.ActiveBatch.ActiveDocument = m_oApp.ActiveBatch.Documents.Item(1)
                End If
                m_oApp.ValidationMode = InteropServices.KfxApiValidationMode.KfxApiValidationModeDataEntry
                End If
        End Sub


        '**************************************************
        '*** Routine:   OnGotFocus
        '*** Purpose:   Restore focus to the last active 
        '***            control
        '*** Input:     eventArgs - just passed to the base
        '***            class event handler
        '*** Output:    none
        '**************************************************
        Protected Overrides Sub OnGotFocus(ByVal eventArgs As EventArgs)
            MyBase.OnGotFocus(eventArgs)
            If Not ActiveControl Is Nothing Then ActiveControl.Focus()
        End Sub

        Private Sub chkDebug_CheckedChanged(sender As Object, e As EventArgs) Handles chkDebug.CheckedChanged
            Mode_debug = chkDebug.Checked
            txtLog.Visible = Mode_debug
        End Sub
    End Class

End Namespace

