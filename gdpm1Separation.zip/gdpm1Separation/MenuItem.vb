Option Strict Off
Option Explicit On 

Imports System.Runtime.InteropServices
Imports InteropServices = Kofax.Capture.CaptureModule.InteropServices

Namespace Kofax.Samples.SmpleOcx

    <ProgId("Kofax.MenuItem")> _
    Friend Class MenuItem
        '******************************************************************************
        '***
        '*** Module:    MenuItem
        '*** Purpose:   Container class for menuItem collection
        '***
        '*** (c) Copyright 2006 Kofax Image Products
        '*** All rights reserved.
        '***
        '******************************************************************************

        Public strMenu As String
        Public strName As String
        Public strLocation As String
        Public strMenuBarText As String
		Public lState As InteropServices.KfxShowMenu

    End Class

End Namespace
