Option Strict Off
Option Explicit On 
Imports InteropServices = Kofax.Capture.CaptureModule.InteropServices

Imports System.Runtime.InteropServices

Namespace Kofax.Samples.SmpleOcx

    Friend Class ShowMenuForm
        Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

		Public Sub New(ByRef oApp As InteropServices.Application, ByRef oMenuCollecion As MenuCollection)
			MyBase.New()

			Try
				'This call is required by the Windows Form Designer.
				IsInitializing = True
				InitializeComponent()
				IsInitializing = False

				'*** Sets the application object from the control
				Try
					m_oApp = oApp
				Catch ex As Exception
					MsgBox("ApplicationError Error: " & ex.Message)
				End Try

				'*** This collection keeps track of every menu item added
				m_oMenuCollection = New MenuCollection
				m_oMenuCollection = oMenuCollecion
			Catch ex As Exception
				ExceptionHandler.HandleException("New Error: ", ex)
			End Try
		End Sub

        'Form overrides dispose to clean up the component list.
        Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
            If disposing Then
                m_oApp = Nothing
                m_oMenuCollection = Nothing
                If Not IsNothing(components) Then
                    components.Dispose()
                End If
            End If
            MyBase.Dispose(disposing)
        End Sub

        'Required by the Windows Form Designer
        Private components As System.ComponentModel.IContainer

        'NOTE: The following procedure is required by the Windows Form Designer
        'It can be modified using the Windows Form Designer.  
        'Do not modify it using the code editor.
        Friend WithEvents cmdApply As System.Windows.Forms.Button
        Friend WithEvents cmdClose As System.Windows.Forms.Button
        Friend WithEvents cmbMenuText As System.Windows.Forms.ComboBox
        Friend WithEvents txtLocation As System.Windows.Forms.TextBox
        Friend WithEvents txtEventText As System.Windows.Forms.TextBox
        Friend WithEvents txtMenuBar As System.Windows.Forms.TextBox
        Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
        Friend WithEvents optShow As System.Windows.Forms.RadioButton
        Friend WithEvents optHide As System.Windows.Forms.RadioButton
        Friend WithEvents Label2 As System.Windows.Forms.Label
        Friend WithEvents Label3 As System.Windows.Forms.Label
        Friend WithEvents Label4 As System.Windows.Forms.Label
        Friend WithEvents Label1 As System.Windows.Forms.Label
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
			Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(ShowMenuForm))
			Me.cmdApply = New System.Windows.Forms.Button()
			Me.cmdClose = New System.Windows.Forms.Button()
			Me.cmbMenuText = New System.Windows.Forms.ComboBox()
			Me.txtLocation = New System.Windows.Forms.TextBox()
			Me.txtEventText = New System.Windows.Forms.TextBox()
			Me.txtMenuBar = New System.Windows.Forms.TextBox()
			Me.GroupBox1 = New System.Windows.Forms.GroupBox()
			Me.optHide = New System.Windows.Forms.RadioButton()
			Me.optShow = New System.Windows.Forms.RadioButton()
			Me.Label2 = New System.Windows.Forms.Label()
			Me.Label3 = New System.Windows.Forms.Label()
			Me.Label4 = New System.Windows.Forms.Label()
			Me.Label1 = New System.Windows.Forms.Label()
			Me.GroupBox1.SuspendLayout()
			Me.SuspendLayout()
			'
			'cmdApply
			'
			resources.ApplyResources(Me.cmdApply, "cmdApply")
			Me.cmdApply.Name = "cmdApply"
			'
			'cmdClose
			'
			Me.cmdClose.DialogResult = System.Windows.Forms.DialogResult.Cancel
			resources.ApplyResources(Me.cmdClose, "cmdClose")
			Me.cmdClose.Name = "cmdClose"
			'
			'cmbMenuText
			'
			resources.ApplyResources(Me.cmbMenuText, "cmbMenuText")
			Me.cmbMenuText.Name = "cmbMenuText"
			'
			'txtLocation
			'
			resources.ApplyResources(Me.txtLocation, "txtLocation")
			Me.txtLocation.Name = "txtLocation"
			'
			'txtEventText
			'
			resources.ApplyResources(Me.txtEventText, "txtEventText")
			Me.txtEventText.Name = "txtEventText"
			'
			'txtMenuBar
			'
			resources.ApplyResources(Me.txtMenuBar, "txtMenuBar")
			Me.txtMenuBar.Name = "txtMenuBar"
			'
			'GroupBox1
			'
			Me.GroupBox1.Controls.Add(Me.optHide)
			Me.GroupBox1.Controls.Add(Me.optShow)
			Me.GroupBox1.FlatStyle = System.Windows.Forms.FlatStyle.System
			resources.ApplyResources(Me.GroupBox1, "GroupBox1")
			Me.GroupBox1.Name = "GroupBox1"
			Me.GroupBox1.TabStop = False
			'
			'optHide
			'
			resources.ApplyResources(Me.optHide, "optHide")
			Me.optHide.Name = "optHide"
			'
			'optShow
			'
			Me.optShow.Checked = True
			resources.ApplyResources(Me.optShow, "optShow")
			Me.optShow.Name = "optShow"
			Me.optShow.TabStop = True
			'
			'Label2
			'
			Me.Label2.FlatStyle = System.Windows.Forms.FlatStyle.System
			resources.ApplyResources(Me.Label2, "Label2")
			Me.Label2.Name = "Label2"
			'
			'Label3
			'
			Me.Label3.FlatStyle = System.Windows.Forms.FlatStyle.System
			resources.ApplyResources(Me.Label3, "Label3")
			Me.Label3.Name = "Label3"
			'
			'Label4
			'
			Me.Label4.FlatStyle = System.Windows.Forms.FlatStyle.System
			resources.ApplyResources(Me.Label4, "Label4")
			Me.Label4.Name = "Label4"
			'
			'Label1
			'
			Me.Label1.FlatStyle = System.Windows.Forms.FlatStyle.System
			resources.ApplyResources(Me.Label1, "Label1")
			Me.Label1.Name = "Label1"
			'
			'ShowMenuForm
			'
			Me.AcceptButton = Me.cmdApply
			resources.ApplyResources(Me, "$this")
			Me.CancelButton = Me.cmdClose
			Me.Controls.Add(Me.Label1)
			Me.Controls.Add(Me.Label4)
			Me.Controls.Add(Me.Label3)
			Me.Controls.Add(Me.Label2)
			Me.Controls.Add(Me.GroupBox1)
			Me.Controls.Add(Me.txtMenuBar)
			Me.Controls.Add(Me.txtEventText)
			Me.Controls.Add(Me.txtLocation)
			Me.Controls.Add(Me.cmbMenuText)
			Me.Controls.Add(Me.cmdClose)
			Me.Controls.Add(Me.cmdApply)
			Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
			Me.MaximizeBox = False
			Me.MinimizeBox = False
			Me.Name = "ShowMenuForm"
			Me.ShowInTaskbar = False
			Me.GroupBox1.ResumeLayout(False)
			Me.ResumeLayout(False)
			Me.PerformLayout()

		End Sub

#End Region

        '********************************************************************************
        '***
        '*** Module:    ShowMenuForm
        '*** Purpose:   Dynamically show/hide menus
        '***
        '*** (c) Copyright 2006 Kofax Image Products.
        '*** All rights reserved.
        '***
        '********************************************************************************

		'*** The InteropServices.Application provides the base of the
		'*** Ascent Capture OLE Automation Hierarchy.
		Private m_oApp As InteropServices.Application

		'*** List of menu items
		Private m_oMenuCollection As MenuCollection

		'*** Checks if the form is being initialized
		Private m_bIsInitializing As Boolean = False

		'**************************************************
		'*** Function:  LoadShowMenuForm
		'*** Purpose:   Load the form and initialize the controls
		'*** Input:     none
		'*** Output:    none
		'**************************************************
		Private Sub LoadShowMenuForm(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Load
			Dim oMenuItem As New MenuItem

			For Each oMenuItem In m_oMenuCollection
				cmbMenuText.Items.Add(oMenuItem.strMenu)
			Next oMenuItem

			oMenuItem = m_oMenuCollection.Item(1)

			cmbMenuText.Text = oMenuItem.strMenu
			txtLocation.Text = oMenuItem.strLocation
			txtMenuBar.Text = oMenuItem.strMenuBarText
			txtEventText.Text = oMenuItem.strName
			If oMenuItem.lState = InteropServices.KfxShowMenu.KfxMenuHide Then
				optHide.Checked = True
			Else
				optShow.Checked = True
			End If

		End Sub

		'**************************************************
		'*** Function:  ClosedShowMenuForm
		'*** Purpose:   Free the app to prevent a leak
		'*** Input:     Cancel- ignored
		'*** Output:    none
		'**************************************************
		Private Sub ClosedShowMenuForm(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Closed
			m_oApp = Nothing
			m_oMenuCollection = Nothing
		End Sub

		'**************************************************
		'*** Function:  cmbMenuText_Click
		'*** Purpose:   Each time they change the menu comb
		'***            we need to update the other read-only
		'***            controls.
		'*** Input:     none
		'*** Output:    none
		'**************************************************
		Private Sub cmbMenuText_SelectedIndexChanged(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmbMenuText.SelectedIndexChanged

			'*** This check prevents the event from firing when
			'*** the form is initialized
			If Not Me.IsInitializing Then

				If (cmbMenuText.SelectedIndex = -1) Then
					MsgBox("No Item Selected")
					Exit Sub
				End If

				Dim oMenuItem As New MenuItem
				oMenuItem = m_oMenuCollection.Item(cmbMenuText.SelectedIndex + 1)
				txtLocation.Text = oMenuItem.strLocation
				txtMenuBar.Text = oMenuItem.strMenuBarText
				txtEventText.Text = oMenuItem.strName
				If oMenuItem.lState = InteropServices.KfxShowMenu.KfxMenuHide Then
					optHide.Checked = True
				Else
					optShow.Checked = True
				End If

			End If

		End Sub

		'**************************************************
		'*** Function:  cmdApplyClick
		'*** Purpose:   Ok, show/hide the menu item
		'*** Input:     none
		'*** Output:    none
		'**************************************************
		Private Sub cmdApply_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdApply.Click

			Dim oMenuItem As MenuItem

			Try
				oMenuItem = m_oMenuCollection.Item(cmbMenuText.SelectedIndex + 1)

				If optShow.Checked = False Then
					m_oApp.ShowMenu(InteropServices.KfxShowMenu.KfxMenuHide, txtEventText.Text, cmbMenuText.Text, txtLocation.Text, txtMenuBar.Text)
					oMenuItem.lState = InteropServices.KfxShowMenu.KfxMenuHide
				Else
					m_oApp.ShowMenu(InteropServices.KfxShowMenu.KfxMenuShow, txtEventText.Text, cmbMenuText.Text, txtLocation.Text, txtMenuBar.Text)
					oMenuItem.lState = InteropServices.KfxShowMenu.KfxMenuShow
				End If
			Catch ex As Exception
				ExceptionHandler.HandleException("Show/Hide Menu Error: ", ex)
			End Try

		End Sub

        '**************************************************
        '*** Function:  CancelButton
        '*** Purpose:   Closes the dialog.
        '*** Input:     none
        '*** Output:    none
        '**************************************************
        Private Sub cmdClose_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdClose.Click
            Me.Close()
        End Sub

        '**************************************************
        '*** Property:  IsInitializing
        '*** Purpose:   Checks if the form is being initialized
        '*** Input:     none
        '*** Output:    none
        '**************************************************
        Private Property IsInitializing() As Boolean
            Get
                IsInitializing = m_bIsInitializing
            End Get
            Set(ByVal Value As Boolean)
                m_bIsInitializing = Value
            End Set
        End Property

    End Class

End Namespace