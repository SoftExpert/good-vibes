Imports System.Reflection
Imports System.Runtime.CompilerServices
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following
' set of attributes. Change these attribute values to modify the information
' associated with an assembly


' TODO: Review the values of the assembly attributes


<Assembly: AssemblyTitle("Kofax Capture SmpleOCX ActiveX Component")>
<Assembly: AssemblyDescription("")>
<Assembly: AssemblyCompany("Kofax, Inc.")>
<Assembly: AssemblyProduct("Kofax Capture")>
<Assembly: AssemblyCopyright("© 2006-2021 Kofax. " &
		"All rights reserved.")>
<Assembly: AssemblyTrademark("")> 
<Assembly: AssemblyCulture("")>

' Version information for an assembly consists of the following four values:

'	Major version
'	Minor Version
'	Revision
'	Build Number

' You can specify all the values or you can default the Revision and Build Numbers
' by using the '*' as shown below


<Assembly: AssemblyVersion("11.1.0.0")>
<Assembly: AssemblyFileVersion("11.1.0.0")>
<Assembly: ComVisible(True)>
