Option Strict Off
Option Explicit On 

Imports System.Runtime.InteropServices

Namespace Kofax.Samples.SmpleOcx

    <ProgId("Kofax.MenuCollection")> _
    Friend Class MenuCollection
        Implements System.Collections.IEnumerable

        '*** Local variable to hold collection
        Private m_Col As Collection

        Public Sub Add(ByRef oMenuItem As MenuItem)
            m_Col.Add(oMenuItem)
        End Sub

        Default Public ReadOnly Property Item(ByVal vntIndexKey As Object) As MenuItem
            Get
                Item = m_Col.Item(vntIndexKey)
            End Get
        End Property

        Public ReadOnly Property Count() As Integer
            Get
                Count = m_Col.Count()
            End Get
        End Property

        Public Function GetEnumerator() As System.Collections.IEnumerator Implements System.Collections.IEnumerable.GetEnumerator
            GetEnumerator = m_Col.GetEnumerator
        End Function

        Public Sub Remove(ByRef vntIndexKey As Object)
            m_Col.Remove(vntIndexKey)
        End Sub

        Public Sub New()
            MyBase.New()
            m_Col = New Collection
        End Sub

    End Class

End Namespace

