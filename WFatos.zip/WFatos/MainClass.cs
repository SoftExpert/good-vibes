﻿using Kofax.Capture.SDK.Data;
using Kofax.Capture.SDK.Workflow;
using System;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;

namespace Galian
{
    /// <summary>
    /// Description of MyClass.
    /// </summary>
    /// 
    [type: ComVisible(true)]
	[Guid("F10B82AD-B612-444A-8A3C-EF1AB4BCB7E4")]
	[ClassInterface(ClassInterfaceType.None)]
	[ProgId("WFatos.atos")]
	public class WFAI : IACWorkflowAgent
	{
		private string FName = @"D:\temp\WfAI.log";

		private static void Dbg(string Message)
		{
			Debug.WriteLine(Message);
		}
        private static void Dbg(string Fmt, params string[] prm)
        {
			Debug.WriteLine(Fmt, prm);
        }

        [CLSCompliant(false)] // because ACWorkflowData is not CLS compliant
		public void ProcessWorkflow(ref Kofax.Capture.SDK.Workflow.IACWorkflowData oWorkflowData)
		{

			//logToFile("EnterProcess Workflow with " + oWorkflowData.CurrentModule.ID);

			// avoid executing if something goes really wrong
			if (oWorkflowData.CurrentModule == null)
			{
				return;
			}

			if (!KofaxModuleIDs.SPLIT_ID.Equals(oWorkflowData.CurrentModule.ID, StringComparison.InvariantCultureIgnoreCase))
			{
				return;
			}

			if (!"Error".Equals(oWorkflowData.NextState.Name, StringComparison.InvariantCultureIgnoreCase))
			{
				return;
			}

			KfxWfVars vars = new(ref oWorkflowData);
			string sCrtID = string.Empty;
			string sNextID = string.Empty;
			string msg = string.Empty;
			//try 1 - début
			try
			{

				sCrtID = oWorkflowData.CurrentModule.ID;
				sNextID = oWorkflowData.NextModule.ID;

                Dbg("BatchClass={0}, CurrentModuleID={1}, NextModuleID={2}", vars.BatchElement["BatchClassName"], sCrtID, sNextID);

				foreach (IACDataElement doc in vars.DocumentsCollection)
				{
					IACDataElement oPages = doc.FindChildElementByName("Pages");
                    foreach(IACDataElement page in oPages.FindChildElementsByName("Page"))
					{
						if (page.AttributeExists("Rejected"))
						{
							page["Rejected"] = "0";
                        }
					}
                }

				foreach (IACDataElement loosePage in vars.BatchElement.FindChildElementsByName("Page"))
				{
                    if (loosePage.AttributeExists("Rejected"))
                    {
                        loosePage["Rejected"] = "0";
                    }
                }

				oWorkflowData.NextModule = oWorkflowData.PossibleModules[KofaxModuleIDs.KCRecognition];
				oWorkflowData.NextState = oWorkflowData.PossibleStates["Ready"];
            }
			catch (Exception exc)
			{
				oWorkflowData.ErrorText = "Exception: " + exc.Message;

				//throw;
			}
			finally
			{
				vars.Dispose();
			}
		}
	}
}