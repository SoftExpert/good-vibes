﻿namespace Galian
{
	public struct KofaxModuleIDs
	{
		public const string KCBatchManager      = "ops.exe";
		public const string KCPDFGen            = "kfxpdf.exe";
		public const string KCQC                = "qc.exe";
		public const string KCRecognition       = "fp.exe";
		public const string KCRelease           = "release.exe";
		public const string KCScan              = "scan.exe";
		public const string KCValidation        = "index.exe";
		public const string KCVerify            = "verify.exe";
		
		
		public const string KTMCorrection       = "Kofax.Correction";
		public const string KTMDocumentReview   = "Kofax.DocumentReview";
		public const string KTMKBModule         = "LCI.KBModule";
		public const string KTMServer           = "LCI.Mailroom";
		public const string KTMServer2          = "LCI.MailroomInst2";
		public const string KTMValidation       = "LCI.Validation";
		public const string KTMVerification     = "Kofax.Verification";
		
		public const string XTrataServer        = "AC.XtrataSvr";
		
		public const string KCNServer           = "ACIRSA.exe";

		public const string SPLIT_ID			= "DICOM.DS2";
		
	//		public const string KTMValidation = "MailroomVal.exe";
	//		public const string KTMThinClientModule = "KCThinClientModule.exe";
	}	
}
