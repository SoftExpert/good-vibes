﻿using Kofax.Capture.DBLite;
using Kofax.Capture.SDK.Data;
using Kofax.Capture.SDK.Workflow;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.InteropServices;

namespace Galian
{
	public class KfxWfVars : IDisposable
	{
		#region property vars
		[CLSCompliant(false)]
		public IACWorkflowData oWorkflowData;

		private IACDataElement oRootSetupElement;
		private IACDataElement oRuntimeRootElement;

		private Batch oBatch;
		private IACDataElement oBatchElement;
		private IACDataElement oBatchClassesElement;
		private IACDataElementCollection oBatchClassElementColl;
		private IACDataElement oBatchClassElement;

		private IACDataElement oFoldersElement;
		private IACDataElementCollection oFoldersCollection;
		private IACDataElement oFolderElement;

		private IACDataElement oFolderDocumentsElement;
		private IACDataElementCollection oFolderDocumentsCollection;

		private IACDataElement oDocumentsElement;
		private IACDataElementCollection oDocumentsCollection;
		//private ACDataElement oDocumentElement;

		private IACDataElement oIndexFieldsElement;
		private IACDataElementCollection oIndexFieldsCollection;
		//private ACDataElement oIndexField;

		private IACWorkflowState oNextState;
		private IDictionary<string, string> oGlobalVars;
		#endregion
		[CLSCompliant(false)]
		public IACWorkflowData WfData
		{
			get
			{
				return this.oWorkflowData;
			}
		}

		[CLSCompliant(false)]
		public IACDataElement RootSetupElement
		{
			get
			{
				try
				{
					this.oRootSetupElement ??= this.oWorkflowData.ExtractSetupACDataElement(0);
					return this.oRootSetupElement;
				}
				catch (Exception)
				{
					return null;
				}
			}
			set
			{
				this.oRootSetupElement = value;
			}
		}

		[CLSCompliant(false)]
		public IACDataElement RuntimeRootElement
		{
			get
			{
				try
				{
					this.oRuntimeRootElement ??= this.oWorkflowData.ExtractRuntimeACDataElement((int)ACDataElementHints.HintDocumentIndexFields);
					return this.oRuntimeRootElement;
				}
				catch (Exception)
				{
					return null;
				}
			}
			set
			{
				this.oRuntimeRootElement = value;
			}
		}

		[CLSCompliant(false)]
		public Batch BatchObject
		{
			get
			{
				try
				{
                    //this.oWorkflowData.
                    this.oBatch ??= (Batch)this.RuntimeRootElement.FindChildElementByName("Batch");
                    return this.oBatch;
				}
				catch (Exception exc)
				{
					Debug.WriteLine("BatchObject exception : {0} {1} {2}", exc.Message, exc.Source, exc.StackTrace);
					return null;
				}
			}
			set
			{
				this.oBatch = value;
			}
		}


		[CLSCompliant(false)]
		public IACDataElement BatchElement
		{
			get
			{
				try
				{
					this.oBatchElement ??= this.RuntimeRootElement.FindChildElementByName("Batch");
					return this.oBatchElement;
				}
				catch (Exception exc)
				{
					Debug.WriteLine("BatchElement exception : {0} {1} {2}", exc.Message, exc.Source, exc.StackTrace);
					return null;
				}
			}
			set
			{
				this.oBatchElement = value;
			}
		}

		[CLSCompliant(false)]
		public IACDataElement BatchClassesElement
		{
			get
			{
				try
				{
					this.oBatchClassesElement ??= this.RootSetupElement.FindChildElementByName("BatchClasses");
					return this.oBatchClassesElement;
				}
				catch (Exception)
				{
					return null;
				}
			}
			set
			{
				this.oBatchClassesElement = value;
			}
		}

		[CLSCompliant(false)]
		public IACDataElementCollection BatchClassElementColl
		{
			get
			{
				try
				{
					this.oBatchClassElementColl ??= this.BatchClassesElement.FindChildElementsByName("BatchClass");
					return this.oBatchClassElementColl;
				}
				catch (Exception)
				{
					return null;
				}
			}
			set
			{
				this.oBatchClassElementColl = value;
			}
		}

		[CLSCompliant(false)]
		public IACDataElement BatchClassElement
		{
			get
			{
				try
				{
					this.oBatchClassElement ??= this.BatchClassElementColl[1];
					return this.oBatchClassElement;
				}
				catch (Exception)
				{
					return null;
				}
			}
			set
			{
				this.oBatchClassElement = value;
			}
		}

		[CLSCompliant(false)]
		public IACDataElement FoldersElement
		{
			get
			{
				try
				{
					this.oFoldersElement ??= this.BatchElement.FindChildElementByName("Folders");
					return this.oFoldersElement;
				}
				catch (Exception)
				{
					return null;
				}
			}
			set
			{
				this.oFoldersElement = value;
			}
		}

		[CLSCompliant(false)]
		public IACDataElementCollection FoldersCollection
		{
			get
			{
				try
				{
					this.oFoldersCollection ??= this.FoldersElement.FindChildElementsByName("Folder");
					return this.oFoldersCollection;
				}
				catch (Exception)
				{
					return null;
				}
			}
			set
			{
				this.oFoldersCollection = value;
			}
		}

		[CLSCompliant(false)]
		public IACDataElement FolderDocumentsElement
		{
			get
			{
				return this.oFolderDocumentsElement;
			}
		}

		[CLSCompliant(false)]
		public IACDataElement DocumentsElement
		{
			get
			{
				try
				{
					this.oDocumentsElement ??= this.BatchElement.FindChildElementByName("Documents");
					return this.oDocumentsElement;
				}
				catch (Exception)
				{
					return null;
				}
			}
			set
			{
				this.oDocumentsElement = value;
			}
		}

		[CLSCompliant(false)]
		public IACDataElementCollection DocumentsCollection
		{
			get
			{
				try
				{
					this.oDocumentsCollection ??= this.DocumentsElement.FindChildElementsByName("Document");
					return this.oDocumentsCollection;
				}
				catch (Exception)
				{
					return null;
				}
			}
			set
			{
				this.oDocumentsCollection = value;
			}
		}


		public string NextState
		{
			get
			{
				string s = this.oNextState.Name;
				return s;
			}
		}

		public IDictionary<string, string> GlobalVars
		{
			get
			{
				return this.oGlobalVars;
			}
			set
			{
				this.oGlobalVars = value;
			}
		}

		//[CLSCompliant(false)]
		public bool extract_FolderDocumentsElement(int index)
		{
			//int i = 0;
			if ((index > 0) && (this.FoldersCollection.Count > 0) && (index <= this.FoldersCollection.Count))
			{

				if (this.oFolderDocumentsElement != null)
				{
					if (Marshal.IsComObject(this.oFolderDocumentsElement))
						Marshal.ReleaseComObject(this.oFolderDocumentsElement);
				}

				this.oFolderDocumentsElement = this.FoldersCollection[index].FindChildElementByName("Documents");

				/*				foreach(ACDataElement f in this.FoldersCollection )
				{
					++i;
					if (i == index)
					{
						if (this.oFolderDocumentsElement != null)
						{
							Marshal.ReleaseComObject(this.oFolderDocumentsElement);
						}
						
						this.oFolderDocumentsElement = f.FindChildElementByName("Documents");
					}
				}*/
			}
			return false;
		}

		[CLSCompliant(false)] // because ref is not compliant
		public KfxWfVars(ref IACWorkflowData objWorkflowData)
		{
			this.cleanup();

			this.oWorkflowData = objWorkflowData;
			this.oNextState = objWorkflowData.NextState;
			this.oGlobalVars = new Dictionary<string, string>();
		}

		public void cleanup()
		{
			// workflow data object
			this.oWorkflowData = null;

			// root elements
			this.oRootSetupElement = null;
			this.oRuntimeRootElement = null;

			// batch elements
			this.oBatchElement = null;
			this.oBatchClassesElement = null;
			this.oBatchClassElementColl = null;
			this.oBatchClassElement = null;

			// folder elements
			this.oFoldersElement = null;
			this.oFoldersCollection = null;
			this.oFolderElement = null;

			// folder documents elements
			this.oFolderDocumentsElement = null;
			this.oFolderDocumentsCollection = null;

			// folders indexes

			// folders documents indexes

			// documents elements
			this.oDocumentsElement = null;
			this.oDocumentsCollection = null;
			//this.oDocumentElement = null;

			// indexes elements
			this.oIndexFieldsElement = null;
			this.oIndexFieldsCollection = null;
			//this.oIndexField = null;

			this.oNextState = null;

			this.oGlobalVars = null;
		}

		public void Dispose()
		{
			try
			{
				if (this.oGlobalVars != null)
				{
					this.oGlobalVars.Clear();
					this.oGlobalVars = null;
				}

				//if (this.oNextState != null)
				//{
				//                if (Marshal.IsComObject(this.oNextState))
				//                    Marshal.ReleaseComObject(this.oNextState);
				//}
				////if (this.oIndexField != null)
				////{
				////	Marshal.ReleaseComObject(this.oIndexField);
				////}

				//if (this.oIndexFieldsCollection != null)
				//{
				//                if (Marshal.IsComObject(this.oIndexFieldsCollection))
				//                    Marshal.ReleaseComObject(this.oIndexFieldsCollection);
				//}

				//if (this.oIndexFieldsElement != null)
				//{
				//                if (Marshal.IsComObject(this.oIndexFieldsElement))
				//                    Marshal.ReleaseComObject(this.oIndexFieldsElement);
				//}

				////if (this.oDocumentElement != null)
				////{
				////	Marshal.ReleaseComObject(this.oDocumentElement);
				////}

				//if (this.oDocumentsCollection != null)
				//{
				//                if (Marshal.IsComObject(this.oDocumentsCollection))
				//                    Marshal.ReleaseComObject(this.oDocumentsCollection);
				//}

				//if (this.oDocumentsElement != null)
				//{
				//                if (Marshal.IsComObject(this.oDocumentsElement))
				//                    Marshal.ReleaseComObject(this.oDocumentsElement);
				//}

				//if (this.oFolderDocumentsElement != null)
				//{
				//                if (Marshal.IsComObject(this.oFolderDocumentsElement))
				//                    Marshal.ReleaseComObject(this.oFolderDocumentsElement);
				//}

				//if (this.oFolderDocumentsCollection != null)
				//{
				//	Marshal.ReleaseComObject(this.oFolderDocumentsCollection);
				//}

				//if (this.oFolderElement != null)
				//{
				//	Marshal.ReleaseComObject(this.oFolderElement);
				//}

				//if (this.oFoldersCollection != null)
				//{
				//	Marshal.ReleaseComObject(this.oFoldersCollection);
				//}

				//if (this.oFoldersElement != null)
				//{
				//	Marshal.ReleaseComObject(this.oFoldersElement);
				//}

				//if (this.oBatchClassElementColl != null)
				//{
				//	Marshal.ReleaseComObject(this.oBatchClassElementColl);
				//}

				//if (this.oBatchClassElement != null)
				//{
				//	Marshal.ReleaseComObject(this.oBatchClassElement);
				//}

				//if (this.oBatchElement != null)
				//{
				//	Marshal.ReleaseComObject(this.oBatchElement);
				//}

				//if (this.oRuntimeRootElement != null)
				//{
				//	Marshal.ReleaseComObject(this.oRuntimeRootElement);
				//}

				//if (this.oRootSetupElement != null)
				//{
				//	Marshal.ReleaseComObject(this.oRootSetupElement);
				//}
			}
			finally
			{
				this.cleanup();
			}
			GC.WaitForPendingFinalizers();
			GC.Collect(GC.MaxGeneration, GCCollectionMode.Forced);
		}
	}
}
