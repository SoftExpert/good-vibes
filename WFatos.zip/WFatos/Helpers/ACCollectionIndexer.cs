﻿using Kofax.Capture.SDK.Data;
using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;

namespace Galian
{

	public class ACCollectionIndexer : IDisposable
	{
		//List<ACDataElement> _internalList = new List<ACDataElement> ();
		IACDataElementCollection _internalCollection = null;
		Dictionary<string, int> _internalDictionary = new Dictionary<string, int>();

		[CLSCompliant(false)]
		public IACDataElement this[string propName]
		{
			get
			{
				if (_internalDictionary.ContainsKey(propName))
				{
					return _internalCollection[_internalDictionary[propName]];
				}
				return null;
			}
		}

		[CLSCompliant(false)]
		public ACCollectionIndexer(ref IACDataElementCollection coll)
		{
			this._internalCollection = coll;
			int i = 1;
			foreach (IACDataElement element in this._internalCollection)
			{
				_internalDictionary.Add(element["Name"], i++);
			}
		}

		[CLSCompliant(false)]
		public ACCollectionIndexer(IACDataElement oDataElem, string collName, string collElementName)
		{
			IACDataElement colElem = oDataElem.FindChildElementByName(collName);
			try
			{
				if (colElem != null)
				{
					this._internalCollection = colElem.FindChildElementsByName(collElementName);
				}

				int i = 1;
				foreach (IACDataElement element in this._internalCollection)
				{
					_internalDictionary.Add(element["Name"], i++);
				}
			}
			catch (Exception)
			{

			}
			finally
			{
				if (colElem != null)
				{
					if (Marshal.IsComObject(colElem))
						Marshal.ReleaseComObject(colElem);
				}
			}
		}

		public void Dispose()
		{
			if (_internalDictionary != null)
			{
				_internalDictionary.Clear();
			}
			if (_internalCollection != null)
			{
				if (Marshal.IsComObject(_internalCollection))
				{
					Marshal.ReleaseComObject(_internalCollection);
				}
				_internalCollection = null;
			}
		}

		public bool Contains(string propName)
		{
			return _internalDictionary.ContainsKey(propName);
		}

	}

}
