﻿Imports Kofax.Capture.SDK.CustomModule
Imports Kofax.Capture.SDK.Data
Imports Separate.OutilsKC
Imports Newtonsoft.Json
Imports System.Diagnostics.Eventing
Imports System.Configuration
Imports System.IO
Imports System.Collections.Generic
Imports System.Globalization

Public Class AgricaJsonBuilder
    Implements IDisposable

    Private debugGUID As New Guid("A962E4F2-CFB7-4647-A486-EA2BBBD63E8E")
    Private dbgEP As EventProvider

    Private Env As String ' DEV, QLF, REC
    Private JsonRootPath As String

    Public Sub New()
        dbgEP = New EventProvider(debugGUID)
        Env = ConfigurationManager.AppSettings.Item("PlateformeKC").ToUpperInvariant()
        If Len(Env) > 0 Then
            Env += "_"
        Else
            Env = String.Empty
        End If
        JsonRootPath = ConfigurationManager.AppSettings.Item("RepertoireSortieJson")
    End Sub

    Public Sub Dispose() Implements IDisposable.Dispose
        If dbgEP IsNot Nothing Then
            dbgEP.Dispose()
        End If
        dbgEP = Nothing
    End Sub

    Public Function BuildJsonFromBatch(ByVal oBatchFieldsCollection As IACDataElementCollection, ByVal oFDocumentsCollection As IACDataElementCollection) As String
        Dim sJsonData As String = String.Empty
        Dim batchIndexes As New ACCollectionIndexer(oBatchFieldsCollection)
        Dim jsonObj As New WSRootObject
        Dim crtDoc As IACDataElement

        Try
            jsonObj.DevisCreateur = "undefined"
            jsonObj.DevisNumero = $"{Env}KF_" '... a continuer

            FillDefaultValues(jsonObj)

            For Each crtDoc In oFDocumentsCollection
                ProcessDocument(jsonObj, crtDoc)
            Next

            sJsonData = JsonConvert.SerializeObject(jsonObj, Formatting.Indented) ' produit la chaîne JSON qui sera passée au service Web

            SaveJsonToFile(JsonRootPath, sJsonData)

            dbgEP.WriteMessageEvent($"AgricaJsonBuilder.BuildJsonFromBatch: {Environment.NewLine}{sJsonData}")
        Catch ex As Exception
            dbgEP.WriteMessageEvent($"AgricaJsonBuilder.BuildJsonFromBatch exception: {ex.Message} {ex.StackTrace} {ex.Source}")
        Finally
            If batchIndexes IsNot Nothing Then
                batchIndexes.Dispose()
            End If
        End Try
        Return sJsonData
    End Function

    Private Sub FillDefaultValues(ByRef jsonObj As WSRootObject)
        ' valeurs constantes
        jsonObj.DevisDelegataire = "AGRICA"

        jsonObj.DevisDateExtraction = $"{DateTime.UtcNow:yyyy-MM-ddTHH:mm:ss.fff}Z"
        jsonObj.DevisDateCreation = $"{DateTime.UtcNow:yyyy-MM-ddTHH:mm:ss.fff}Z"


        jsonObj.DetailPropCom.ProduitCodeNiv1Gestionnaire = "PERCPCEANC"
        jsonObj.DetailPropCom.ProduitCodeNiv2Gestionnaire = {"TXCONV", "TXSUP"}

        jsonObj.DetailPropCom.ProduitCodeSouscritNiv1 = "PERCPCEANC"
        jsonObj.DetailPropCom.ProduitCodeSouscritNiv2 = {"TXCONV", "TXSUP"}

        ' MPO - 20220324 - cf mail Marc Divo
        'jsonObj.DetailPropCom.DetailProduit.Add(New Detailproduit With {
        '    .DetailProduitCodeSouscritNiv2 = "TXCONV",
        '    .SecteurActiviteCode = "SECT_ETARF",
        '    .TauxTA = "01.00",
        '    .TauxTB = "01.00",
        '    .TauxTC = "01.00",
        '    .SpecialisationCPCEACode = "19",
        '    .Garantie = "Taux conventionnel avec supplément de taux",
        '    .GarantieCode = "TXCONV,TXSUP"
        '})

        'jsonObj.DetailPropCom.DetailProduit.Add(New Detailproduit With {
        '    .DetailProduitCodeSouscritNiv2 = "TXSUP",
        '    .SecteurActiviteCode = "SECT_ETARF",
        '    .TauxTA = "00.10",
        '    .TauxTB = "00.10",
        '    .TauxTC = "00.10",
        '    .SpecialisationCPCEACode = "19",
        '    .Garantie = "Taux conventionnel avec supplément de taux",
        '    .GarantieCode = "TXCONV,TXSUP"
        '})

        jsonObj.DetailPropCom.DetailProduit.Add(New Detailproduit With {
            .DetailProduitCodeSouscritNiv2 = "TXCONV",
            .SecteurActiviteCode = "SECT_PAYS",
            .TauxTA = "01.00",
            .TauxTB = "01.00",
            .TauxTC = "01.00",
            .SpecialisationCPCEACode = "82",
            .Garantie = "Taux conventionnel (1% en TA/TB/TC)",
            .GarantieCode = "TXCONV"
        })

        ' MPO - 20220324 - cf mail Marc Divo
        jsonObj.DetailPropCom.ProvenanceDevis = New Provenancedevis With {
            .CodeCanalSource = "NUM",
            .LibelleCanalSource = "Chaîne de numérisation"
        }

        jsonObj.DetailPropCom.EligibiliteVerifiee = True
        jsonObj.DetailPropCom.Confidentiel = False

        jsonObj.NomDistributeur = "Groupe AGRICA"
        jsonObj.NomDistributeurCode = "0"
        jsonObj.NomCaisseregionale = ""
        jsonObj.ProduitNom = "Plan d'Epargne Retraite CPCEA Non Cadre"
        jsonObj.ProduitInstitution = "CPCEA"
        jsonObj.ProduitRisque = "Epargne Retraite"
        jsonObj.ProduitType = "Collective"

        jsonObj.EntrepriseProsp = New Entrepriseprospecte With {
            .Pays = "France",
            .Siret = "79210513200015",
            .Matricule = "000600925",
            .RaisonSociale = "123 PAYSAGE DERRIEN",
            .CodeNaf = "8130Z",
            .JuridiqueForme = "Société par actions simplifiée",
            .Adresse = "4 bis route de la Seigneurie",
            .ComplementAdresse = "",
            .PostalCode = "60260",
            .Ville = "LAMORLAYE",
            .SiretRattaches = {},
            .NatureJuridique = "",
            .DateCreation = ""
        }

        jsonObj.LegalRep = New Legalrepresentant With {
            .Civilite = "",
            .Email = "",
            .Fonction = "",
            .Nom = "",
            .Prenom = "",
            .Telephone = "",
            .TelephonePortable = ""
        }

    End Sub

    Private Sub ProcessDocument(ByRef jsonObj As WSRootObject, doc As IACDataElement)
        Try
            ' doc.AttributeValue("")
            Using docIndexes As New ACCollectionIndexer(doc, "IndexFields", "IndexField")

                Select Case doc.AttributeValue("FormTypeName")
                    Case "PER CPCEA1" 'master document

                        '                        jsonObj.DevisNumero = $"{Env}KF_" + docIndexes("DevisNumero")("Value")
                        jsonObj.DevisNumero = docIndexes("DevisNumero")("Value")
                        jsonObj.DevisDateEffetContrat = ReFormatDateValue(docIndexes("DateEffet")("Value"))

                    Case Else

                End Select



                If String.IsNullOrEmpty(jsonObj.EntrepriseProsp.Siret) Then
                    If Not String.IsNullOrEmpty(docIndexes("Siret")("Value")) Then
                        jsonObj.EntrepriseProsp.Siret = docIndexes("Siret")("Value")
                    End If
                End If
                If String.IsNullOrEmpty(jsonObj.EntrepriseProsp.Matricule) Then
                    If Not String.IsNullOrEmpty(docIndexes("Tag_MA")("Value")) Then
                        jsonObj.EntrepriseProsp.Matricule = docIndexes("Tag_MA")("Value")
                    End If
                End If
                If String.IsNullOrEmpty(jsonObj.EntrepriseProsp.RaisonSociale) Then
                    If Not String.IsNullOrEmpty(docIndexes("Raison_Sociale")("Value")) Then
                        jsonObj.EntrepriseProsp.RaisonSociale = docIndexes("Raison_Sociale")("Value")
                    End If
                End If
                If String.IsNullOrEmpty(jsonObj.EntrepriseProsp.PostalCode) Then
                    If Not String.IsNullOrEmpty(docIndexes("CodePostalCPCEA")("Value")) Then
                        jsonObj.EntrepriseProsp.PostalCode = docIndexes("CodePostalCPCEA")("Value")
                    End If
                End If

                If String.IsNullOrEmpty(jsonObj.LegalRep.Nom) Then
                    If Not String.IsNullOrEmpty(docIndexes("Nom")("Value")) Then
                        jsonObj.LegalRep.Nom = docIndexes("Nom")("Value")
                    End If
                End If
                If String.IsNullOrEmpty(jsonObj.LegalRep.Prenom) Then
                    If Not String.IsNullOrEmpty(docIndexes("Prenom")("Value")) Then
                        jsonObj.LegalRep.Nom = docIndexes("Prenom")("Value")
                    End If
                End If

                If String.IsNullOrEmpty(jsonObj.EntrepriseRegl.Iban) Then
                    If Not String.IsNullOrEmpty(docIndexes("IBAN")("Value")) Then
                        jsonObj.EntrepriseRegl.Iban = docIndexes("IBAN")("Value")
                    End If
                End If
                If String.IsNullOrEmpty(jsonObj.EntrepriseRegl.Bic) Then
                    If Not String.IsNullOrEmpty(docIndexes("BIC")("Value")) Then
                        jsonObj.EntrepriseRegl.Bic = docIndexes("BIC")("Value")
                    End If
                End If
                If String.IsNullOrEmpty(jsonObj.EntrepriseRegl.Domiciliation) Then
                    If Not String.IsNullOrEmpty(docIndexes("Domiciliation")("Value")) Then
                        jsonObj.EntrepriseRegl.Domiciliation = docIndexes("Domiciliation")("Value")
                    End If
                End If


                Dim f As New Fichier With {
                            .Libelle = docIndexes("Fichier_Libelle")("Value"),
                            .Contenu = LoadFileAsBase64(doc.AttributeValue("PDFGenerationFileName")),
                            .Id = docIndexes("Fichier_Id")("Value"),
                            .Statut = docIndexes("Fichier_Statut")("Value"),
                            .Typologie = docIndexes("Fichier_Typologie")("Value")
                        }

                If doc.AttributeValue("FormTypeName") = "PER CPCEA1" Then
                    f.TryAddControle("CHK_EFFET", docIndexes("Fichier_Controles_CHK_EFFET")("Value"))
                    f.TryAddControle("CHK_SIGNE", docIndexes("Fichier_Controles_CHK_SIGNE")("Value"))
                    f.TryAddControle("CHK_SIRET", docIndexes("Fichier_Controles_CHK_SIRET")("Value"))
                End If
                If doc.AttributeValue("FormTypeName") = "IBAN_RIB" Then
                    f.TryAddControle("CHK_RIB_BIC_FORMAT", docIndexes("Fichier_Controles_CHK_RIB_BIC_FORMAT")("Value"))
                    f.TryAddControle("CHK_RIB_IBAN", docIndexes("Fichier_Controles_CHK_RIB_IBAN")("Value"))
                End If
                If doc.AttributeValue("FormTypeName") = "CNI" Or doc.AttributeValue("FormTypeName") = "Passeport" Or doc.AttributeValue("FormTypeName") = "Titre de séjour" Then
                    f.TryAddControle("CHK_ID_MRZ_EXPIRYDATE", docIndexes("Fichier_Controles_CHK_ID_MRZ_EXPIRYDATE")("Value"))
                    f.TryAddControle("CHK_ID_MRZ_MINIMUM_AGE", docIndexes("Fichier_Controles_CHK_ID_MINIMUM_AGE")("Value"))
                    f.TryAddControle("CHK_ID_MRZ_MODULO", docIndexes("Fichier_Controles_CHK_ID_MRZ_MODULO")("Value"))
                End If
                If doc.AttributeValue("FormTypeName") = "KBIS" Then
                    f.TryAddControle("Présence d’une date d’édition, au plus inférieure de 3 mois à la date du jour", docIndexes("Fichier_Controles_KBIS_DATE")("Value"))
                    f.TryAddControle("Présence numéro d'immatriculation", docIndexes("Fichier_Controles_KBIS_IMMAT")("Value"))
                    f.TryAddControle("[Contrôle Inter-pièces] CHK_INTER_FORM_CORPORATION_KBIS_REGISTRATION_NUMBER", docIndexes("Fichier_Controles_KBIS_INTERPIECES")("Value"))
                End If
                If doc.AttributeValue("FormTypeName") = "MandatSEPA" Then
                    f.TryAddControle("CHK_SEPA_IBAN", docIndexes("Fichier_Controles_CHK_SEPA_IBAN")("Value"))
                    f.TryAddControle("CHK_SEPA_BIC", docIndexes("Fichier_Controles_CHK_SEPA_BIC")("Value"))
                    f.TryAddControle("CHK_SEPA_SIGNE", docIndexes("Fichier_Controles_CHK_SEPA_SIGNE")("Value"))
                End If

                jsonObj.Fichiers.Add(f)
            End Using
        Catch ex As Exception
            dbgEP.WriteMessageEvent($"AgricaJsonBuilder.ProcessDocument exception: {ex.Message} {ex.StackTrace} {ex.Source}")
        Finally

        End Try

    End Sub

    Private Function SaveJsonToFile(rootFolder As String, sJson As String) As Boolean
        If String.IsNullOrWhiteSpace(rootFolder) Then
            Return False
        End If

        Try
            File.WriteAllText(Path.Combine(rootFolder, Guid.NewGuid().ToString() + "_" + DateTime.Now.ToString("yyyy_MM_dd_HH_mm_ss") + ".json"), sJson)
            Return True
        Catch ex As Exception
            dbgEP.WriteMessageEvent($"AgricaJsonBuilder.SaveJsonToFile exception: {ex.Message} {ex.StackTrace} {ex.Source}")
        End Try

        Return False
    End Function

    Private Function LoadFileAsBase64(fPath As String) As String
        Try
            If File.Exists(fPath) Then
                Using fs As System.IO.Stream = File.OpenRead(fPath)
                    Using br As New System.IO.BinaryReader(fs)
                        Dim bytes As Byte() = br.ReadBytes(CType(fs.Length, Integer))
                        Return Convert.ToBase64String(bytes, 0, bytes.Length, Base64FormattingOptions.None)
                    End Using
                End Using
            Else
                dbgEP.WriteMessageEvent($"AgricaJsonBuilder.LoadFileAsBase64 exception: file [{fPath}] be found")
            End If
        Catch ex As Exception
            dbgEP.WriteMessageEvent($"AgricaJsonBuilder.LoadFileAsBase64 exception: {ex.Message} {ex.StackTrace} {ex.Source}")
        End Try
        Return String.Empty
    End Function

    Private Function ReFormatDateValue(origValue As String, Optional origFormat As String = "dd/MM/yyyy|dd-MM-yyyy|dd.MM.yyyy") As String
        Dim d As Date
        Dim f() As String

        f = origFormat.Split("|".ToCharArray())
        If f.Length = 1 Then
            If DateTime.TryParseExact(origValue, origFormat, CultureInfo.InvariantCulture, DateTimeStyles.None, d) Then
                Return $"{d:yyyy-MM-dd}T00:00:00.000Z"
            End If
        Else
            If DateTime.TryParseExact(origValue, f, CultureInfo.InvariantCulture, DateTimeStyles.None, d) Then
                Return $"{d:yyyy-MM-dd}T00:00:00.000Z"
            End If
        End If

        Return String.Empty
    End Function


End Class
