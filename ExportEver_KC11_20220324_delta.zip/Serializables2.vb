﻿Imports System.Collections.Generic
Imports Newtonsoft.Json

Public Class WSRootObject
    <JsonProperty(PropertyName:="devisCreateur")> Public Property DevisCreateur As String = ""
    <JsonProperty(PropertyName:="devisNumero")> Public Property DevisNumero As String = ""
    <JsonProperty(PropertyName:="devisDelegataire")> Public Property DevisDelegataire As String = "AGRICA"
    <JsonProperty(PropertyName:="devisDateExtraction")> Public Property DevisDateExtraction As String = ""
    <JsonProperty(PropertyName:="devisDateCreation")> Public Property DevisDateCreation As String = ""
    <JsonProperty(PropertyName:="devisDateEffetContrat")> Public Property DevisDateEffetContrat As String = ""
    <JsonProperty(PropertyName:="detailPropositionCommerciale")> Public Property DetailPropCom As Detailpropositioncommerciale = New Detailpropositioncommerciale()
    <JsonProperty(PropertyName:="nomDistributeur")> Public Property NomDistributeur As String = "Groupe AGRICA"
    <JsonProperty(PropertyName:="nomDistributeurCode")> Public Property NomDistributeurCode As String = "0"
    <JsonProperty(PropertyName:="nomCaisseregionale")> Public Property NomCaisseregionale As String = ""
    <JsonProperty(PropertyName:="produitNom")> Public Property ProduitNom As String = "Plan d'Epargne Retraite CPCEA Non Cadre"
    <JsonProperty(PropertyName:="produitInstitution")> Public Property ProduitInstitution As String = "CPCEA"
    <JsonProperty(PropertyName:="produitRisque")> Public Property ProduitRisque As String = "Epargne Retraite"
    <JsonProperty(PropertyName:="produitType")> Public Property ProduitType As String = "Collective"
    <JsonProperty(PropertyName:="entrepriseProspecte")> Public Property EntrepriseProsp As Entrepriseprospecte = New Entrepriseprospecte()
    <JsonProperty(PropertyName:="legalRepresentant")> Public Property LegalRep As Legalrepresentant = New Legalrepresentant()
    <JsonProperty(PropertyName:="entrepriseReglement")> Public Property EntrepriseRegl As Entreprisereglement = New Entreprisereglement()
    <JsonProperty(PropertyName:="fichiers")> Public Property Fichiers As List(Of Fichier) = New List(Of Fichier)
End Class

Public Class Detailpropositioncommerciale
    <JsonProperty(PropertyName:="produitCodeNiv1Gestionnaire")> Public Property ProduitCodeNiv1Gestionnaire As String = "PERCPCEANC"
    <JsonProperty(PropertyName:="produitCodeNiv2Gestionnaire")> Public Property ProduitCodeNiv2Gestionnaire As String() = {}
    <JsonProperty(PropertyName:="produitCodeSouscritNiv1")> Public Property ProduitCodeSouscritNiv1 As String = "PERCPCEANC"
    <JsonProperty(PropertyName:="produitCodeSouscritNiv2")> Public Property ProduitCodeSouscritNiv2 As String() = {"TXCONV", "TXSUP"}
    <JsonProperty(PropertyName:="detailProduit")> Public Property DetailProduit As List(Of Detailproduit) = New List(Of Detailproduit)
    <JsonProperty(PropertyName:="provenanceDevis")> Public Property ProvenanceDevis As Provenancedevis
    <JsonProperty(PropertyName:="eligibiliteVerifiee")> Public Property EligibiliteVerifiee As Boolean = True
    <JsonProperty(PropertyName:="confidentiel")> Public Property Confidentiel As Boolean = False
End Class

Public Class Provenancedevis
    <JsonProperty(PropertyName:="codeCanalSource")> Public Property CodeCanalSource As String = "NUM"
    <JsonProperty(PropertyName:="libelleCanalSource")> Public Property LibelleCanalSource As String = "Chaîne de numérisation"
End Class

Public Class Detailproduit
    <JsonProperty(PropertyName:="detailProduitCodeSouscritNiv2")> Public Property DetailProduitCodeSouscritNiv2 As String = ""
    <JsonProperty(PropertyName:="Secteur_Activite_Code")> Public Property SecteurActiviteCode As String = ""
    <JsonProperty(PropertyName:="Taux_TA")> Public Property TauxTA As String = ""
    <JsonProperty(PropertyName:="Taux_TB")> Public Property TauxTB As String = ""
    <JsonProperty(PropertyName:="Taux_TC")> Public Property TauxTC As String = ""
    <JsonProperty(PropertyName:="Specialisation_CPCEA_Code")> Public Property SpecialisationCPCEACode As String = ""
    <JsonProperty(PropertyName:="Garantie")> Public Property Garantie As String = ""
    <JsonProperty(PropertyName:="Garantie_Code")> Public Property GarantieCode As String = ""
End Class

Public Class Entrepriseprospecte
    <JsonProperty(PropertyName:="siret")> Public Property Siret As String = ""
    <JsonProperty(PropertyName:="matricule")> Public Property Matricule As String = ""
    <JsonProperty(PropertyName:="raisonSociale")> Public Property RaisonSociale As String = ""
    <JsonProperty(PropertyName:="codeNaf")> Public Property CodeNaf As String = ""
    <JsonProperty(PropertyName:="juridiqueForme")> Public Property JuridiqueForme As String = ""
    <JsonProperty(PropertyName:="adresse")> Public Property Adresse As String = ""
    <JsonProperty(PropertyName:="complementAdresse")> Public Property ComplementAdresse As String = ""
    <JsonProperty(PropertyName:="postalCode")> Public Property PostalCode As String = ""
    <JsonProperty(PropertyName:="ville")> Public Property Ville As String = ""
    <JsonProperty(PropertyName:="pays")> Public Property Pays As String = ""
    <JsonProperty(PropertyName:="SiretRattaches")> Public Property SiretRattaches As String()
    <JsonProperty(PropertyName:="natureJuridique")> Public Property NatureJuridique As String = ""
    <JsonProperty(PropertyName:="dateCreation")> Public Property DateCreation As String = ""
End Class

Public Class Legalrepresentant
    <JsonProperty(PropertyName:="civilite")> Public Property Civilite As String = ""
    <JsonProperty(PropertyName:="fonction")> Public Property Fonction As String = ""
    <JsonProperty(PropertyName:="nom")> Public Property Nom As String = ""
    <JsonProperty(PropertyName:="prenom")> Public Property Prenom As String = ""
    <JsonProperty(PropertyName:="email")> Public Property Email As String = ""
    <JsonProperty(PropertyName:="telephone")> Public Property Telephone As String = ""
    <JsonProperty(PropertyName:="telephonePortable")> Public Property TelephonePortable As String = ""
End Class

Public Class Entreprisereglement
    <JsonProperty(PropertyName:="IBAN")> Public Property Iban As String = ""
    <JsonProperty(PropertyName:="BIC")> Public Property Bic As String = ""
    <JsonProperty(PropertyName:="domiciliation")> Public Property Domiciliation As String = ""
End Class

Public Class Fichier
    <JsonProperty(PropertyName:="libelle")> Public Property Libelle As String = ""
    <JsonProperty(PropertyName:="contenu")> Public Property Contenu As String = ""
    <JsonProperty(PropertyName:="typologie")> Public Property Typologie As String = ""
    <JsonProperty(PropertyName:="id")> Public Property Id As String = ""
    <JsonProperty(PropertyName:="statut")> Public Property Statut As String = ""
    <JsonProperty(PropertyName:="controles")> Public Property Controles As List(Of BusinessRule) = New List(Of BusinessRule)

    Public Sub TryAddControle(k As String, v As String)
        If Not String.IsNullOrEmpty(v) Then
            Controles.Add(New BusinessRule With {.Libelle = k, .Statut = v})
        End If
    End Sub
End Class

Public Class BusinessRule
    <JsonProperty(PropertyName:="libelle")> Public Property Libelle As String = ""
    <JsonProperty(PropertyName:="statut")> Public Property Statut As String = ""
End Class
