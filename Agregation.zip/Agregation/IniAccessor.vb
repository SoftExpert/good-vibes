﻿Imports System.Runtime.InteropServices
Imports System.Text
Module IniAccessor
    Private Declare Auto Function GetPrivateProfileString Lib "kernel32" (ByVal lpAppName As String,
            ByVal lpKeyName As String,
            ByVal lpDefault As String,
            ByVal lpReturnedString As StringBuilder,
            ByVal nSize As Integer,
            ByVal lpFileName As String) As Integer

    Function GetIniString(ByVal Section As String, ByVal Item As String, ByVal File As String) As String
        Dim res As Integer
        Dim sb As StringBuilder

        sb = New StringBuilder(500)
        res = GetPrivateProfileString(Section, Item, "", sb, sb.Capacity, File)
        Return res.ToString()
    End Function
End Module