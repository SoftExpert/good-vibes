Imports System.Reflection
Imports System.Runtime.CompilerServices
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.


' TODO: Review the values of the assembly attributes


<Assembly: AssemblyTitle("Ascent Capture Sample Separation Custom Module")>
<Assembly: AssemblyDescription("")>
<Assembly: AssemblyCompany("Kofax, Inc.")>
<Assembly: AssemblyProduct("Kofax Capture")>
<Assembly: AssemblyCopyright("Copyright © 2021 Kofax. All rights reserved.")>
<Assembly: AssemblyTrademark("")> 
<Assembly: AssemblyCulture("")>

' Version information for an assembly consists of the following four values:

'	Major version
'	Minor Version
'	Build Number
'	Revision

' You can specify all the values or you can default the Build and Revision Numbers
' by using the '*' as shown below:

<Assembly: AssemblyVersion("1.0.0.0")>
<Assembly: AssemblyFileVersion("11.1.0.0")>

