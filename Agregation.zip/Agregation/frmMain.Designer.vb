<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> Partial Class frmMain
#Region "Windows Form Designer generated code "

	'Form overrides dispose to clean up the component list.
	<System.Diagnostics.DebuggerNonUserCode()> Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
		If Disposing Then
			If Not components Is Nothing Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(Disposing)
	End Sub
	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer
	Public ToolTip1 As System.Windows.Forms.ToolTip
	Public WithEvents tmrMainTimer As System.Windows.Forms.Timer
	Public WithEvents lblPage As System.Windows.Forms.Label
	Public WithEvents lblLoosePage As System.Windows.Forms.Label
	Public WithEvents lblBatchname As System.Windows.Forms.Label
	Public WithEvents lblBatch As System.Windows.Forms.Label
	Public WithEvents frmStatus As System.Windows.Forms.GroupBox
	Public WithEvents lblFeature As System.Windows.Forms.Label
	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.
	'Do not modify it using the code editor.
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmMain))
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.tmrMainTimer = New System.Windows.Forms.Timer(Me.components)
        Me.frmStatus = New System.Windows.Forms.GroupBox()
        Me.lblDocOfsDocs = New System.Windows.Forms.Label()
        Me.lblDocument = New System.Windows.Forms.Label()
        Me.lblPage = New System.Windows.Forms.Label()
        Me.lblLoosePage = New System.Windows.Forms.Label()
        Me.lblBatchname = New System.Windows.Forms.Label()
        Me.lblBatch = New System.Windows.Forms.Label()
        Me.lblFeature = New System.Windows.Forms.Label()
        Me.frmStatus.SuspendLayout()
        Me.SuspendLayout()
        '
        'tmrMainTimer
        '
        Me.tmrMainTimer.Interval = 5000
        '
        'frmStatus
        '
        resources.ApplyResources(Me.frmStatus, "frmStatus")
        Me.frmStatus.BackColor = System.Drawing.SystemColors.Control
        Me.frmStatus.Controls.Add(Me.lblDocOfsDocs)
        Me.frmStatus.Controls.Add(Me.lblDocument)
        Me.frmStatus.Controls.Add(Me.lblPage)
        Me.frmStatus.Controls.Add(Me.lblLoosePage)
        Me.frmStatus.Controls.Add(Me.lblBatchname)
        Me.frmStatus.Controls.Add(Me.lblBatch)
        Me.frmStatus.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.frmStatus.ForeColor = System.Drawing.SystemColors.ControlText
        Me.frmStatus.Name = "frmStatus"
        Me.frmStatus.TabStop = False
        '
        'lblDocOfsDocs
        '
        resources.ApplyResources(Me.lblDocOfsDocs, "lblDocOfsDocs")
        Me.lblDocOfsDocs.BackColor = System.Drawing.SystemColors.Control
        Me.lblDocOfsDocs.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblDocOfsDocs.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.lblDocOfsDocs.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblDocOfsDocs.Name = "lblDocOfsDocs"
        '
        'lblDocument
        '
        Me.lblDocument.BackColor = System.Drawing.SystemColors.Control
        Me.lblDocument.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblDocument.FlatStyle = System.Windows.Forms.FlatStyle.System
        resources.ApplyResources(Me.lblDocument, "lblDocument")
        Me.lblDocument.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblDocument.Name = "lblDocument"
        '
        'lblPage
        '
        resources.ApplyResources(Me.lblPage, "lblPage")
        Me.lblPage.BackColor = System.Drawing.SystemColors.Control
        Me.lblPage.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblPage.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.lblPage.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblPage.Name = "lblPage"
        '
        'lblLoosePage
        '
        Me.lblLoosePage.BackColor = System.Drawing.SystemColors.Control
        Me.lblLoosePage.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblLoosePage.FlatStyle = System.Windows.Forms.FlatStyle.System
        resources.ApplyResources(Me.lblLoosePage, "lblLoosePage")
        Me.lblLoosePage.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblLoosePage.Name = "lblLoosePage"
        '
        'lblBatchname
        '
        resources.ApplyResources(Me.lblBatchname, "lblBatchname")
        Me.lblBatchname.BackColor = System.Drawing.SystemColors.Control
        Me.lblBatchname.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblBatchname.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.lblBatchname.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblBatchname.Name = "lblBatchname"
        '
        'lblBatch
        '
        Me.lblBatch.BackColor = System.Drawing.SystemColors.Control
        Me.lblBatch.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblBatch.FlatStyle = System.Windows.Forms.FlatStyle.System
        resources.ApplyResources(Me.lblBatch, "lblBatch")
        Me.lblBatch.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblBatch.Name = "lblBatch"
        '
        'lblFeature
        '
        resources.ApplyResources(Me.lblFeature, "lblFeature")
        Me.lblFeature.BackColor = System.Drawing.SystemColors.Control
        Me.lblFeature.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblFeature.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.lblFeature.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblFeature.Name = "lblFeature"
        '
        'frmMain
        '
        resources.ApplyResources(Me, "$this")
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.Controls.Add(Me.frmStatus)
        Me.Controls.Add(Me.lblFeature)
        Me.Cursor = System.Windows.Forms.Cursors.Default
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmMain"
        Me.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Show
        Me.frmStatus.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Public WithEvents lblDocOfsDocs As System.Windows.Forms.Label
    Public WithEvents lblDocument As System.Windows.Forms.Label
#End Region 
End Class