'********************************************************************************
'***
'*** Module:    BatchSel.frm - frmBatchSelect
'*** Purpose:   Form used to display and select a batch.
'***
'*** (c) Copyright 2000-2013 Kofax Image Products.
'*** All rights reserved.
'***
'********************************************************************************
Imports System.Runtime.InteropServices
Imports VB = Microsoft.VisualBasic
Imports Kofax.Capture.SDK.CustomModule

Friend Class frmBatchSelect
	Inherits System.Windows.Forms.Form
    '*** Class members
	Private m_oProcessColl As IProcessCollection	'*** Collection of processes
    '*** Used to display names
	Private m_oBatchColl As IBatchCollection	'*** Collection of batches displayed
	Private m_oSelectedBatch As IBatch '*** Selected batch (read-only)
	
	'**************************************************************************
	'*** Property:  BatchCollection
	'*** Purpose:   Collection of batches used to fill the list.
	'**************************************************************************
	Public WriteOnly Property BatchCollection() As IBatchCollection
		Set(ByVal Value As IBatchCollection)
			Dim oBatch As IBatch
			Dim oItem As System.Windows.Forms.ListViewItem
			Dim lIndex As Integer

			'*** Set the member variable
			m_oBatchColl = Value

			'*** Update the list with the current batch collection
			lstBatches.Items.Clear()
			For lIndex = 1 To m_oBatchColl.Count
				oBatch = m_oBatchColl(lIndex)
				oItem = lstBatches.Items.Add(oBatch.Name, lIndex)
				'            oItem.Tag = CStr(lIndex) '*** Index into m_oBatchColl.
				''*** Used to retrieve the selected batch.
				'oItem.Text = oBatch.Name
				If oItem.SubItems.Count > 0 Then
					oItem.SubItems(0).Text = oBatch.BatchClassName
				Else
					oItem.SubItems.Insert(0, New System.Windows.Forms.ListViewItem.ListViewSubItem(Nothing, oBatch.BatchClassName))
				End If
				If oItem.SubItems.Count > 1 Then
					oItem.SubItems(1).Text = oBatch.CreateDate
				Else
					oItem.SubItems.Insert(1, New System.Windows.Forms.ListViewItem.ListViewSubItem(Nothing, oBatch.CreateDate))
				End If
				If oItem.SubItems.Count > 2 Then
					oItem.SubItems(2).Text = get_StateString(oBatch.State)
				Else
					oItem.SubItems.Insert(2, New System.Windows.Forms.ListViewItem.ListViewSubItem(Nothing, get_StateString(oBatch.State)))
				End If
				If oItem.SubItems.Count > 3 Then
					oItem.SubItems(4).Text = VB.Right(" " & oBatch.Priority, 2)
				Else
					oItem.SubItems.Insert(3, New System.Windows.Forms.ListViewItem.ListViewSubItem(Nothing, VB.Right(" " & oBatch.Priority, 2)))
				End If
				If oItem.SubItems.Count > 4 Then
					oItem.SubItems(5).Text = get_ProcessString(oBatch.ProcessID)
				Else
					oItem.SubItems.Insert(4, New System.Windows.Forms.ListViewItem.ListViewSubItem(Nothing, get_ProcessString(oBatch.ProcessID)))
				End If
				If oItem.SubItems.Count > 5 Then
					oItem.SubItems(6).Text = oBatch.StationID
				Else
					oItem.SubItems.Insert(5, New System.Windows.Forms.ListViewItem.ListViewSubItem(Nothing, oBatch.StationID))
				End If
				If oItem.SubItems.Count > 6 Then
					oItem.SubItems(7).Text = VB.Right("            " & oBatch.ExternalBatchID, 12)
				Else
					oItem.SubItems.Insert(6, New System.Windows.Forms.ListViewItem.ListViewSubItem(Nothing, VB.Right("            " & oBatch.ExternalBatchID, 12)))
				End If

				'*** Set the selection to the first item
				If lstBatches.Items.Count = 1 Then
					oItem.Selected = True
				End If
			Next
		End Set
	End Property

	'**************************************************************************
	'*** Property:  ProcessCollection
	'*** Purpose:   Process list. Used to determine process names
	'**************************************************************************
	Public WriteOnly Property ProcessCollection() As IProcessCollection
		Set(ByVal Value As IProcessCollection)
			m_oProcessColl = Value
		End Set
	End Property

	'**************************************************************************
	'*** Property:  Batch
	'*** Purpose:   Selected batch
	'**************************************************************************
	Public ReadOnly Property Batch() As IBatch
		Get
			Return m_oSelectedBatch
		End Get
	End Property

	'**************************************************************************
	'*** Function:  btnCancel_Click
	'*** Purpose:   Hides the dialog
	'*** Inputs:    None
	'*** Outputs:    None
	'**************************************************************************
	Private Sub btnCancel_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles btnCancel.Click
		'*** No batch was selected
		m_oSelectedBatch = Nothing
		Hide()
	End Sub

	'**************************************************************************
	'*** Function:  btnOK_Click
	'*** Purpose:   Sets the selected batch member and hides the dialog
	'*** Inputs:    None
	'*** Outputs:    None
	'**************************************************************************
	Private Sub btnOK_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles btnOK.Click
		If lstBatches.FocusedItem Is Nothing Then
			MsgBox("No selected batch", MsgBoxStyle.OKOnly, "Batch Open")
			Exit Sub
		End If

		m_oSelectedBatch = m_oBatchColl(lstBatches.FocusedItem.Tag)
		Hide()
	End Sub

	'**************************************************************************
	'*** Function:  OnLoad
	'*** Purpose:   Ensures that the batch collection has been set before
	'***            the form is loaded.
	'*** Inputs:    None
	'*** Outputs:    None
	'**************************************************************************
	Protected Overrides Sub OnLoad(ByVal e As System.EventArgs)
		MyBase.OnLoad(e)

		If m_oBatchColl Is Nothing Then
			MsgBox("Please specify BatchCollection before loading this form.")
		End If

		'*** Initialize the list control
		Dim collHeaders As System.Windows.Forms.ListView.ColumnHeaderCollection

		'*** Add the column headers. Include a width scale.
		collHeaders = lstBatches.Columns
		collHeaders.Clear()
		collHeaders.Add("Name")
		collHeaders.Add("Class")
		collHeaders.Add("Date")
		collHeaders.Add("Status")
		collHeaders.Add("Queue")
		collHeaders.Add("StationID")
		lstBatches.HeaderStyle = ColumnHeaderStyle.None
	End Sub

	'**************************************************************************
	'*** Function:  lstBatches_ColumnClick
	'*** Purpose:   Implement sorting based on column clicked
	'*** Inputs:    oHeader - A reference to the ColumnHeader object that
	'***                      was clicked
	'*** Outputs:    None
	'**************************************************************************
	Private Sub lstBatches_ColumnClick(ByVal eventSender As System.Object, _
										ByVal eventArgs As System.Windows.Forms.ColumnClickEventArgs) Handles lstBatches.ColumnClick
		Dim oHeader As System.Windows.Forms.ColumnHeader = lstBatches.Columns(eventArgs.Column)

		' set the listviewItemSorter property to a new ListViewItemComparer
		' object. Setting this property immediately sorts the 
		' listView using the ListViewItemComparer object.
		Me.lstBatches.ListViewItemSorter = New ListViewItemComparer(eventArgs.Column)
	End Sub

	' Implements the manual sorting of items by columns.
	Class ListViewItemComparer
		Implements IComparer

		Private col As Integer

		Public Sub New()
			col = 0
		End Sub

		Public Sub New(ByVal column As Integer)
			col = column
		End Sub

		Public Function Compare(ByVal x As Object, ByVal y As Object) As Integer _
		   Implements IComparer.Compare
			Return [String].Compare(CType(x, ListViewItem).SubItems(col).Text, CType(y, ListViewItem).SubItems(col).Text)
		End Function
	End Class


	'**************************************************************************
	'*** Function:  get_ProcessString
	'*** Purpose:   Gets the process name from the ID
	'*** Inputs:    Process ID
	'*** Outputs:    Process name
	'**************************************************************************
	Private Function get_ProcessString(ByVal lProcess As Integer) As String
		Dim oProcess As IProcess

		For Each oProcess In m_oProcessColl
			If oProcess.ProcessID = lProcess Then
				Return oProcess.Name
			End If
		Next

		System.Diagnostics.Debug.Assert(False, "")
		Return "Unknown"
	End Function

	'**************************************************************************
	'*** Function:  get_StateString
	'*** Purpose:   Gets the state name from the enum
	'*** Inputs:    State enum value
	'*** Outputs:    State name
	'**************************************************************************
	Private Function get_StateString(ByVal lState As Integer) As String
		Select Case lState
			Case KfxDbState.KfxDbBatchReady
				Return "Ready"
			Case KfxDbState.KfxDbBatchInProgress
				Return "In Progress"
			Case KfxDbState.KfxDbBatchSuspended
				Return "Suspended"
			Case KfxDbState.KfxDbBatchError
				Return "Error"
			Case KfxDbState.KfxDbBatchCompleted
				Return "Completed"
			Case KfxDbState.KfxDbBatchReserved
				Return "Reserved"
			Case Else
				System.Diagnostics.Debug.Assert(False, "")
				Return "Unknown"
		End Select
	End Function

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
        If Disposing Then
            If Not components Is Nothing Then
                components.Dispose()
            End If

            If m_oProcessColl IsNot Nothing Then
				Using (m_oProcessColl)
				End Using
            End If

            If m_oBatchColl IsNot Nothing Then
				Using (m_oBatchColl)
				End Using
            End If

            If m_oSelectedBatch IsNot Nothing Then
				Using (m_oSelectedBatch)
				End Using
            End If
        End If
        MyBase.Dispose(Disposing)
    End Sub
End Class