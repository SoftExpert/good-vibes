﻿Imports System.Net.Sockets
Imports System.ServiceProcess
Imports System.Threading.Tasks
Imports System.Timers

Public Class WinService
    Inherits System.ServiceProcess.ServiceBase

    Public Shared ReadOnly SvcName As String = "AOI.Custom.Agregation"
    Public Shared ReadOnly SvcDisplay As String = "AOI.Custom.Agregation"
    Public Shared ReadOnly SvcDescription As String = "AOI.Custom.Agregation"
    Public Shared ReadOnly StartAfterInstall As Boolean = False

    Public Shared ReadOnly ModuleID As String = "AOI.Custom.Agregation"

    Private bm As BatchManager
    Private svcTimer As System.Timers.Timer
    Private stopRequested As Boolean = False

    Public Sub New()
        MyBase.New()
        InitializeComponent()
    End Sub

    Protected Overrides Sub OnStart(ByVal args() As String)
        Debug.WriteLine("OnStart ...")
        Try
            bm = New BatchManager(ModuleID)
            bm.LoginToRuntimeSession()

            svcTimer = New Timers.Timer With {
                .Interval = 5000,
                .Enabled = True
            }

            AddHandler svcTimer.Elapsed, AddressOf OnTimerFired
            stopRequested = False
            svcTimer.Start()

            Debug.WriteLine("OnStart ... started")
        Catch ex As Exception
            Debug.WriteLine("OnStart error: " & ex.Message)
        End Try
    End Sub

    Private Sub OnTimerFired(sender As Object, e As ElapsedEventArgs)
        svcTimer?.Stop()
        Debug.WriteLine("OnTimerFired ...")
        Try
            Try
                ' execute batch search and picking logic

                While Not stopRequested And bm.BatchOpenNext(BatchManager.bmProcessMode.bmProcessByBatch, False)
                    If bm.ActiveBatch IsNot Nothing Then
                        Debug.WriteLine($"Processing batch : ID={bm.ActiveBatch.BatchId}, CLASS={bm.ActiveBatch.BatchClassName}, NAME={bm.ActiveBatch.Name}")
                        Using bp As New Processor()
                            bp.Process(bm.ActiveBatch)
                        End Using

                    End If
                End While

            Catch ex As Exception
                Debug.WriteLine("OnTimerFired error: " & ex.Message)
            End Try
        Finally
            If svcTimer IsNot Nothing Then
                Debug.WriteLine("OnTimerFired ... done; timer started again")
                svcTimer?.Start()
            Else
                Debug.WriteLine("OnTimerFired ... done; timer was disabled")
            End If
        End Try
    End Sub

    Protected Overrides Sub OnStop()
        Debug.WriteLine("OnStop ...")
        stopRequested = True
        Try
            svcTimer.Stop()
            svcTimer.Dispose()

            Debug.WriteLine("OnStop ... stopped")
        Catch ex As Exception
            Debug.WriteLine("OnStop error: " & ex.Message)
        End Try
    End Sub

    '    Private Async Function RunAsync() As Task
    'DoWork()
    'Await NetworkStream.WriteAsync(Buffer, 0, Buffer.Length).ConfigureAwait(False)
    '   End Function

    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    <MTAThread()>
    <System.Diagnostics.DebuggerNonUserCode()>
    Shared Sub Main(args As String())
        Dim ServicesToRun() As System.ServiceProcess.ServiceBase

        ' Code added for Self-Installation
        Try
            Dim path As String = System.Reflection.Assembly.GetExecutingAssembly().Location
            Dim commandLine As String() = Nothing
            Dim msgText As String = ""
            Dim msgTitle As String = ""
            If args.Length > 0 Then
                Select Case args(0).ToUpper()
                    Case "-I"
                    Case "/I"
                        commandLine = New String() {path}
                        msgText = "Le service a été installé avec succes! Veuillez le démarrer depuis le Panneau de Contrôle."
                        msgTitle = " installation"
                    Case "-U"
                    Case "/U"
                        commandLine = New String() {"/u", path}
                        msgText = "Le service a été desinstallé avec succes!"
                        msgTitle = " desinstallation"
                    Case Else
                        Throw New ArgumentException("Paramètre invalide.")
                End Select
                System.Configuration.Install.ManagedInstallerClass.InstallHelper(commandLine)
                If System.Environment.UserInteractive Then
                    MsgBox(msgText, MsgBoxStyle.Information Or MsgBoxStyle.OkOnly, WinService.SvcDisplay & msgTitle)
                Else
                    Debug.WriteLine(msgText)
                End If
            Else
                If System.Environment.UserInteractive Then
                    'MsgBox("Interactive GUI", MsgBoxStyle.Information Or MsgBoxStyle.OkOnly, WinService.SvcDisplay & " run")
                    Dim f As frmMain = New frmMain()
                    f.ShowDialog()
                Else
                    ServicesToRun = New System.ServiceProcess.ServiceBase() {New WinService()}
                    System.ServiceProcess.ServiceBase.Run(ServicesToRun)
                End If
            End If

        Catch ex As Exception
            If System.Environment.UserInteractive Then
                MsgBox(ex.Message, MsgBoxStyle.Critical, WinService.SvcDisplay & " Error")
            Else
                Debug.WriteLine(ex.Message)
            End If
        End Try
    End Sub

    Private components As System.ComponentModel.IContainer

    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        components = New System.ComponentModel.Container()
        Me.ServiceName = WinService.SvcName
    End Sub

End Class