Option Strict Off
Option Explicit On

Imports Microsoft.VisualBasic.FileIO

Friend Class clsFolder
	'********************************************************************************
	'***
	'*** Module: Folder.cls
	'*** Purpose: Folder handling class. Includes validation checks, directory
	'*** creation, directory deletion, and other useful folder operations.
	'***
	'*** (c) Copyright 1999-2003 Kofax Image Products.
	'*** All rights reserved.
	'********************************************************************************
	
	Private Const THIS_FILE As String = "clsFolder"
	
	Private Const MAX_PATH As Short = 260
	Private Const MAX_MESSAGE_SIZE As Short = 1024
	
	' --- Returned by FindFirstFile function ---
	Private Const INVALID_FILE_HANDLE As Integer = -1
	
	' --- Used by FormatMessage API function ---
	Private Const FORMAT_MESSAGE_FROM_SYSTEM As Integer = &H1000s
	
	' --- Specially handled error codes ---
	Private Const ERR_FILE_NOT_FOUND As Integer = 2
	Private Const ERR_PATH_NOT_FOUND As Integer = 3
	Private Const ERROR_BAD_PATHNAME As Integer = 161
	Private Const ERR_ALREADY_EXISTS As Integer = 183
	
	Private Const VB_ERR_PATH_NOT_FOUND As Integer = 76
	
	' --- GetDriveType return values ---
	Private Const DRIVE_UNKNOWN As Integer = 0
	Private Const DRIVE_NO_ROOT_DIR As Integer = 1
	Private Const DRIVE_REMOVABLE As Integer = 2
	Private Const DRIVE_FIXED As Integer = 3
	Private Const DRIVE_REMOTE As Integer = 4
	Private Const DRIVE_CDROM As Integer = 5
	Private Const DRIVE_RAMDISK As Integer = 6
	
	' --- Exposed public drive type enumeration ---
	Public Enum eDriveTypes
		eDRIVE_UNKNOWN = DRIVE_UNKNOWN
		eDRIVE_NO_ROOT_DIR = DRIVE_NO_ROOT_DIR
		eDRIVE_REMOVEABLE = DRIVE_REMOVABLE
		eDRIVE_FIXED = DRIVE_FIXED
		eDRIVE_REMOTE = DRIVE_REMOTE
		eDRIVE_CDROM = DRIVE_CDROM
		eDRIVE_RAMDISK = DRIVE_RAMDISK
	End Enum
	
    '' --- Structs used by FindFirstFile ---
    'Private Structure FILETIME
    '	Dim dwLowDateTime As Integer
    '	Dim dwHighDateTime As Integer
    'End Structure
	
    'Private Structure WIN32_FIND_DATA
    '	Dim dwFileAttributes As Integer
    '	Dim ftCreationTime As FILETIME
    '	Dim ftLastAccessTime As FILETIME
    '	Dim ftLastWriteTime As FILETIME
    '	Dim nFileSizeHigh As Integer
    '	Dim nFileSizeLow As Integer
    '	Dim dwReserved0 As Integer
    '	Dim dwReserved1 As Integer
    '	'UPGRADE_WARNING: Fixed-length string size must fit in the buffer. Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="3C1E4426-0B80-443E-B943-0627CD55D48B"'
    '	<VBFixedString(MAX_PATH),System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.ByValArray,SizeConst:=MAX_PATH)> Public cFileName() As Char
    '	'UPGRADE_WARNING: Fixed-length string size must fit in the buffer. Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="3C1E4426-0B80-443E-B943-0627CD55D48B"'
    '	<VBFixedString(14),System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.ByValArray,SizeConst:=14)> Public cAlternate() As Char
    'End Structure

    '' --- API Declarations ---
    ''UPGRADE_WARNING: Structure WIN32_FIND_DATA may require marshalling attributes to be passed as an argument in this Declare statement. Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="C429C3A5-5D47-4CD9-8F51-74A1616405DC"'
    '   Private Declare Function FindFirstFile Lib "Kernel32" Alias "FindFirstFileA" (ByVal lpFileName As String, ByRef lpFindFileData As WIN32_FIND_DATA) As Integer
    'Private Declare Function FindClose Lib "Kernel32" (ByVal hFindFile As Integer) As Integer

    'Private Declare Function GetDriveType Lib "Kernel32"  Alias "GetDriveTypeA"(ByVal nDrive As String) As Integer
    'Private Declare Function GetFullPathName Lib "Kernel32"  Alias "GetFullPathNameA"(ByVal lpFileName As String, ByVal nBufferLength As Integer, ByVal lpBuffer As String, ByVal lpFilePart As String) As Integer
	
    Private Declare Function FormatMessage Lib "Kernel32" Alias "FormatMessageA" (ByVal dwFlags As Integer, ByRef lpSource As Object, ByVal dwMessageId As Integer, ByVal dwLanguageId As Integer, ByVal lpBuffer As String, ByVal nSize As Integer, ByRef Arguments As Integer) As Integer

    ' *** MEMBER VARIABLES ***
	Private m_strPath As String
	Private m_lDriveType As Integer
	Private m_strRoot As String
	Private m_bRootValid As Boolean
	Private m_bIsUNC As Boolean
	
	
	'*******************************************************
	'                Property Let (Path)
	'-------------------------------------------------------
	' Purpose   This routine will set the objects path
	'           property as well as initialize the rest of
	'           the objects members.
	' Notes:    This function can change the passed in sPath
	'           value before it gets saved.  It handles
	'           expanding relative paths and will add an
	'           extra backslash to the end of an incomplete
	'           UNC root.
	'*******************************************************
	
	'*******************************************************
	'                Property Get (Path)
	'-------------------------------------------------------
	' Purpose   Returns the path stored in the object.
	' Notes:    The path passed to the object in the
	'           property let function may be altered during
	'           the objects initialization.
	'*******************************************************
	Public Property Path() As String
		Get
			Path = m_strPath
			If Right(Path, 1) <> "\" Then
				Path = Path & "\"
			End If
		End Get
		Set(ByVal Value As String)
			
			' If the path is an empty string, just
			' put the object back in it's initial
			' state
			If Trim(Value) = "" Then
				m_strPath = ""
				m_lDriveType = DRIVE_UNKNOWN
				m_strRoot = ""
				m_bRootValid = False
				m_bIsUNC = False
				Exit Property
			End If
			
			' Expand any relative paths.
1000:       m_strPath = get_FullName(Value)
			m_bIsUNC = False
			
			' Extract the root off of the full path
			' value.  Also set the IsUNC flag.
1010:       m_strRoot = get_RootDir(m_strPath, m_bIsUNC, m_bRootValid)
			
			' If the root could not be extracted, don't try to
			' find the drive type.
			If m_bRootValid = False Then
				m_lDriveType = DRIVE_UNKNOWN
				' Otherwise, check the drive type
			Else
				' If the passed in path is a UNC root that
				' didn't have the trailing backslash, save
				' the edited root as it's correct.
                ' See function get_RootDir for more details.
				If Len(m_strRoot) > Len(m_strPath) Then
					m_strPath = m_strRoot
				End If
1020:           m_lDriveType = get_TheDriveType(m_strRoot)
			End If
			
		End Set
	End Property
	
	'*******************************************************
	'                Property Get (Root)
	'-------------------------------------------------------
	' Purpose   Returns the root of the path that is stored
	'           in the object.
	' Notes:    This function returns the root string that
	'           is set during the Path property let routine.
	'*******************************************************
    Public ReadOnly Property get_Root() As String
        Get
            System.Diagnostics.Debug.Assert(Len(m_strPath) > 0, "")
            get_Root = m_strRoot
        End Get
    End Property
	
	'*******************************************************
	'                Property Get (DriveType)
	'-------------------------------------------------------
	' Purpose   Returns the type drive the path is located
	'           on.
	' Notes:    This function simply returns a pre-set flag
	'           which is set during the Path property let
	'           routine.
	'*******************************************************
    Public ReadOnly Property get_DriveType() As Integer
        Get
            System.Diagnostics.Debug.Assert(Len(m_strPath) > 0, "")
            get_DriveType = m_lDriveType
        End Get
    End Property
	
	'*******************************************************
	'                Property Get (IsUNC)
	'-------------------------------------------------------
	' Purpose   Returns the type of path stored in the
	'           object.  If it's a standard drive letter
	'           mapping, this value is false, if it's a
	'           UNC path, this value is true.
	' Notes:    This function simply returns a pre-set flag
	'           which is set during the Path property let
	'           routine.
	'*******************************************************
	Public ReadOnly Property IsUNC() As Boolean
		Get
			System.Diagnostics.Debug.Assert(Len(m_strPath) > 0, "")
			IsUNC = m_bIsUNC
		End Get
	End Property
	
	'*******************************************************
	'                    CreatePath
	'-------------------------------------------------------
	' Purpose   This routine will attempt to create the path
	'           stored in the object.
	' Inputs:   bRaiseIfExists - Set to False to create the
	'           directory only if it doesn't already exist.
	'           This routine uses the objects data members.
	' Outputs:  NONE - An error is raised from this routine
	'           that must be caught by the callers own
	'           error handler.
	' Notes:    If the directory already exists, we'll throw
	'           an error if this function is called.
	'*******************************************************
	Public Sub CreatePath(Optional ByRef bRaiseIfExists As Boolean = True)
		
		Dim lErrNum As Integer '*** Error number
        Dim strErrDesc As String '*** Error description
        strErrDesc = ""
		
		If bRaiseIfExists = False Then
			
			'*** If they don't want errors when the directory
			'*** already exists, then bail out if the path
			'*** is valid.
			If IsValidNoThrow(lErrNum, strErrDesc) = True Then
				Exit Sub
			End If
		End If
		
		Call create_Path(m_strPath)
	End Sub
	
	'*******************************************************
	'                    create_Path
	'-------------------------------------------------------
	' Purpose   This routine will attempt to create the path
	'           stored in the object.
	' Inputs:   strPath -  the path to create
	' Outputs:  NONE
	'*******************************************************
	Private Sub create_Path(ByVal strPath As String)
        Dim strOriginalPath As String
        strOriginalPath = ""
		
		System.Diagnostics.Debug.Assert(Len(strPath) > 0, "")
		' Check to make sure the drive and root directory
		' are both valid before continuing.
		If m_lDriveType <= DRIVE_NO_ROOT_DIR Or m_bRootValid = False Then
1050:       throw_Error(ERROR_BAD_PATHNAME)
		End If
		
		' Save the current directory so we can put the system
		' back to it's original state after the "create_Directory"
		' call.
		If m_bIsUNC = False Then
1060:       strOriginalPath = CurDir(m_strRoot)
		End If
		
		On Error GoTo RESET_AND_RETHROW
		' This call to the recursive "create_Directory"
		' function will do the following:
		' 1 - Recursively create the entire path if
		' necessary.
		' 2 - Change the path to exactly what VB has
		' created.
		' 3 - Throw an error to the caller if this path
		' could not be created for any reason.
		create_Directory(strPath)
		
		' If we get here, all is well and we just need
		' to reset the system's state.  Turn off our
		' internal error handling at this point and allow
		' the caller to catch any other raised errors
		On Error GoTo 0
		If m_bIsUNC = False Then
1080:       ChDir(strOriginalPath)
		End If
		Exit Sub
		
		'---------------
		' Error Handler
		'---------------
RESET_AND_RETHROW: 
		' Make sure to try and reset the system state
		' before returning.
		ChDir(strOriginalPath)
		Err.Raise(Err.Number, Err.Source, Err.Description)
		
	End Sub
	
	'*******************************************************
	'                    FillDirectoryCollection
	'-------------------------------------------------------
	' Purpose   Builds a collection of all the files
	'           and directories under the member folder.
	' Inputs:   None.  This routine uses the objects data
	'           members.
	' Outputs:  collFiles - Collection containing full path
	'                       names of files and directories
	'                       found in the folder.
	' Note:     An error is raised from this routine
	'           that must be caught by the callers own
	'           error handler.
	'*******************************************************
	Public Sub FillDirectoryCollection(ByRef collFiles As Collection)
		
        Dim strOriginalPath As String
        strOriginalPath = ""
		
		System.Diagnostics.Debug.Assert(Len(m_strPath) > 0, "")
		' Check to make sure the drive and root directory
		' are both valid before continuing.
		If m_lDriveType <= DRIVE_NO_ROOT_DIR Or m_bRootValid = False Then
1310:       throw_Error(ERROR_BAD_PATHNAME)
		End If
		
		' Save the current directory so we can put the system
		' back to it's original state after the "fill_CollectionWithFiles"
		' call.
		If m_bIsUNC = False Then
1320:       strOriginalPath = CurDir(m_strRoot)
		End If
		
		On Error GoTo RESET_AND_RETHROW
		
		
		fill_CollectionWithFiles(m_strPath, collFiles)
		
		' If we get here, all is well and we just need
		' to reset the system's state.  Turn off our
		' internal error handling at this point and allow
		' the caller to catch any other raised errors
		On Error GoTo 0
		If m_bIsUNC = False Then
1330:       ChDir(strOriginalPath)
		End If
		
		Exit Sub
		
		'---------------
		' Error Handler
		'---------------
RESET_AND_RETHROW: 
		' Reset the error handler
		On Error GoTo 0
		
		' Make sure to try and reset the system state
		' before returning.
		ChDir(strOriginalPath)
		Err.Raise(Err.Number, Err.Source, Err.Description)
		
	End Sub
	
	'*******************************************************
	'                      GetRelativePath
	'-------------------------------------------------------
	' Purpose   This routine returns the path of the file
	'           relative to the object's member path.
	' Inputs:   Full file name for which a relative path is
	'           desired.
	' Outputs:  The file name passed in relative to the
	'           member folder.
	'           An error is raised from this routine
	'           that must be caught by the callers own
	'           error handler.
	' Example:  Path = "C:\Program Files\Ascent\"
	'           GetRelativePath("C:\Program Files\Ascent\Images\200\1.tif")
	'           returns: "Images\200\1.tif"
	'*******************************************************
	Public Function GetRelativePath(ByVal strFile As String) As String
		
		Dim nStartPos As Short
		
		' Be sure that the file name passed in is in the same
		' directory as this object's member path.
		If InStr(1, strFile, m_strPath, CompareMethod.Text) <> 1 Then
1410:       throw_Error(ERROR_BAD_PATHNAME)
		End If
		
		' Determine the position in strFile to start from
		nStartPos = Len(m_strPath)
		
		' Move past the last slash if there is one
1420:   If (Len(strFile) > nStartPos And Mid(strFile, nStartPos, 1) = "\") Then
            nStartPos = nStartPos + 1
        End If
		
		' Return the relative path
1430:   GetRelativePath = Mid(strFile, nStartPos)
		
	End Function
	
	'*******************************************************
	'                      IsValid
	'-------------------------------------------------------
	' Purpose   This routine checks the path currently
	'           stored in the object to see if it exists.
	' Inputs:   None.  This routine uses the objects data
	'           members.
	' Outputs:  NONE - An error is raised from this routine
	'           that must be caught by the callers own
	'           error handler.
	' Notes:    None
	'*******************************************************
	Public Sub IsValid()
		
		System.Diagnostics.Debug.Assert(Len(m_strPath) > 0, "")
		' If the drive type is either DRIVE_UNKNOWN or DRIVE_NOT_ROOT
		' the drive is not valid.  If the Root could not be extracted
		' from the path, also fail immediately.
		If m_lDriveType < DRIVE_REMOVABLE Or m_bRootValid = False Then
1090:       throw_Error(ERR_PATH_NOT_FOUND)
		End If
		
		' If the saved Path value is exactly the same as the extracted
		' root, the path is valid.  If it isn't exactly the same, check
		' to make sure the attached subdirectory is valid.
		If m_strRoot <> m_strPath Then
			check_Directory(m_strPath)
		End If
		
	End Sub
	
	'*******************************************************
	'                   IsValidNoThrow
	'-------------------------------------------------------
	' Purpose   This routine wraps the IsValid check and
	'           returns a boolean value and error message
	'           through function outputs instead of by
	'           throwing an error.
	' Inputs:   sErrorMsg - Error message if the stored
	'           path is not valid.
	' Outputs:  Status of the directory.  True = directory
	'           exists / False = directory does not exist.
	' Notes:    None
	'*******************************************************
	Public Function IsValidNoThrow(ByRef lError As Integer, ByRef strError As String) As Boolean
		
		System.Diagnostics.Debug.Assert(Len(m_strPath) > 0, "")
		' Initialize our return values as if we succeeded.
		' In the case of an error, we will fall into the below
		' error handler.
		strError = ""
		lError = 0
		IsValidNoThrow = True
		
		' Perform the test of the stored path.
		On Error GoTo DIR_NOT_VALID
		IsValid()
		Exit Function
		
		'---------------
		' Error Handlers
		'---------------
DIR_NOT_VALID: 
		' If we get here, the directory did not pass the tests.
		' Set the return values and exit.
		lError = Err.Number
		strError = Err.Description
		IsValidNoThrow = False
		
	End Function
	
	'*******************************************************
	'                        PopDir
	'-------------------------------------------------------
	' Purpose   Moves the current directory one level back
	'           up the directory tree.
	' Inputs:   None
	' Outputs:  None
	' Notes:    If the current directory is a root, this
	'           function will leave the directory as a
	'           root
	'*******************************************************
	Public Sub PopDir()
		Dim strTemp As String
		
		strTemp = remove_LastPathSegment(m_strPath)
		If strTemp <> "" Then
			m_strPath = strTemp
		End If
		
	End Sub
	
	
	'*******************************************************
	'                       Prune
	'-------------------------------------------------------
	' Purpose   Delete a directory and all files and subdirectories in it
	' Inputs:   This routine uses the objects data
	'           members.
	' Outputs:  NONE - An error is raised from this routine
	'           that must be caught by the callers own
	'           error handler.
	' Note:     May cause stack overflow on very large directories
	'*******************************************************
	Public Sub Prune()
		Dim strOriginalPath As String
		Dim nError As Integer
		Dim strErrSource As String
        Dim strErrDescription As String

        strOriginalPath = ""
		
		System.Diagnostics.Debug.Assert(Len(m_strPath) > 0, "")
		' Check to make sure the drive and root directory
		' are both valid before continuing.
		If m_lDriveType <= DRIVE_NO_ROOT_DIR Or m_bRootValid = False Then
1510:       throw_Error(ERROR_BAD_PATHNAME)
		End If
		
		' Make sure the current directory is not the folder being removed (or a subfolder)
		If m_bIsUNC = False Then
			If UCase(m_strPath) = Left(UCase(CurDir()), Len(m_strPath)) Then
				Call ChDir(m_strRoot)
			End If
		End If
		
		' Save the current directory so we can put the system
		' back to it's original state after the "prune_Directory"
		' call.
		If m_bIsUNC = False Then
1520:       strOriginalPath = CurDir(m_strRoot)
		End If
		
		On Error GoTo RESET_AND_RETHROW

        ' delete the files and subdirectories
        FileSystem.DeleteDirectory(m_strPath, DeleteDirectoryOption.DeleteAllContents)

		' If we get here, all is well and we just need
		' to reset the system's state.
		' If we can't change to the original directory,
		' try to change to the root.
		On Error GoTo CHANGE_TO_SAFE_DIR
		If m_bIsUNC = False Then
1530:       ChDir(strOriginalPath)
		End If
		
		Exit Sub
		
		'---------------
		' Error Handler
		'---------------
RESET_AND_RETHROW: 
		' Make sure to try and reset the system state
		' before returning.
		' If we can't change to the original directory,
		' try to change to the root.
		nError = Err.Number
		strErrSource = Err.Source
		strErrDescription = Err.Description
		Resume CHANGE_TO_ORIGINAL_DIR
CHANGE_TO_ORIGINAL_DIR: 
		On Error GoTo CHANGE_TO_SAFE_DIR
		ChDir(strOriginalPath)
		On Error GoTo 0
		Err.Raise(nError, strErrSource, strErrDescription & " (" & m_strPath & ")")
		
CHANGE_TO_SAFE_DIR: 
		' We were unable to change to the original
		' directory. Just change to the root instead.
		ChDir(m_strRoot)
		Resume Next
		
	End Sub
	
	
	'*******************************************************
	'                       PushDir
	'-------------------------------------------------------
	' Purpose   Adds the passed in subdirectory entires to
	'           the current directory.
	' Inputs:   Extra sub-directory entry values to append
	'           to the end of the current directory.
	' Outputs:  None
	' Notes:    This function cannot change roots.
	'*******************************************************
	Public Sub PushDir(ByRef strNewEntry As String)
		' Check passed in path entry for a leading
		' \ character.
		If Left(strNewEntry, 1) = "\" Then
			strNewEntry = Right(strNewEntry, Len(strNewEntry) - 1)
		End If
		
		If (Right(m_strPath, 1) <> "\") And (m_strPath <> "") Then
			m_strPath = m_strPath & "\"
		End If
		
		' Extract the relative path values from the 'pushed'
		' value.
		m_strPath = get_FullName(m_strPath & strNewEntry)
		
	End Sub
	
	'*******************************************************
	'                    check_Directory
	'-------------------------------------------------------
	' Purpose   This routine will check the passed in
	'           directory to see if it exists on the system.
	' Inputs:   sPath - Directory to search for.
	' Outputs:  NONE - An error is raised from this routine
	'           that must not be caught in an internal error
	'           handler.
	' Notes:    sPath cannot be an empty string or this
	'           function will fail immediately.
	'*******************************************************
    Private Sub check_Directory(ByVal strPath As String)

        If Trim(strPath) = "" Then
            throw_Error(ERROR_BAD_PATHNAME)
        End If

        Dim getInfo As System.IO.DirectoryInfo

        On Error GoTo check_Directory_Error

        ' GetDirectoryInfo will throw if it is invalid, doesn't exist 
        getInfo = FileSystem.GetDirectoryInfo(strPath)
        Exit Sub

check_Directory_Error:

        throw_Error(ERR_PATH_NOT_FOUND)

        '		Dim findData As WIN32_FIND_DATA
        '		Dim hFind As Integer
        '		Dim strWorkingPath As String
        '		Dim lError As Integer

        '		' Check to see if we were passed an empty string
        '		If Trim(strPath) = "" Then
        '			throw_Error(ERROR_BAD_PATHNAME)
        '		End If

        '		' Use the FindFirstFile function to determine whether or not
        '		' a subdirectory is valid.  The FindFirstFile function fails
        '		' if the subdirectory has a trailing backslash, so remove it.
        '		If Right(strPath, 1) = "\" Then
        '			strWorkingPath = Left(strPath, Len(strPath) - 1)
        '		Else
        '			strWorkingPath = strPath
        '		End If

        '		' The FindFirstFile function will also search for directories.
        '		' If it fails to find the dir, it returns a -1 ( or
        '        ' INVALID_FILE_HANDLE).

        '1150:   hFind = FindFirstFile(strWorkingPath, findData)
        '		If hFind = INVALID_FILE_HANDLE Then
        '			' If we get here, an error occurred while trying to access
        '			' the DLL function.
        '			lError = Err.LastDllError

        '			' Check the return code.  If the passed back error is for
        '			' FILE not found, which will occur under Win95, change it
        '			' to DIRECTORY not found.
        '			If lError = ERR_FILE_NOT_FOUND Then
        '				lError = ERR_PATH_NOT_FOUND
        '			End If

        '1160: throw_Error(lError)
        '		End If

        '		' If we get here, it means we found the directory.  Just clean
        '		' up the system resources we accessed with the Find call.
        '1170: FindClose(hFind)

    End Sub
	
	'*******************************************************
	'                  create_Directory
	'-------------------------------------------------------
	' Purpose:  This routine will try to create the
	'           directory at the passed in path.
	' Inputs:   sPath = Full path to directory to create
	' Outputs:  Success or Failure
	' Notes:    This routine is recursive.  It checks the
	'           parent directory of the directory to create
	'           and if the parent does not exist, it will
	'           try to create it.  This function will change
	'           the system's current directory.  If the
	'           current directory must be preserved, the
	'           caller must perserve it.
	'*******************************************************
	Private Sub create_Directory(ByRef strPath As String)
		Dim strParentDir As String
		Dim nParentDirLen As Short
		Dim bResult As Boolean
		
		' Step 1 -
		' Extract the parent directory, if we are working in
		' the root directory, causes automatic failure.  We
		' shouldn't be trying to create a root directory.
		strParentDir = remove_LastPathSegment(strPath)
		nParentDirLen = Len(strParentDir)
		If strParentDir = "" Then
			throw_Error(ERROR_BAD_PATHNAME)
		End If
		
		' Step 2 -
		' Make sure that the parent directory is valid
		' before trying to create a new directory.
		On Error GoTo DirNotYetExist
1200:   ChDir(strParentDir)
		
		' Step 3 -
		' Rebuild the directory value as the parent may have
		' been created and changed slightly.  See Step 5 below
		' for details.  Turn off error handling as we want
		' the error to be raised back up to the caller.
		On Error GoTo 0
		' If the parent directory is missing the trailing
		' backslash, add it.
		If Right(strParentDir, 1) <> "\" Then
			strParentDir = strParentDir & "\"
		End If
		' Make the new path equal to the new parent directory
		' plus everything found after the parent directory.
		' NOTE: nParentDirLen is not updated even though the
		' parent directory may have changed.  This enables the
		' following equation to properly extract the last entry
		' off the original path.
		strPath = strParentDir & Right(strPath, Len(strPath) - nParentDirLen)
		If Right(strPath, 1) = "\" Then
			strPath = Left(strPath, Len(strPath) - 1)
		End If
		
		' Step 4 -
		' Attempt to create the directory
1210:   MkDir(strPath)
		
		' Step 5 -
		' Change to the new directory.  The directory may not be
		' exactly as it was passed in.  VB has an annoying bug
		' that will accept a directory name and create it slightly
		' differently.
1220:   ChDir(strPath)
		
		' Step 6 -
		' If the path is passed in ByRef (as we do in our recursive
		' calls), change the directory to exactly represent what we've
		' just created.
		If m_bIsUNC = False Then
1230:       strPath = CurDir(strPath)
		End If
		
		' If we get here, the directory was successfully created
		Exit Sub
		
		'---------------
		' Error Handlers
		'---------------
DirNotYetExist: 
		' If we get here, we failed changing to the parent directory.
		' If the error is 'Path not found', then try to create the
		' directory, otherwise fail.
		If Err.Number = VB_ERR_PATH_NOT_FOUND Then ' Path not found = 76
			create_Directory(strParentDir)
			Resume Next
		End If
		
		' If we get here, either from the above error handler
		' falling through or from a different error, we fail
		' the routine.
		Err.Raise(Err.Number, Err.Source, Err.Description)
		Exit Sub
		
	End Sub
	
	
	'*******************************************************
	'                fill_CollectionWithFiles
	'-------------------------------------------------------
	' Purpose   This routine fills the collection with files
	'           and directories contained in the specified
	'           directory. It is called recursively so that
	'           all child files and directories are listed.
	' Inputs:   strPath - Directory for which to list all
	'                     files and sub folders
	' Outputs:  collFiles - Collection containing full path
	'                       filenames of files found in the
	'                       directory.
	'*******************************************************
	Private Sub fill_CollectionWithFiles(ByRef strPath As String, ByRef collFiles As Collection)

        ' the collection to keep the file and path names
        Dim oFiles As System.Collections.ObjectModel.ReadOnlyCollection(Of String)

        ' we want to search this directory and sub directories too
        ' this gets us all the files and their path too
        oFiles = FileSystem.GetFiles(strPath, SearchOption.SearchAllSubDirectories, "*.*")

        For Each strFile As String In oFiles
            ' extract just the name and add it to the collection passed in
            collFiles.Add(FileSystem.GetName(strFile))
        Next

        '		Dim strFile As String
        '		Dim collDirs As New Collection '*** Collection of subdirectories for recursion
        '		Dim strDir As Object
        '		Dim lIndex As Integer

        '		'*** Get a directory of all files and sub directories
        '1340: 'UPGRADE_ISSUE: Unable to determine which constant to upgrade vbNormal to. Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="B3B44E51-B5F1-4FD7-AA29-CAD31B71F487"'
        '		'UPGRADE_WARNING: Dir has a new behavior. Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="9B7D5ADD-D8FE-4819-A36C-6DEDAF088CC7"'
        '		strFile = Dir(strPath, FileAttribute.Directory Or vbNormal)
        '		While Len(strFile) <> 0

        '			'*** Skip over . and ..
        '			If strFile <> "." And strFile <> ".." Then

        '				'*** Add it to the collection passed in.
        '1350: collFiles.Add(strPath & strFile)

        '1360: If (GetAttr(strPath & strFile) And FileAttribute.Directory) = FileAttribute.Directory Then

        '					'*** Its a directory. We need to get those sub directories too.
        '					'*** But Dir cannot be called recursively. Save the directory
        '					'*** Names for a recursive call after we get everything from
        '					'*** the current dir.
        '1370: collDirs.Add(strPath & strFile & "\")
        '				End If
        '			End If

        '			'*** Get next file or directory
        '1380: 'UPGRADE_WARNING: Dir has a new behavior. Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="9B7D5ADD-D8FE-4819-A36C-6DEDAF088CC7"'
        '			strFile = Dir()
        '		End While

        '		'*** Now get all the directories for each of the subdirectories we found
        '		For lIndex = 1 To collDirs.Count()
        '			'UPGRADE_WARNING: Couldn't resolve default property of object collDirs.Item(). Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
        '			'UPGRADE_WARNING: Couldn't resolve default property of object strDir. Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
        '			strDir = collDirs.Item(lIndex)
        '			'*** Don't do this! Q183164 For Each strDir In collDirs
        '			'UPGRADE_WARNING: Couldn't resolve default property of object strDir. Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
        '			fill_CollectionWithFiles(CStr(strDir), collFiles)
        '		Next 

    End Sub
	
	'*******************************************************
    '                    get_TheDriveType
	'-------------------------------------------------------
	' Purpose   This routine returns the drive type as
	'           understood by the system for the passed in
	'           path.
	' Inputs:   sPath - Should be the root of the current
	'           path, however, it does not need to be.
	' Outputs:  NONE - An error is raised from this routine
	'           that must not be caught in an internal error
	'           handler.
	' Notes:    The errNum is used to extract a system level
	'           error message which is added to the raised
	'           error.
	'*******************************************************
    Private Function get_TheDriveType(ByVal strPath As String) As Integer

        Dim oDriveInfo As System.IO.DriveInfo
        oDriveInfo = FileSystem.GetDriveInfo(strPath)
        get_TheDriveType = oDriveInfo.DriveType

    End Function
	
	'*******************************************************
	'                   get_FullName
	'-------------------------------------------------------
	' Purpose   This routine takes a relative path name and
	'           expands it out to a full path.
	' Inputs:   sRelPath - The relative path
	' Outputs:  The expanded full path.
	' Notes:    If a full path is passed in as the function
    '           argument, the full path will be passed back
	'           unchanged.  This function DOES NOT check to
	'           see if the expanded path is valid.  It only
	'           builds the expanded path based on the
	'           current path.  This function is UNC safe.
	'*******************************************************
    Private Function get_FullName(ByVal strRelPath As String) As String

        Dim oDirInfo As System.IO.DirectoryInfo
        oDirInfo = FileSystem.GetDirectoryInfo(strRelPath)

        get_FullName = oDirInfo.FullName

        '		Dim strFullPath As String
        '		Dim strNewName As String
        '		Dim lLength As Integer

        '		strFullPath = Space(MAX_PATH)
        '		strNewName = Space(MAX_PATH)

        '		' lLength will be the size of the path not including the
        '		' terminating NULL
        '1260: lLength = GetFullPathName(strRelPath, MAX_PATH, strFullPath, strNewName)

        '		' When extracting the string DO NOT get the terminating NULL
        '		' as VB does need it.
        '		get_FullName = Left(strFullPath, lLength)

    End Function
	
	'*******************************************************
    '                      get_RootDir
	'-------------------------------------------------------
	' Purpose   Parses the root directory off the passed in
	'           path.  Will also determine whether or not
	'           the passed in path is UNC.
	' Inputs:   sPath - Full path
	'           bIsUNC - PASSED BY REF!! Returns whether or
	'           not the path is UNC.
	'           bIsValid - PASSED BY REF!! Returns whether
	'           or not the root was successfully extracted.
	' Outputs:  The parsed off root directory.
	' Notes:    None
	'*******************************************************
    Private Function get_RootDir(ByVal strPath As String, ByRef bIsUNC As Boolean, ByRef bIsValid As Boolean) As String
        Dim nBSlashes As Integer
        Dim nCurrChar As Short
        Dim nUNCRootEnd As Short

        ' Start with the assumption that it is not a UNC path
        bIsUNC = False
        bIsValid = False

        ' First check to make sure that the passed in folder path
        ' is at least 3 characters long.
        If Len(strPath) < 3 Then
            get_RootDir = ""
            Exit Function
        End If

        ' Now check to see if the passed in value is a UNC type path.
        ' This is done by checking the first two characters looking for
        ' the \\ characters.
        If Left(strPath, 2) = "\\" Then

            ' Search for up to four backslash (\) characters while
            ' parsing the UNC root off the path.  A UNC root has the
            ' following format: "\\ENGNT\Ascent\".  The result must be
            ' valid if either three or four backslash characters are
            ' found because the MS common dialogs return a UNC root with
            ' only three backslash characters.  Three backslash characters
            ' isn't really valid, however, as all the directory test
            ' methods require the fourth backslash in order to work.
            nBSlashes = 2 ' Search for two more backslashes
            nCurrChar = 3 ' Start search after leading "\\"
            Do While nBSlashes
                nCurrChar = InStr(nCurrChar, strPath, "\")
                If nCurrChar Then
                    nBSlashes = nBSlashes - 1
                    nUNCRootEnd = nCurrChar
                    nCurrChar = nCurrChar + 1
                Else
                    Exit Do
                End If
            Loop

            ' Check the remaining backslash count.  The remaining backslash
            ' count can be either 0 or 1 and still be valid.  i.e:
            ' 0 = "\\ENGNT\ASCENT\"
            ' 1 = "\\ENGNT\ASCENT"
            ' If we encounter the second case, we must add the trailing
            ' backslash to the root in order to make it valid.
            Select Case nBSlashes
                Case 0 ' i.e. "\\ENGNT\ASCENT\"
                    ' If we found all four backslashes, extract the root
                    ' from the path.
                    bIsUNC = True
                    get_RootDir = Left(strPath, nUNCRootEnd)
                    bIsValid = True

                Case 1 ' i.e. "\\ENGNT\ASCENT"
                    ' If we found only three backslashes, accept the entire
                    ' string as the root PLUS add the trailing backslash.
                    bIsUNC = True
                    get_RootDir = strPath & "\"
                    bIsValid = True

                Case Else ' i.e. "\\ENGNT" -- NOT VALID!!
                    get_RootDir = ""

            End Select

            ' If the first two characters are not '\\', assume it's a standard
            ' drive letter mapping.
        Else
            ' Extract the three letter drive root entry from the path.
            ' Check to make sure it's a valid root by making sure it
            ' follows the standard "<Letter>:\" convention.  NOTE: You can
            ' map drives to characters other than letters, so we only check
            ' for the ":\"
            If Mid(strPath, 2, 2) = ":\" Then
                get_RootDir = Left(strPath, 3)
                bIsValid = True
            Else
                get_RootDir = ""
            End If

        End If

    End Function
	
	
	'*******************************************************
	'                remove_LastPathSegment
	'-------------------------------------------------------
	' Purpose:  This routine will remove the last entry on a
	'           path string and pass back the results.
	' Inputs:   sPath = Path string
	' Outputs:  Path string minus last entry or an empty
	'           string if no further \ chars could be found
	' Notes:    If a drive letter root directory or a single
	'           entry path string is passed in, an empty
	'           string will be passed back out.  Searches
	'           for UNC roots specifically.
	'*******************************************************
	Private Function remove_LastPathSegment(ByVal strPath As String) As String
		Dim nCurrentChar As Short
		Dim nTempChar As Short
		Dim bIsUNC As Boolean
		Dim bIsValid As Boolean
		
		' Trim the passed in string to remove all white
		' space and initialize the current pointer location
		strPath = Trim(strPath)
		nCurrentChar = 0
		
		' Check to see if we are working with a root directory.
		' This tests the length of the root directory and if it's
		' the same size or longer then the passed in value, we
		' are working with a root directory.  This was added to
		' handle UNC roots.
        If Len(get_RootDir(strPath, bIsUNC, bIsValid)) >= Len(strPath) Then
            remove_LastPathSegment = ""
            Exit Function
        End If
		
		' If there is a trailing "\" character, remove it before
		' we try and chop off the last directory segment.
		If Right(strPath, 1) = "\" Then
			strPath = Left(strPath, Len(strPath) - 1)
		End If
		
		' Loop on scanning the string for "\" characters until we
		' find the last one.
		Do 
			nTempChar = InStr(nCurrentChar + 1, strPath, "\")
			If nTempChar <> 0 Then
				nCurrentChar = nTempChar
			End If
		Loop Until nTempChar = 0
		
		' If we found at least one in the remaining string,
		' create a string up to that "\", otherwise there is
		' no remaining path so pass back an empty string.
		If nCurrentChar > 1 Then
			remove_LastPathSegment = Left(strPath, nCurrentChar)
		Else
			remove_LastPathSegment = ""
		End If
		
	End Function
	
	'*******************************************************
	'                    throw_Error
	'-------------------------------------------------------
	' Purpose   This routine will build and raise a VB error
	'           back to the caller if an error occurs inside
	'           this class.
	' Inputs:   errNum - The system error number
	' Outputs:  NONE - An error is raised from this routine
	'           that may not be caught in an internal error
	'           handler if the function wants to pass the
	'           error back to the calling routine.
	' Notes:    The errNum is used to extract a system level
	'           error message which is added to the raised
	'           error.
	'*******************************************************
	Private Sub throw_Error(ByVal errNum As Integer)
		Dim strErrorMessage As String
		Dim lResult As Integer
		
		' Extract the system message from Windows for this error
		strErrorMessage = Space(MAX_MESSAGE_SIZE)
		lResult = FormatMessage(FORMAT_MESSAGE_FROM_SYSTEM, 0, errNum, 0, strErrorMessage, MAX_MESSAGE_SIZE, 0)
		strErrorMessage = Left(strErrorMessage, lResult)
		
		' Then raise the error
		Err.Raise(errNum, THIS_FILE, strErrorMessage)
	End Sub
	
	'*******************************************************
	'                 Class_Initialize
	'-------------------------------------------------------
	' Purpose   This routine will initialize the internal
	'           vars to a known state.  Only the drive type
	'           really needs to be initialized, but I
	'           initialize all state vars here just in case.
	' Notes:    None
	'*******************************************************
	'UPGRADE_NOTE: Class_Initialize was upgraded to Class_Initialize_Renamed. Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="A9E4979A-37FA-4718-9994-97DD76ED70A7"'
    Private Sub Initialize()

        m_lDriveType = DRIVE_UNKNOWN
        m_bRootValid = False
        m_bIsUNC = False

    End Sub
    Public Sub New()
        MyBase.New()
        Initialize()
    End Sub
	

	'*******************************************************
	'                  Copy
	'-------------------------------------------------------
	' Purpose:  Copy a folder recursively
	' Input:     strDest: The folder to copy to
	' ### WIP ### The error checking code in this function
	'   is duplicated throughout this class.  It should
	'   probably be made into a function at some point
	'*******************************************************
	Public Sub Copy(ByVal strDest As String)
		System.Diagnostics.Debug.Assert(Len(m_strPath) > 0, "")
		
		' Check to make sure the drive and root directory
		' are both valid before continuing.
		If m_lDriveType <= DRIVE_NO_ROOT_DIR Or m_bRootValid = False Then
1700:       throw_Error(ERROR_BAD_PATHNAME)
		End If

        FileSystem.CopyDirectory(m_strPath, strDest, True)
    End Sub
	
	'**************************************************
	'                  last_Character
	'-------------------------------------------------------
    ' Purpose:   Return the last occurrence of a character within a string
	' Input:     str: String to search through
	'            c: The character to search for
	' Output:    The location within the string
	'**************************************************
	'UPGRADE_NOTE: str was upgraded to str_Renamed. Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="A9E4979A-37FA-4718-9994-97DD76ED70A7"'
    Private Function last_Character(ByRef str As String, ByRef c As String) As Short
        Dim ii As Short
        Dim jj As Short

        ii = 1
        jj = 0

        ' Make sure that c is only one character.
        If Len(c) <> 1 Then
            last_Character = 0
            Exit Function
        End If

        ' If the string starts with a "\", make sure we catch it.
        If Left(str, 1) = c Then jj = 1
        While ii > 0
            ii = InStr(ii + 1, str, c)
            If ii > 0 Then jj = ii
        End While

        last_Character = jj
    End Function
	
	'*******************************************************
	'                  ReturnLastPathSegment
	'-------------------------------------------------------
	' Purpose:   Return the file portion of a filename
	' Input:     strPath: A file path
	' Output:    The filename
	'*******************************************************
	Private Function ReturnLastPathSegment(ByVal strPath As String) As String
		Dim ii As Short
		
		' Remove trailing slashes before finding the last one
		While Not (Right(strPath, 1) <> "\")
			strPath = Left(strPath, Len(strPath) - 1)
		End While
		
		ii = last_Character(strPath, "\")
		If ii <> 0 Then
			ReturnLastPathSegment = Right(strPath, Len(strPath) - ii)
		Else
			ReturnLastPathSegment = ""
		End If
		
	End Function
End Class