﻿'******************************************************************************
'***
'*** Module:    Processor.vb - Processor
'*** Purpose:   Encapsulates the separate process.
'***
'*** (c) Copyright 2009 Kofax Image Products.
'*** All rights reserved.
'***
'******************************************************************************

Imports System.IO
Imports System.Runtime.InteropServices

Public Class Processor
    Implements IProcessor, IDisposable

    '*** Constants
    Private Const THIS_FILE As String = "Processor"

    Private Const CUSTMOD_ID As String = "AOI.Custom.Agregation"

    Private Const DOCUMENTS As String = "Documents"
    Private Const DOCUMENT As String = "Document"
    Private Const PAGES As String = "Pages"
    Private Const PAGE As String = "Page"
    Private Const BATCH As String = "Batch"
    Private Const DOCUMENTCLASSES As String = "DocumentClasses"
    Private Const DOCUMENTCLASS As String = "DocumentClass"
    Private Const FORMTYPES As String = "FormTypes"
    Private Const FORMTYPE As String = "FormType"
    Private Const STR_NAME As String = "Name"
    Private Const FORMTYPENAME As String = "FormTypeName"
    Private Const STR_NOTE As String = "Note"
    Private RuntimePath As String = Path.GetDirectoryName(New Uri(Reflection.Assembly.GetExecutingAssembly.CodeBase).AbsolutePath)

    '********************************************************************************
    '*** Sub:       PageStatus
    '*** Purpose:   Raise a status string for the Page label
    '********************************************************************************
    Event PageStatus(ByVal strStatus As String) Implements IProcessor.PageStatus

    '********************************************************************************
    '*** Sub:       DocumentStatus
    '*** Purpose:   Raise a status string for the Document label
    '********************************************************************************
    Event DocumentStatus(ByVal strStatus As String) Implements IProcessor.DocumentStatus

    '********************************************************************************
    '*** Sub:       CustomModuleID
    '*** Purpose:   The UniqueID of the custom module
    '********************************************************************************
    ReadOnly Property CustomModuleID() As String Implements IProcessor.CustomModuleID
        Get
            Return CUSTMOD_ID
        End Get
    End Property

    '********************************************************************************
    '*** Sub:       ProcessDescription
    '*** Purpose:   The feature description of the custom module
    '********************************************************************************
    ReadOnly Property ProcessDescription() As String Implements IProcessor.ProcessDescription
        Get
            Return My.Resources.Feature
        End Get
    End Property

    '********************************************************************************
    '*** Sub:       ProcessCaption
    '*** Purpose:   The caption to be displayed on the form using this process
    '********************************************************************************
    ReadOnly Property ProcessCaption() As String Implements IProcessor.ProcessCaption
        Get
            Return My.Resources.Caption
        End Get
    End Property

    '********************************************************************************
    '*** Sub:       Process
    '*** Purpose:   Move each loose page into a newly created document.
    '*** Inputs:    oBatch - The batch to be processed.
    '*** Outputs:   None
    '********************************************************************************
    'Public Sub Process(ByVal oBatch As Kofax.Capture.SDK.CustomModule.IBatch) Implements IProcessor.Process

    '    'Dim strTemp As String '*** Contains intermediate string
    '    Dim oRootElement As Kofax.Capture.SDK.Data.IACDataElement = Nothing '*** Root element
    '    Dim oBatchElement As Kofax.Capture.SDK.Data.IACDataElement = Nothing
    '    Dim oPagesElement As Kofax.Capture.SDK.Data.IACDataElement = Nothing
    '    Dim oColPages As Kofax.Capture.SDK.Data.IACDataElementCollection = Nothing
    '    Dim oPageElement As Kofax.Capture.SDK.Data.IACDataElement = Nothing
    '    Dim lPageIndex As Integer
    '    Dim lPageCount As Integer
    '    Dim nbDoc As Integer

    '    '*** Access Runtime Information
    '    oRootElement = oBatch.ExtractRuntimeACDataElement(0)

    '    oBatchElement = oRootElement.FindChildElementByName(BATCH)

    '    '*** Find the pages
    '    oPagesElement = oBatchElement.FindChildElementByName(PAGES)
    '    oColPages = oPagesElement.FindChildElementsByName(PAGE)
    '    If oColPages Is Nothing Then
    '        '*** Set caption indicating No loose pages
    '        RaiseEvent PageStatus(My.Resources.NoLoosePages)
    '        Exit Sub
    '    End If

    '    Dim strFormType As String = FindFirstFormType(oBatch)

    '    lPageCount = oColPages.Count
    '    lPageIndex = 1

    '    '*** For Each oPageElement In oColPages
    '    Dim oDocumentsElement As Kofax.Capture.SDK.Data.IACDataElement = Nothing
    '    Dim oColDocuments As Kofax.Capture.SDK.Data.IACDataElementCollection = Nothing
    '    Dim oNewDocument As Kofax.Capture.SDK.Data.IACDataElement = Nothing
    '    Dim oNewPages As Kofax.Capture.SDK.Data.IACDataElement = Nothing  '*** Document element '*** Documents element
    '    Dim oDocumentElement As Kofax.Capture.SDK.Data.IACDataElement = Nothing
    '    Dim oDocPagesElement As Kofax.Capture.SDK.Data.IACDataElement = Nothing

    '    oDocumentsElement = oBatchElement.FindChildElementByName(DOCUMENTS)
    '    oColDocuments = oDocumentsElement.FindChildElementsByName(DOCUMENT)

    '    'MsgBox(oColDocuments.Count & " document(s) à traiter")

    '    For nbDoc = 1 To oColDocuments.Count Step 1
    '        oDocumentElement = oColDocuments.Item(nbDoc)
    '        'MsgBox("document de type " & oDocumentElement.AttributeValue(FORMTYPENAME))

    '        oDocPagesElement = oDocumentElement.FindChildElementByName(PAGES)
    '        oColPages = oDocPagesElement.FindChildElementsByName(PAGE)

    '        'On ne passe que dans les "Annexes à traiter"
    '        If (StrComp(oDocumentElement.AttributeValue(FORMTYPENAME), "ANNEXES  A  TRAITER") = 0) Then
    '            'On voit de quel type d'annexe il s'agit
    '            Select Case oDocumentElement.AttributeValue("TypeAnnexe")
    '                Case "Partition1"
    '                'On voit s'il s'agit de la premiere page
    '                'si c'est le cas, on créé le document de ce type

    '                Case "PartitionN"
    '                    Dim findAnnexe As Integer
    '                    findAnnexe = oColDocuments.Count
    '                    While ((findAnnexe > 0) And "ANNEXES  A  TRAITER".Equals(oDocumentElement.AttributeValue(FORMTYPENAME), StringComparison.InvariantCultureIgnoreCase))
    '                        findAnnexe = findAnnexe - 1
    '                    End While
    '                    'si on a trouvé le document
    '                    If (findAnnexe > 0) Then
    '                        'on y copie l'annexe
    '                    Else
    '                        'on crée le document et on y copie l'annexe
    '                    End If
    '            End Select
    '            oDocumentElement.Delete()
    '        End If
    '    Next
    'End Sub

    '*******************************************************************************************
    '*** Sub:       Processing
    '*** Sujet :    Agrégation du lot / regroupe les documents du même type / même dossier
    '*** But :      Si en validation un opérateur, pour un même dossier type un document
    '***            en partition 1ère page et dans le même dossier il type un autre document en
    '***            partition 2ème page, ce module regroupe ces document en un seul de type
    '***            partition. Si dans le même dossier, il y a un autre document de type
    '***            partition 1 ère page, ce module créra un nouveau document de type partition.
    '*** Fontionnement : On parcourt tous les documents de type "Annexe à traiter" ou "Mixte",
    '***            On prend le premier document, non regarde le code oeuvre et on cherche si
    '***            un document de même typeX mais en page suivante qui le suit. Si on en trouve,
    '***            on les met dans le même document qu'on retype en typeX. Si on retombe sur un
    '***            document de typeX première page ou quon change de code oeuvre, on consifère
    '***            que notre premier document est complet.
    '*******************************************************************************************

    Private Sub Notify(ByVal msg As String)
        If System.Environment.UserInteractive Then
            MsgBox(msg)
        End If
        Debug.WriteLine(msg)
    End Sub

    Public Sub Process(ByRef oBatch As Kofax.Capture.SDK.CustomModule.IBatch) Implements IProcessor.Process

        'Déclaration des variables
        Dim oRootElement As Kofax.Capture.SDK.Data.IACDataElement = Nothing   '*** Root element
        Dim oBatchElement As Kofax.Capture.SDK.Data.IACDataElement = Nothing
        Dim oColPages As Kofax.Capture.SDK.Data.IACDataElementCollection = Nothing
        Dim oDocumentElement As Kofax.Capture.SDK.Data.IACDataElement = Nothing
        Dim oDocPagesElement As Kofax.Capture.SDK.Data.IACDataElement = Nothing
        Dim oPage As Kofax.Capture.SDK.Data.IACDataElement = Nothing
        Dim oNewPages As Kofax.Capture.SDK.Data.IACDataElement = Nothing
        Dim oDocumentsElement As Kofax.Capture.SDK.Data.IACDataElement = Nothing  '*** Documents element
        Dim oColDocuments As Kofax.Capture.SDK.Data.IACDataElementCollection = Nothing
        Dim oTmpColDocuments As Kofax.Capture.SDK.Data.IACDataElementCollection = Nothing
        Dim oTmpDocumentsElement As Kofax.Capture.SDK.Data.IACDataElement = Nothing
        Dim oNewDocument As Kofax.Capture.SDK.Data.IACDataElement = Nothing       '*** Document element
        Dim fieldElement As Kofax.Capture.SDK.Data.IACDataElement = Nothing
        Dim oColFields As Kofax.Capture.SDK.Data.IACDataElementCollection = Nothing

        Dim listType As Kofax.Capture.SDK.Data.IACDataElementCollection = Nothing
        Dim oPageTmp As Kofax.Capture.SDK.Data.IACDataElement = Nothing

        Dim oNextDocumentElement As Kofax.Capture.SDK.Data.IACDataElement = Nothing
        Dim oNextPagesElement As Kofax.Capture.SDK.Data.IACDataElement = Nothing
        Dim oNextColPages As Kofax.Capture.SDK.Data.IACDataElementCollection = Nothing
        Dim oNextPageElement As Kofax.Capture.SDK.Data.IACDataElement = Nothing
        Dim oNextFields As Kofax.Capture.SDK.Data.IACDataElement = Nothing
        Dim oNextColFields As Kofax.Capture.SDK.Data.IACDataElementCollection = Nothing
        Dim CodeOeuvreNext As String = ""
        Dim TypeAnnexeNext As String = ""
        Dim TypeDocNext As String = ""
        Dim page1Next As Boolean

        Dim lastDoc As Integer

        'Déclaration des variables
        Dim cptPage As Integer
        'Dim nbPageType As Integer
        'Dim nbDoc As Integer
        Dim testCreation As Boolean
        'Dim findDoc As Boolean
        Dim i As Integer
        Dim j As Integer
        Dim testError As Boolean
        Dim typeError As Boolean
        Dim testErrorMessage As String
        Dim TypeAnnexe As String = ""
        Dim ntsEtiquette As String = ""
        Dim page1 As Boolean
        Dim TypeDoc As String = ""
        Dim CodeOeuvre As String = ""
        Dim FileName As String = ""
        Dim COAD As String = ""
        Dim CV As String = ""
        Dim IniFile As String = ""
        Dim nbClass As String = ""
        Dim numPage As String = ""
        Dim ReadIniFile As String
        Dim Titre As String = ""
        Dim CodeOeuvreRef As String = ""
        'Dim page1Ref As Boolean
        Dim posCur As Integer
        Dim SortieW2 As Boolean

        Try


            Dim g As Kofax.Capture.SDK.Data.IACDataElement = Nothing


            'Initialisation des variables
            testError = False
            testErrorMessage = ""
            typeError = False
            TypeAnnexe = ""
            CodeOeuvre = ""
            page1 = True
            TypeDoc = ""
            testCreation = False
            CodeOeuvreRef = ""
            posCur = 1
            SortieW2 = False

            '*** Positionnement sur le cas à traiter
            oRootElement = oBatch.ExtractRuntimeACDataElement(0)

            '*** Positionnement sur le lot
            oBatchElement = oRootElement.FindChildElementByName(BATCH)
            'lblBatchname.Caption = oBatchElement.AttributeValue(STR_NAME)

            'Récupération des documents
            oDocumentsElement = oBatchElement.FindChildElementByName(DOCUMENTS)
            oColDocuments = oDocumentsElement.FindChildElementsByName(DOCUMENT)


            If Not File.Exists(Path.Combine(RuntimePath, "Gecod.ini")) Then
                testError = True
                testErrorMessage = "Fichier d'initialisation Gecod.ini introuvable"
                Notify($"Fichier d'initialisation Gecod.ini introuvable ({RuntimePath})")
            Else
                IniFile = Path.Combine(RuntimePath, "Gecod.ini")

                'On parcourt l'ensemble des documents
                i = 1
                lastDoc = oColDocuments.Count

                While (i <= lastDoc)

                    oDocumentElement = oColDocuments.Item(i)

                    ' On ne passe que dans les "Annexes à traiter" ou "Mixtes" (on vérifie le type de document
                    ' à rechercher par rapport à la classe de lots dans le Gecod.ini
                    If (StrComp(oDocumentElement.AttributeValue(FORMTYPENAME), FindFirstFormType(oBatch)) = 0) Then

                        'On récupère les pages du document
                        oDocPagesElement = oDocumentElement.FindChildElementByName(PAGES)
                        oColPages = oDocPagesElement.FindChildElementsByName(PAGE)

                        'On parcourt les pages --> Normalement, une seule page par document Annexe
                        For cptPage = 1 To oColPages.Count Step 1

                            TypeAnnexe = ""
                            page1 = True
                            TypeDoc = ""

                            'On récupère la page à transférer
                            oPage = oColPages.Item(cptPage)

                            'Récupération des index du documents
                            fieldElement = oDocumentElement.FindChildElementByName("IndexFields")
                            oColFields = fieldElement.FindChildElementsByName("IndexField")


                            Dim f As Kofax.Capture.SDK.Data.IACDataElement = Nothing

                            For Each f In oColFields
                                If (StrComp(f.AttributeValue("Name"), "CodeOeuvre") = 0) Then
                                    CodeOeuvre = f.AttributeValue("value")
                                End If
                                If (StrComp(f.AttributeValue("Name"), "Type de document") = 0) Then
                                    TypeAnnexe = f.AttributeValue("value")
                                End If
                                If (StrComp(f.AttributeValue("Name"), "DocumentTitle") = 0) Then
                                    Titre = f.AttributeValue("value")
                                End If
                                If (StrComp(f.AttributeValue("Name"), "COAD") = 0) Then
                                    COAD = f.AttributeValue("value")
                                End If
                                If (StrComp(f.AttributeValue("Name"), "CodeVersion") = 0) Then
                                    CV = f.AttributeValue("value")
                                End If
                                If (StrComp(f.AttributeValue("Name"), "ntsEtiquette") = 0) Then
                                    ntsEtiquette = f.AttributeValue("value")
                                End If
                            Next

                            nbClass = ""
                            numPage = ""
                            ReadIniFile = ""

                            If (StrComp(TypeAnnexe, "") = 0) Then
                                testError = True
                                typeError = True
                                testErrorMessage = "Le type de document saisi est incorrect."
                                Notify(testErrorMessage)
                            Else
                                'Récupération des informations nécessaires dans le fichier ini
                                nbClass = GetIniString("CHOIXCLASS", TypeAnnexe, IniFile)
                                If nbClass = "" Then
                                    If ReadIniFile = "" Then ReadIniFile = "choix " & TypeAnnexe & " introuvable"
                                End If


                                'Classe de doc Ascent
                                TypeDoc = GetIniString("DOCCCLASS", nbClass, IniFile)
                                If TypeDoc = "" Then
                                    If ReadIniFile = "" Then ReadIniFile = "Pas de docClass qui corresponde"
                                End If

                                'Permet de savoir si on est sur un doc premiere page ou page suivante
                                numPage = GetIniString("NUMPAGE", nbClass, IniFile)
                                If numPage = "" Then
                                    If ReadIniFile = "" Then ReadIniFile = "Pas de numéro de page spécifié."
                                Else
                                    If (numPage = "1") Then
                                        page1 = True
                                    Else
                                        page1 = False
                                    End If
                                End If

                            End If

                            oDocumentElement.AttributeValue(FORMTYPENAME) = TypeDoc
                            oColFields = oDocumentElement.FindChildElementByName("IndexFields").FindChildElementsByName("IndexField")
                            For Each f In oColFields
                                If (StrComp(f.AttributeValue("Name"), "CodeOeuvre") = 0) Then
                                    f.AttributeValue("value") = CodeOeuvre
                                End If
                                If (StrComp(f.AttributeValue("Name"), "DocumentTitle") = 0) Then
                                    f.AttributeValue("value") = Titre
                                End If
                                If (StrComp(f.AttributeValue("Name"), "COAD") = 0) Then
                                    f.AttributeValue("value") = COAD
                                End If
                                If (StrComp(f.AttributeValue("Name"), "CodeVersion") = 0) Then
                                    f.AttributeValue("value") = CV
                                End If
                                If (StrComp(f.AttributeValue("Name"), "ntsEtiquette") = 0) Then
                                    f.AttributeValue("value") = ntsEtiquette
                                End If
                            Next

                            If (ReadIniFile <> "") Then
                                Notify("Incohérence avec fichier Gecod.ini : " & ReadIniFile)
                            Else

                                'On parcourt les documents suivants tant qu'ils sont du même type
                                j = i + 1
                                SortieW2 = False

                                While ((Not SortieW2) And (j <= lastDoc))
                                    If (StrComp(oColDocuments.Item(j).AttributeValue(FORMTYPENAME), FindFirstFormType(oBatch)) = 0) Then

                                        'On récupère le document de test suivant
                                        oNextDocumentElement = oColDocuments.Item(j)

                                        oNextPagesElement = oNextDocumentElement.FindChildElementByName(PAGES)
                                        oNextColPages = oNextPagesElement.FindChildElementsByName(PAGE)
                                        oNextPageElement = oNextColPages.Item(1)
                                        oNextFields = oNextDocumentElement.FindChildElementByName("IndexFields")
                                        oNextColFields = oNextFields.FindChildElementsByName("IndexField")

                                        'On récupère tous les indexs nécessaires
                                        For Each f In oNextColFields
                                            If (StrComp(f.AttributeValue("Name"), "CodeOeuvre") = 0) Then
                                                CodeOeuvreNext = f.AttributeValue("value")
                                            End If
                                            If (StrComp(f.AttributeValue("Name"), "Type de document") = 0) Then
                                                TypeAnnexeNext = f.AttributeValue("value")
                                            End If
                                        Next

                                        nbClass = ""
                                        numPage = ""
                                        ReadIniFile = ""

                                        If (StrComp(TypeAnnexeNext, "") = 0) Then
                                            testError = True
                                            typeError = True
                                            testErrorMessage = "Le type de document saisi est incorrect."
                                            Notify(testErrorMessage)
                                        Else

                                            'Récupération des informations nécessaires dans le fichier ini
                                            nbClass = GetIniString("CHOIXCLASS", TypeAnnexeNext, IniFile)
                                            If nbClass = "" Then
                                                If ReadIniFile = "" Then ReadIniFile = "choix " & TypeAnnexeNext & " introuvable"
                                            End If

                                            'Classe de doc Ascent
                                            TypeDocNext = GetIniString("DOCCCLASS", nbClass, IniFile)
                                            If TypeDocNext = "" Then
                                                If ReadIniFile = "" Then ReadIniFile = "Pas de docClass qui corresponde"
                                            End If

                                            'Permet de savoir si on est sur un doc premiere page ou page suivante
                                            numPage = GetIniString("NUMPAGE", nbClass, IniFile)
                                            If numPage = "" Then
                                                If ReadIniFile = "" Then ReadIniFile = "Pas de numéro de page spécifié."
                                            Else
                                                If (numPage = "1") Then
                                                    page1Next = True
                                                Else
                                                    page1Next = False
                                                End If
                                            End If

                                        End If

                                        'Si on a même type doc + même CO + page suivante, on AGREGE
                                        If ((StrComp(CodeOeuvre, CodeOeuvreNext) = 0) And (StrComp(TypeDoc, TypeDocNext) = 0) And (Not page1Next)) Then

                                            'On pointe sur le dossier destination
                                            If (oDocumentElement.AttributeValue("UniqueID") <> oNextDocumentElement.AttributeValue("UniqueID")) Then

                                                'Récupération des noeuds pages (Collection --> XML)
                                                oNewPages = oDocumentElement.FindChildElementByName(PAGES)

                                                'On déplace toutes les pages (normalement qu'une) de NextDocument vers DocumentElement
                                                For Each oPageTmp In oNextDocumentElement.FindChildElementByName(PAGES).FindChildElementsByName(PAGE)
                                                    'On met notre page tout en bas du document
                                                    oPageTmp.MoveToBack(oNewPages)
                                                Next

                                                oColDocuments.Item(j).Delete()

                                                'On décrémente la borne principale
                                                lastDoc = lastDoc - 1
                                                'On recharcge les documents
                                                oDocumentsElement = oBatchElement.FindChildElementByName(DOCUMENTS)
                                                oColDocuments = oDocumentsElement.FindChildElementsByName(DOCUMENT)

                                                If (j > lastDoc) Then SortieW2 = True

                                            Else
                                                j = j + 1
                                            End If
                                        Else
                                            SortieW2 = True

                                        End If
                                    Else
                                        SortieW2 = True
                                    End If
                                End While
                            End If
                        Next
                    End If
                    i = i + 1
                End While
            End If

            '*** Close the batch
            If (testError) Then
                oBatch.BatchClose(Kofax.Capture.SDK.CustomModule.KfxDbState.KfxDbBatchError, Kofax.Capture.SDK.CustomModule.KfxDbQueue.KfxDbQueueException, 0, testErrorMessage)
            Else
                oBatch.BatchClose(Kofax.Capture.SDK.CustomModule.KfxDbState.KfxDbBatchReady, Kofax.Capture.SDK.CustomModule.KfxDbQueue.KfxDbQueueNext, 0, "")
            End If

        Catch ex As Exception
            Notify(ex.Message)
            oBatch.BatchClose(Kofax.Capture.SDK.CustomModule.KfxDbState.KfxDbBatchError, Kofax.Capture.SDK.CustomModule.KfxDbQueue.KfxDbQueueException, 0, ex.Message)
        End Try

    End Sub


    '********************************************************************************
    '*** Sub:       FindFirstFormType
    '*** Purpose:   Find first FormType name of current batch.
    '***            FormTypes are ordered alphabetically
    '*** Inputs:    none
    '*** Outputs:   FormType Name
    '********************************************************************************
    Private Function FindFirstFormType(ByVal oBatch As Kofax.Capture.SDK.CustomModule.IBatch) As String

		'*** Access Setup Information
		'*** Find the first form type's name
		Dim oRootSetup As Kofax.Capture.SDK.Data.IACDataElement = Nothing
		Dim oDocClassesElement As Kofax.Capture.SDK.Data.IACDataElement = Nothing
		Dim oDocClassElement As Kofax.Capture.SDK.Data.IACDataElement = Nothing
		Dim oFormTypesElement As Kofax.Capture.SDK.Data.IACDataElement = Nothing
		Dim oColFormType As Kofax.Capture.SDK.Data.IACDataElementCollection = Nothing
		Dim oFormType As Kofax.Capture.SDK.Data.IACDataElement = Nothing
		Dim strTemp As String = String.Empty

		oRootSetup = oBatch.ExtractSetupACDataElement(0)
		oDocClassesElement = oRootSetup.FindChildElementByName(DOCUMENTCLASSES)
		oDocClassElement = oDocClassesElement.FindChildElementByName(DOCUMENTCLASS)
		oFormTypesElement = oDocClassElement.FindChildElementByName(FORMTYPES)

		'*** Get FormType collection
		oColFormType = oFormTypesElement.FindChildElementsByName(FORMTYPE)

		'*** Get collection of child elements.
		Dim lFormTypeIndex As Integer
		If oColFormType.Count <= 0 Then
			'*** DocumentClass have no FormType
			MsgBox(My.Resources.DocClassHasNoFormType, , My.Resources.ApplicationTitle)
			Return strTemp
			Exit Function
		Else
			'*** Now compare FormType names and get the first one by alphabetical order
			strTemp = oColFormType.Item(1).AttributeValue(STR_NAME)
			For lFormTypeIndex = 1 To oColFormType.Count
				oFormType = oColFormType.Item(lFormTypeIndex)
				If strTemp > oFormType.AttributeValue(STR_NAME) Then
					strTemp = oFormType.AttributeValue(STR_NAME)
				End If
			Next
		End If

		'*** Here is the first form type's name
		Return strTemp

	End Function

    Public Sub Dispose() Implements IDisposable.Dispose
    End Sub
End Class
