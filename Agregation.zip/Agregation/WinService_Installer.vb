﻿Imports System.ServiceProcess

<ComponentModel.RunInstaller(True)>
Public Class WinService_Installer
    Inherits System.Configuration.Install.Installer

    Public Sub New()
        MyBase.New()

        InitializeComponent()

    End Sub

    Protected Overrides Sub OnBeforeInstall(savedState As IDictionary)
        Uninstall(savedState)
        MyBase.OnBeforeInstall(savedState)
    End Sub

    Protected Overrides Sub OnAfterInstall(savedState As IDictionary)
        MyBase.OnAfterInstall(savedState)

        If WinService.StartAfterInstall Then
            'The following code starts the services after it is installed.
            Using serviceController As New System.ServiceProcess.ServiceController(ServiceInstaller1.ServiceName)
                serviceController.Start()
            End Using
        End If
    End Sub

    Public Overrides Sub Uninstall(savedState As IDictionary)
        If ServiceController.GetServices().Any(Function(x) String.Equals(x.ServiceName, WinService.SvcName, StringComparison.InvariantCultureIgnoreCase)) Then
            MyBase.Uninstall(savedState)
        End If
    End Sub

    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Private Sub RemoveIfExists(ByVal svcName As String, ByRef savedState As IDictionary)
    ' If ServiceController.GetServices().Any(Function(x) String.Equals(x.ServiceName, svcName, StringComparison.InvariantCultureIgnoreCase)) Then
    '        Uninstall(savedState)
    ' End If
    ' End Sub

    Private components As ComponentModel.IContainer

    <DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.ServiceProcessInstaller1 = New System.ServiceProcess.ServiceProcessInstaller
        Me.ServiceInstaller1 = New System.ServiceProcess.ServiceInstaller

        Me.ServiceProcessInstaller1.Account = System.ServiceProcess.ServiceAccount.LocalSystem
        Me.ServiceProcessInstaller1.Password = Nothing
        Me.ServiceProcessInstaller1.Username = Nothing

        Me.ServiceInstaller1.ServiceName = WinService.SvcName
        Me.ServiceInstaller1.DisplayName = WinService.SvcDisplay
        Me.ServiceInstaller1.Description = WinService.SvcDescription

        Me.ServiceInstaller1.StartType = System.ServiceProcess.ServiceStartMode.Automatic

        Me.Installers.AddRange(New System.Configuration.Install.Installer() {Me.ServiceProcessInstaller1, Me.ServiceInstaller1})

    End Sub
    Friend WithEvents ServiceProcessInstaller1 As System.ServiceProcess.ServiceProcessInstaller
    Friend WithEvents ServiceInstaller1 As System.ServiceProcess.ServiceInstaller

End Class